//
//  AppDelegate.m
//  XMThinMe
//
//  Created by 何振东 on 14/10/31.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "AppDelegate.h"
#import "XMHomeVC.h"
#import "XMSettingsVC.h"
#import "XMMessageVC.h"
#import "XMMyCollectionVC.h"
#import "OCheckUpdate.h"
#import "XMGuideVC.h"
#import "APService.h"
#import "MobClick.h"
#import "UMFeedback.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    /// 创建程序所需数据表和文件下载文件夹
    [[XMDBManager sharedInstance] createDatabaseAndTables];
    [[XMDBManager sharedInstance] createDownloadFolder];
    
    /// 注册微信服务
    [WXApi registerApp:kWeChatAppId];
    
    /// 注册短信服务
    [SMS_SDK registerApp:kMessageAPPID withSecret:kMessageAPPSecret];
    
    /// 注册百度服务
    self.mapManager = [[BMKMapManager alloc] init];
    [self.mapManager start:kBaiDuMapKey generalDelegate:nil];
    
    /// 注册极光推送
    // Required
#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_7_1
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
        //可以添加自定义categories
        [APService registerForRemoteNotificationTypes:(UIUserNotificationTypeBadge |
                                                       UIUserNotificationTypeSound |
                                                       UIUserNotificationTypeAlert)
                                           categories:nil];
    } else {
        //categories 必须为nil
        [APService registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge |
                                                       UIRemoteNotificationTypeSound |
                                                       UIRemoteNotificationTypeAlert)
                                           categories:nil];
    }
#else
    //categories 必须为nil
    [APService registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge |
                                                   UIRemoteNotificationTypeSound |
                                                   UIRemoteNotificationTypeAlert)
                                       categories:nil];
#endif
    // Required
    [APService setupWithOption:launchOptions];
    
    // 友盟配置
    [MobClick setAppVersion:XcodeAppVersion];
    [MobClick startWithAppkey:kUmengKey];
    [UMFeedback setAppkey:kUmengKey];
    
    // 设置统一程序界面
    NSDictionary *dict = @{NSFontAttributeName:kB_MiddleFont, NSForegroundColorAttributeName:kBlackColor};
    [[UINavigationBar appearance] setTitleTextAttributes:dict];
    [[UINavigationBar appearance] setTintColor:kBlackColor];
    [[UINavigationBar appearance] setBackIndicatorTransitionMaskImage:[UIImage imageNamed:@"nav_back"]];
    [[UINavigationBar appearance] setBackIndicatorImage:[UIImage imageNamed:@"nav_back"]];
    [[UITabBar appearance] setSelectedImageTintColor:mRGB(168, 142, 89)];
    [[UITabBarItem appearance] setTitlePositionAdjustment:UIOffsetMake(0, -2)];
    
    ONavController *homeNC = [[ONavController alloc] initWithRootViewController:[[XMHomeVC alloc] init]];
    ONavController *collectionNC = [[ONavController alloc] initWithRootViewController:[[XMMyCollectionVC alloc] init]];
    ONavController *messageNC = [[ONavController alloc] initWithRootViewController:[[XMMessageVC alloc] init]];
    ONavController *settingsNC = [[ONavController alloc] initWithRootViewController:[[XMSettingsVC alloc] init]];
    
    UITabBarController *tabBarController = [[UITabBarController alloc] init];
    tabBarController.viewControllers = @[homeNC, messageNC, collectionNC, settingsNC];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor blackColor];
    self.window.rootViewController = tabBarController;
    self.window.cornerRadius = 4;
    [self.window makeKeyAndVisible];
        
    /// 配置程序初始化默认参数和检测更新
    [[XMAppManager sharedInstance] configureInitialDefaultParams];
    [[OCheckUpdate sharedInstance] checkUpdateCompletion:nil];

    return YES;
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    // Required
    [APService registerDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    // Required
    [APService handleRemoteNotification:userInfo];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {    
    // IOS 7 Support Required
    [APService handleRemoteNotification:userInfo];
    completionHandler(UIBackgroundFetchResultNewData);
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    application.applicationIconBadgeNumber = [[XMDBManager sharedInstance] unreadBeaconList].count;
    if (application.applicationState == UIApplicationStateActive) {
        [application  cancelLocalNotification:notification];
    }
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    application.applicationIconBadgeNumber = [[XMDBManager sharedInstance] unreadBeaconList].count;
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    application.applicationIconBadgeNumber = [[XMDBManager sharedInstance] unreadBeaconList].count;
}


#pragma mark - WXApiDelegate

- (void)onResp:(BaseResp *)resp
{
    if (resp.errStr) {
        UIAlertView  *alert=[[UIAlertView  alloc] initWithTitle:@"微信分享" message:resp.errStr delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert  show];
    }
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return [WXApi  handleOpenURL:url delegate:self];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    return [WXApi  handleOpenURL:url delegate:self];
}

@end
