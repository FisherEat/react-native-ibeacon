//
//  XMNearbyBeacon.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMNearbyBeaconManager.h"

/// 定义延时
static NSTimeInterval kDelayTime = 3.0f;

@interface XMNearbyBeaconManager ()
@property (strong, nonatomic) NSTimer   *delayTimer;
@property (assign, nonatomic) NSInteger timeInterval;

/// 判断延时计时器的工作状态
@property (assign, nonatomic) BOOL           delayTimerWorking;

@property (assign, nonatomic) long long start_time;
@property (assign, nonatomic) long long end_time;
@property (strong, nonatomic) NSString       *web_id;

@property (copy, nonatomic) DelayTimerFinishedBlock delayTimerFinishedBlock;

@end

@implementation XMNearbyBeaconManager

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

- (void)startCalculateResidenceTimeForWeb:(NSString *)webId
{
    self.web_id = webId;
    self.start_time = [[NSDate date] timeIntervalSince1970];
}

/// 计算延时，超过该时间，则停止计时，并发送到服务器
- (void)startDelayTimerFinished:(DelayTimerFinishedBlock)finished
{
    self.delayTimerFinishedBlock = nil;
    self.delayTimerFinishedBlock = finished;
    
    if (!self.web_id) {
        return;
    }
    if (self.delayTimerWorking) {
        return;
    }
    if (self.delayTimer) {
        return;
    }
    
    self.delayTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerHandle) userInfo:nil repeats:YES];
    [self.delayTimer fire];
    self.delayTimerWorking = YES;
}

- (void)timerHandle
{
    self.timeInterval++;
    if (self.timeInterval >= kDelayTime) {
        [self sendBeaconToService];
        [self stopDelayTimer];
        self.web_id = nil;
        if (self.delayTimerFinishedBlock) {
            self.delayTimerFinishedBlock();
        }
    }
}

- (void)stopDelayTimer
{
    [self.delayTimer invalidate];
    self.delayTimer = nil;
    self.delayTimerWorking = NO;
    self.timeInterval = 0;
}

- (void)sendBeaconToService
{
    if (!self.web_id) {
        return;
    }
    
    self.end_time = [[NSDate date] timeIntervalSince1970];
    if (self.end_time - self.start_time < 20) {
        return;
    }
    
    self.end_time = [[NSDate date] timeIntervalSince1970];
//    NSDictionary *params = @{@"start_time": @(self.start_time),
//                             @"end_time": @(self.end_time),
//                             @"web_id": self.web_id,
//                             @"user_id": [XMUserManager sharedInstance].userId};
//    [[OURLRequest sharedInstance] postForPath:N_Statistics_UploadUserStayInBeaconNearbyTime
//                                   withParams:params
//                                      success:^(id data)
//    {
//        
//    }
//                                      failure:^(NSString *error)
//    {
//        
//    }];
}

@end
