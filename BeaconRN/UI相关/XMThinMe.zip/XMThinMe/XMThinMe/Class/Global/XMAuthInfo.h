//
//  CJAuthInfo.h
//  CJSX
//
//  Created by 何振东 on 14-5-29.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  用户授权信息对象，在这里组装成一个完整的对象，可直接作为请求体发送。
 *  在获取到用户数据后，有实际的值，否则为相应的值都为nil。
 */
@interface XMAuthInfo : NSObject
/// 用户id
@property (copy, nonatomic  ) NSString     *uid;
/// 后台返回的token，用于验证用户是否有效和过期
@property (copy, nonatomic  ) NSString     *token;
/// 区域码，注册时确定
@property (assign, nonatomic) NSInteger    areaCode;

/// 根据uid、token、areaCode组成的字典结构数据
@property (strong, nonatomic, readonly) NSDictionary *authInfo;

/**
 *  由于本类的功能为全局实现，所以采用单例模式。
 *
 *  @return CJAuthInfo单例对象
 */
+ (instancetype)sharedInstance;


@end
