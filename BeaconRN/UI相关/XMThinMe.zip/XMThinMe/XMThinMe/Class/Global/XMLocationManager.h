//
//  XMLocationService.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/13.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BMapKit.h" 

/**
 *  位置管理类
 */

/// 更新用户当前位置时的返回代理
typedef void(^UserLocationBlock)(BMKUserLocation *userLocation, NSError *error);

/// 将经纬度转换成地理位置完成回调
typedef void(^ReverseCoordinateCompletionHandle)(BMKReverseGeoCodeResult *result, BMKSearchErrorCode errorCode);

/// 将经纬度转换成地理位置完成回调
typedef void(^ReverseAddressCompletionHandle)(BMKGeoCodeResult *result, BMKSearchErrorCode errorCode);

/// 搜索POI返回代理
typedef void(^SearchNearbyPOICompletionHandle)(BMKPoiResult *poiResult, BMKSearchErrorCode errorCode);

/// 搜索云端POI返回代理
typedef void(^SearchCloudPOICompletionHandle)(NSArray *poiList, NSInteger type, BMKSearchErrorCode errorCode);

/// 搜索路径返回代理
typedef void(^SearchRouteCompletionHandle)(BMKWalkingRouteResult *routeResult, BMKSearchErrorCode errorCode);


@interface XMLocationManager : NSObject
<
    BMKLocationServiceDelegate,
    BMKGeoCodeSearchDelegate,
    BMKCloudSearchDelegate,
    BMKLocationServiceDelegate,
    BMKPoiSearchDelegate,
    BMKRouteSearchDelegate
>
@property (strong, nonatomic, readonly) BMKLocationService *locationService;
@property (strong, nonatomic, readonly) BMKGeoCodeSearch   *geoCodeSearch;
@property (strong, nonatomic, readonly) BMKPoiSearch       *poiSearch;
@property (strong, nonatomic, readonly) BMKRouteSearch     *routeSearch;
@property (strong, nonatomic, readonly) BMKCloudSearch     *cloudSearch;

+ (instancetype)manager;

/// 获取用户当前位置
- (void)updateUserLocation:(UserLocationBlock)userLocation;

/**
 *  将经纬度转换为详细地址
 *
 *  @param coordinate                 要转换的经纬度
 *  @param reverseGeoCompletionHandle 转换完成后的回调
 */
- (void)reverseCoordinate:(CLLocationCoordinate2D)coordinate completionHandle:(ReverseCoordinateCompletionHandle)reverseCoordinateCompletionHandle;

/**
 *  将地址转换为经纬度
 *
 *  @param address                        要转换的地址
 *  @param city                           该地址所在城市
 *  @param reverseAddressCompletionHandle 转换完成后的回调
 */
- (void)reverseAddrese:(NSString *)address inCity:(NSString *)city completionHandle:(ReverseAddressCompletionHandle)reverseAddressCompletionHandle;

/**
 *  搜索周围的POI列表
 *
 *  @param coordinate                      搜索中心点
 *  @param keyword                         搜索关键词
 *  @param radius                          搜索半径
 *  @param searchNearbyPOICompletionHandle 搜索完成后的回调
 */
- (void)searchNearbyPOIWidthCoordinate:(CLLocationCoordinate2D)coordinate keyword:(NSString *)keyword radius:(CGFloat)radius completionHandle:(SearchNearbyPOICompletionHandle)searchNearbyPOICompletionHandle;

/**
 *  搜索用户云端自建的POI
 *
 *  @param keyword                             搜索关键词
 *  @param region                              搜索区域范围
 *  @param searchCloudLocationCompletionHandle 搜索完成后的回调
 */
- (void)searchCloudPOIWidthKeyword:(NSString *)keyword region:(NSString *)region completionHandle:(SearchCloudPOICompletionHandle)searchCloudLocationCompletionHandle;

/**
 *  步行路径搜索，返回路径数组
 *
 *  @param fromCoordinate              搜索起点
 *  @param toCoordinate                搜索终点
 *  @param searchRouteCompletionHandle 搜索完成后的回调
 */
- (void)walkingRouteSearchFrom:(CLLocationCoordinate2D)fromCoordinate to:(CLLocationCoordinate2D)toCoordinate completionHandle:(SearchRouteCompletionHandle)searchRouteCompletionHandle;

/**
 *  路径导航
 *
 *  @param fromCoordinate 导航起点
 *  @param fromTitle      导航起点标题
 *  @param toCoordinate   导航终点
 *  @param toTitle        导航终点标题
 */
- (void)navigateFrom:(CLLocationCoordinate2D)fromCoordinate fromTitle:(NSString *)fromTitle to:(CLLocationCoordinate2D)toCoordinate toTitle:(NSString *)toTitle;

@end
