//
//  XMProgressHUD.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/18.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMProgressHUD : NSObject

+ (instancetype)sharedInstance;

/// 显示和隐藏等待视图
- (void)showProgress;
- (void)showProgressAtView:(UIView *)aView;
- (void)hideProgress;

/// 显示提示语，自动消失
+ (void)showTips:(NSString *)tips;
+ (void)showTips:(NSString *)tips delay:(CGFloat)delay;
+ (void)showTips:(NSString *)tips atView:(UIView *)view;

+ (void)showTips:(NSString *)tips atView:(UIView *)view delay:(CGFloat)delay;

@end
