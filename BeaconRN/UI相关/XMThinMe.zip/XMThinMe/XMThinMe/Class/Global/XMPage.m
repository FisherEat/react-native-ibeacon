//
//  CJPage.m
//  CJSX
//
//  Created by 何振东 on 14-5-29.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import "XMPage.h"

@implementation XMPage

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.pageSize = 10;
        self.pageIndex = 0;
    }
    return self;
}


@end
