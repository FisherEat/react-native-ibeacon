//
//  XMDBManager.m
//  XMMuseum
//
//  Created by 何振东 on 14-6-29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMDBManager.h"

//定义数据库名和路径及表名
#define kDBPath [NSString stringWithFormat:@"%@/%@", kDocuments, @"xm_museum.db"]
#define kBeaconTable @"beacon"
#define kUserTable   @"user"
#define kFileTable   @"file"

@interface XMDBManager ()
@property (strong, nonatomic) FMDatabase *db;
@property (copy, nonatomic) NSString *dbPath;

@end

@implementation XMDBManager

+ (instancetype)sharedInstance
{
    static XMDBManager *dbManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dbManager = [[XMDBManager alloc] init];
    });
    return dbManager;
}

- (id)init
{
    self = [super init];
    if (self) {
        self.db = [FMDatabase databaseWithPath:kDBPath];
        self.dbPath = kDBPath;
    }
    return self;
}


- (void)createDownloadFolder
{
    if (![[NSFileManager defaultManager] fileExistsAtPath:kXM_Download_Dir]) {
        NSError *error = nil;
        BOOL result = [[NSFileManager defaultManager] createDirectoryAtPath:kXM_Download_Dir withIntermediateDirectories:YES attributes:nil error:&error];
        if (result) {
            NSLog(@"创建下载目录成功");
        }
        else {
            NSLog(@"创建下载目录失败error:%@", error);
        }
    }
}

- (void)createDatabaseAndTables
{
    BOOL result = NO;
    if ([self.db open])
    {
        //创建Beacon记录表
        NSString *sqlKey = @"id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, major TEXT, minor TEXT, rssi TEXT, beacon_id TEXT, template_examples_id TEXT, shop_id TEXT, title TEXT, description TEXT, img_url TEXT, enter_times INTEGER DEFAULT 0, last_update_date INTEGER, collected INTEGER DEFAULT 0, readed INTEGER DEFAULT 0, type INTEGER DEFAULT 0";
        NSString *sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (%@)", kBeaconTable, sqlKey];
        result = [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"create beacon_info error:%@", [self.db lastError]);
        
        //创建用户信息表
        sqlKey = @"id integer primary key, token text, username text, password text, balance real, avatar text, nickname text";
        sql = [NSString stringWithFormat:@"create table if not exists %@ (%@)", kUserTable, sqlKey];
        result = [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"create user_info error:%@", [self.db lastError]);
        
        //创建下载文件信息表
        sqlKey = @"id integer primary key, attachment_id text, attachment_name text, attachment_url text, size text, upload_time INTEGER, local_path text";
        sql = [NSString stringWithFormat:@"create table if not exists %@ (%@)", kFileTable, sqlKey];
        result = [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"create user_info error:%@", [self.db lastError]);
    }
    [self.db close];
}

- (XMBeacon *)beaconInfoForBeaconId:(NSString *)beacon_id
{
    XMBeacon *beacon = nil;
    if ([self.db open]) {
        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE beacon_id = \"%@\"", kBeaconTable, beacon_id];
        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"query beacon error:%@", [self.db lastError]);
        
        while ([resultSet next]) {
            beacon = [self dictToBeaconBasicInfoModel:resultSet.resultDictionary];
            break;
        }
    }
    
    return beacon;
}

- (void)updateEnterTimesForBeaconId:(NSString *)beacon_id
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE beacon_id = \"%@\"", kBeaconTable, beacon_id];
        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"error:%@", [self.db lastError]);
        
        // 如果已有该记录了，则更新进入次数，否则插入该记录
        if ([resultSet next]) {
            /// 如果上次更新时间距离现在已超过1天，则进入次数＋1，否则不作处理
            NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
            NSTimeInterval last_update_date = [resultSet longForColumn:@"last_update_date"];
            if (now - last_update_date > 60 * 60 * 24) {
                sql = [NSString stringWithFormat:@"UPDATE %@ SET enter_times = enter_times + 1, last_update_date = %f where beacon_id = \"%@\"", kBeaconTable, now, beacon_id];
                [self.db executeUpdate:sql];
                if ([self.db hadError])
                    NSLog(@"update enter_timers error:%@", [self.db lastError]);
            }
        }
    }
}

- (void)updateBeaconInfo:(XMBeacon *)beacon
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE beacon_id = \"%@\"", kBeaconTable, beacon.beacon_id];
        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"error:%@", [self.db lastError]);
        
        // 如果已有该记录了，则返回
        if ([resultSet next]) {
            return;
        }
        //若表中无记录则创建记录
        NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
        sql = [NSString stringWithFormat:@"INSERT INTO %@\
               (uuid, major, minor, rssi, beacon_id, template_examples_id, title, description, img_url, enter_times, last_update_date, type, shop_id) VALUES\
               (\"%@\", \"%@\", \"%@\", \"%@\", \"%@\",  \"%@\", \"%@\", \"%@\", \"%@\", %zd, %f, %zd, \"%@\")",
               kBeaconTable, beacon.uuid, beacon.major, beacon.minor, beacon.rssi, beacon.beacon_id, beacon.template_examples_id, beacon.title, beacon.description, beacon.img_url, 1, now, beacon.type, beacon.shop_id];
        [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"insert beacon_info error:%@", [self.db lastError]);
    }
    [self.db close];
}

- (NSArray *)allBeaconList
{
    NSMutableArray *array = @[].mutableCopy;
    if ([self.db open]) {
        NSString *sql = [NSString stringWithFormat:@"SELECT *, COUNT(distinct template_examples_id) FROM %@ GROUP BY template_examples_id ORDER BY last_update_date DESC", kBeaconTable];
//        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ ORDER BY last_update_date DESC", kBeaconTable];

        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"query all beacon error:%@", [self.db lastError]);
        
        while ([resultSet next]) {
            [array addObject:[self dictToBeaconBasicInfoModel:resultSet.resultDictionary]];
        }
    }
    
    return array;
}

- (NSArray *)unreadBeaconList
{
    NSMutableArray *array = @[].mutableCopy;
    if ([self.db open]) {
        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@", kBeaconTable];
        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"query unread beacon error:%@", [self.db lastError]);
        
        while ([resultSet next]) {
            if (![resultSet intForColumn:@"readed"]) {
                [array addObject:[self dictToBeaconBasicInfoModel:resultSet.resultDictionary]];
            }
        }
    }
    
    return array;
}

- (void)deleteBeacon:(XMBeacon *)beacon
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@ WHERE beacon_id = \"%@\"", kBeaconTable, beacon.beacon_id];
        [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"delete beacon error:%@", [self.db lastError]);
    }
    [self.db close];
}

- (void)deleteAllBeacons
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@", kBeaconTable];
        [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"delete beacon error:%@", [self.db lastError]);
    }
    [self.db close];
}

- (void)setRead:(BOOL)isRead forWBeaconId:(NSString *)beacon_id
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE beacon_id = \"%@\"", kBeaconTable, beacon_id];
        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"query beacon error:%@", [self.db lastError]);
        
        if ([resultSet next]) {
            sql = [NSString stringWithFormat:@"UPDATE %@ SET readed = %d where beacon_id = \"%@\"", kBeaconTable, isRead, beacon_id];
            [self.db executeUpdate:sql];
            if ([self.db hadError])
                NSLog(@"update reading beacon_info error:%@", [self.db lastError]);
        }
    }
    [self.db close];
}

/// 将数据字典转换为信息对象
- (XMBeacon *)dictToBeaconBasicInfoModel:(NSDictionary *)dict
{
    NSData *data = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
    XMBeacon *beacon = [[XMBeacon alloc] initWithJSONData:data];
    return beacon;
}



#pragma mark file info

- (void)updateFileInfo:(XMFile *)file
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE attachment_id = \"%@\"", kFileTable, file.attachment_id];
        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"error:%@", [self.db lastError]);
        
        // 如果已有该记录了，则返回
        if ([resultSet next]) {
            return;
        }
        //若表中无记录则创建记录
        sql = [NSString stringWithFormat:@"INSERT INTO %@\
               (attachment_id, attachment_name, attachment_url, size, upload_time, local_path) VALUES\
               (\"%@\", \"%@\", \"%@\", \"%@\", %f, \"%@\")",
               kFileTable, file.attachment_id, file.attachment_name, file.attachment_url, file.size, file.upload_time, file.local_Path];
        [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"insert beacon_info error:%@", [self.db lastError]);
    }
    [self.db close];
}

- (void)deleteFile:(XMFile *)file
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@ WHERE attachment_id = \"%@\"", kFileTable, file.attachment_id];
        [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"delete beacon error:%@", [self.db lastError]);
    }
    [self.db close];
}

- (NSArray *)allFileList
{
    NSMutableArray *array = @[].mutableCopy;
    if ([self.db open]) {
        NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ ORDER BY upload_time DESC", kFileTable];
        
        FMResultSet *resultSet = nil;
        resultSet = [self.db executeQuery:sql];
        if ([self.db hadError])
            NSLog(@"query all beacon error:%@", [self.db lastError]);
        
        while ([resultSet next]) {
            [array addObject:[self dictToFileInfoModel:resultSet.resultDictionary]];
        }
    }
    
    return array;
}

- (void)deleteAllFiles
{
    if ([self.db open])
    {
        NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@", kFileTable];
        [self.db executeUpdate:sql];
        if ([self.db hadError])
            NSLog(@"delete beacon error:%@", [self.db lastError]);
    }
    [self.db close];
}


/// 将数据字典转换为信息对象
- (XMFile *)dictToFileInfoModel:(NSDictionary *)dict
{
    NSData *data = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
    return [[XMFile alloc] initWithJSONData:data];
}


@end
