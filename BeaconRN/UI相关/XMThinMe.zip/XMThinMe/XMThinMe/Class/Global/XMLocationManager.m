//
//  XMLocationService.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/13.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMLocationManager.h"

@interface XMLocationManager ()
@property (strong, nonatomic) BMKLocationService *locationService;
@property (strong, nonatomic) BMKGeoCodeSearch   *geoCodeSearch;
@property (strong, nonatomic) BMKPoiSearch       *poiSearch;
@property (strong, nonatomic) BMKRouteSearch     *routeSearch;
@property (strong, nonatomic) BMKCloudSearch     *cloudSearch;

@property (copy, nonatomic) UserLocationBlock userLocationBlock;
@property (copy, nonatomic) ReverseCoordinateCompletionHandle reverseCoordinateCompletionHandle;
@property (copy, nonatomic) ReverseAddressCompletionHandle reverseAddressCompletionHandle;
@property (copy, nonatomic) SearchNearbyPOICompletionHandle searchNearbyPOICompletionHandle;
@property (copy, nonatomic) SearchCloudPOICompletionHandle searchCloudPOICompletionHandle;
@property (copy, nonatomic) SearchRouteCompletionHandle searchRouteCompletionHandle;

@end

@implementation XMLocationManager

+ (instancetype)manager
{
    return [[XMLocationManager alloc] init];
}

- (id)init
{
    self = [super init];
    if (self) {
        self.locationService = [[BMKLocationService alloc] init];
        self.locationService.delegate = self;

        self.geoCodeSearch = [[BMKGeoCodeSearch alloc] init];
        self.geoCodeSearch.delegate = self;

        self.locationService = [[BMKLocationService alloc] init];
        self.locationService.delegate = self;

        self.poiSearch = [[BMKPoiSearch alloc] init];
        self.poiSearch.delegate = self;

        self.cloudSearch = [[BMKCloudSearch alloc] init];
        self.cloudSearch.delegate = self;

        self.routeSearch = [[BMKRouteSearch alloc] init];
        self.routeSearch.delegate = self;
        
        self.geoCodeSearch = [[BMKGeoCodeSearch alloc] init];
        self.geoCodeSearch.delegate = self;
    }
    return self;
}

- (void)updateUserLocation:(UserLocationBlock)userLocation
{
    if (!self.userLocationBlock) {
        self.userLocationBlock = userLocation;
    }
    [self.locationService startUserLocationService];
}


- (void)reverseCoordinate:(CLLocationCoordinate2D)coordinate completionHandle:(ReverseCoordinateCompletionHandle)reverseCoordinateCompletionHandle
{
    if (!self.reverseCoordinateCompletionHandle) {
        self.reverseCoordinateCompletionHandle = reverseCoordinateCompletionHandle;
    }

    BMKReverseGeoCodeOption *option = [[BMKReverseGeoCodeOption alloc] init];
    option.reverseGeoPoint = coordinate;
    [self.geoCodeSearch reverseGeoCode:option];
}

- (void)reverseAddrese:(NSString *)address inCity:(NSString *)city completionHandle:(ReverseAddressCompletionHandle)reverseAddressCompletionHandle
{
    if (self.reverseAddressCompletionHandle) {
        self.reverseAddressCompletionHandle = reverseAddressCompletionHandle;
    }
    
    BMKGeoCodeSearchOption *option = [[BMKGeoCodeSearchOption alloc] init];
    option.city = nil;
    option.address = nil;
    [self.geoCodeSearch geoCode:option];
}

- (void)searchNearbyPOIWidthCoordinate:(CLLocationCoordinate2D)coordinate keyword:(NSString *)keyword radius:(CGFloat)radius completionHandle:(SearchNearbyPOICompletionHandle)searchNearbyPOICompletionHandle
{
    if (!self.searchNearbyPOICompletionHandle) {
        self.searchNearbyPOICompletionHandle = searchNearbyPOICompletionHandle;
    }
    BMKNearbySearchOption *option = [[BMKNearbySearchOption alloc] init];
    option.location = coordinate;
    option.radius = radius;
    option.keyword = keyword;
    BOOL result = [self.poiSearch poiSearchNearBy:option];
    if (!result) {
//        mAlertView(@"提示", @"搜索附近的POI失败！");
    }
}

- (void)searchCloudPOIWidthKeyword:(NSString *)keyword region:(NSString *)region completionHandle:(SearchCloudPOICompletionHandle)searchCloudLocationCompletionHandle
{
    if (!self.searchCloudPOICompletionHandle) {
        self.searchCloudPOICompletionHandle = searchCloudLocationCompletionHandle;
    }

    BMKCloudLocalSearchInfo *searchInfo  = [[BMKCloudLocalSearchInfo alloc] init];
    searchInfo.ak         = kBDCloudAK;
    searchInfo.geoTableId = kBDTableID;
    searchInfo.keyword    = keyword;
    searchInfo.region     = region;
    
    BOOL ret = [self.cloudSearch localSearchWithSearchInfo:searchInfo];
    if (!ret) {
//        mAlertView(@"提示", @"检索本地POI失败");
    }
}


- (void)walkingRouteSearchFrom:(CLLocationCoordinate2D)fromCoordinate to:(CLLocationCoordinate2D)toCoordinate completionHandle:(SearchRouteCompletionHandle)searchRouteCompletionHandle
{
    if (!self.searchRouteCompletionHandle) {
        self.searchRouteCompletionHandle = searchRouteCompletionHandle;
    }
    
    /// 搜索路径规划
    BMKPlanNode *fromNode = [[BMKPlanNode alloc] init];
    fromNode.pt = fromCoordinate;
    
    BMKPlanNode *toNode = [[BMKPlanNode alloc] init];
    toNode.pt = toCoordinate;
    BMKWalkingRoutePlanOption *option = [BMKWalkingRoutePlanOption alloc];
    option.from = fromNode;
    option.to = toNode;
    BOOL result = [self.routeSearch walkingSearch:option];
    if (!result) {
        mAlertView(@"路径规划", @"规划失败！");
    }
}

- (void)navigateFrom:(CLLocationCoordinate2D)from fromTitle:(NSString *)fromTitle to:(CLLocationCoordinate2D)to toTitle:(NSString *)toTitle
{
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"baidumap://map/"]]){
        BMKPlanNode *end = [[BMKPlanNode alloc] init];
        end.pt = to;
        end.name = fromTitle;
        BMKNaviPara *naviPara = [[BMKNaviPara alloc] init];
        naviPara.naviType = BMK_NAVI_TYPE_NATIVE;
        naviPara.endPoint = end;
        naviPara.appScheme = @"museum://com.xunmitech.museum";
        [BMKNavigation openBaiduMapNavigation:naviPara];
    }
    else {
        MKMapItem *fromItem = [MKMapItem mapItemForCurrentLocation];
        MKPlacemark *palcemark = [[MKPlacemark alloc] initWithCoordinate:to addressDictionary:nil];
        MKMapItem *toItem = [[MKMapItem alloc] initWithPlacemark:palcemark];
        toItem.name = toTitle;
        NSDictionary *options = @{MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving,
                                  MKLaunchOptionsShowsTrafficKey:@(YES)};
        [MKMapItem openMapsWithItems:@[fromItem, toItem] launchOptions:options];
    }
}


#pragma mark - locationService delegate

- (void)didUpdateUserLocation:(BMKUserLocation *)userLocation
{
    if (self.userLocationBlock) {
        self.userLocationBlock(userLocation, nil);
    }
}

- (void)didFailToLocateUserWithError:(NSError *)error
{
    if (self.userLocationBlock) {
        self.userLocationBlock(nil, error);
    }
}


#pragma mark - cloudSearch delegate

- (void)onGetCloudPoiResult:(NSArray *)poiResultList searchType:(int)type errorCode:(int)error
{
    if (self.searchCloudPOICompletionHandle) {
        self.searchCloudPOICompletionHandle(poiResultList, type, error);
    }
}


#pragma mark - poiSearchDelegate

- (void)onGetPoiResult:(BMKPoiSearch *)searcher result:(BMKPoiResult *)poiResult errorCode:(BMKSearchErrorCode)errorCode
{
    if (self.searchNearbyPOICompletionHandle) {
        self.searchNearbyPOICompletionHandle(poiResult, errorCode);
    }
}


#pragma mark - BMKGeoCodeSearchDelegate

- (void)onGetGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if (self.reverseAddressCompletionHandle) {
        self.reverseAddressCompletionHandle(result, error);
    }
}

- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if (self.reverseCoordinateCompletionHandle) {
        self.reverseCoordinateCompletionHandle(result, error);
    }
}


#pragma mark - routeDelegate

- (void)onGetTransitRouteResult:(BMKRouteSearch *)searcher result:(BMKTransitRouteResult *)result errorCode:(BMKSearchErrorCode)error
{
    
}

- (void)onGetDrivingRouteResult:(BMKRouteSearch *)searcher result:(BMKDrivingRouteResult *)result errorCode:(BMKSearchErrorCode)error
{
    
}

- (void)onGetWalkingRouteResult:(BMKRouteSearch *)searcher result:(BMKWalkingRouteResult *)result errorCode:(BMKSearchErrorCode)error
{
    if (self.searchRouteCompletionHandle) {
        self.searchRouteCompletionHandle(result, error);
    }
}


@end
