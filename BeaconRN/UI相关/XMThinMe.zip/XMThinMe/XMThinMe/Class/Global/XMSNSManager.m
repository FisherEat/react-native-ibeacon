//
//  XMSNSManager.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/14.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMSNSManager.h"
#import "WXApi.h"

@interface XMSNSManager () <UIActionSheetDelegate>


@end

@implementation XMSNSManager

+ (instancetype)shareInstance
{
    static XMSNSManager *snsManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        snsManager = [[XMSNSManager alloc] init];
    });
    return snsManager;
}

- (UIBarButtonItem *)shareBarButton
{
    UIButton *shareBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [shareBtn setImage:[UIImage imageNamed:@"exhibition_share_normal"] forState:UIControlStateNormal];
    [shareBtn setImage:[UIImage imageNamed:@"exhibition_share_highlighted"] forState:UIControlStateHighlighted];
    shareBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 20, 0, -20);
    [shareBtn sizeToFit];
    [shareBtn bk_addEventHandler:^(id sender) {
        UIActionSheet *as = [[UIActionSheet alloc] initWithTitle:@"分享到..." delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"微信好友", @"微信朋友圈", @"收藏到微信", nil];
        [as showInView:mKeyWindow];
    } forControlEvents:UIControlEventTouchUpInside];
    
    return [[UIBarButtonItem alloc] initWithCustomView:shareBtn];
}

- (void)sendTextMessage:(NSString *)message scene:(int)scene;
{
    SendMessageToWXReq *req = [[SendMessageToWXReq  alloc] init];
    req.bText = YES;
    req.text = message;
    req.scene = scene;
    [WXApi sendReq:req];
}

- (void)sendImage:(UIImage *)image scene:(int)scene
{
    WXMediaMessage *message = [WXMediaMessage message];
    [message setThumbImage:image];
    
    WXImageObject *ext = [WXImageObject object];
    ext.imageData = UIImagePNGRepresentation(image);
    
    message.mediaObject = ext;
    message.mediaTagName = @"WECHAT_TAG_JUMP_APP";
    message.messageExt = @"这是第三方带的测试字段";
    message.messageAction = @"<action>dotalist</action>";
    
    SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
    req.bText = NO;
    req.message = message;
    req.scene = scene;
    
    [WXApi sendReq:req];
}

- (void)sendLink:(NSString *)url thumb:(UIImage *)thumb title:(NSString *)title description:(NSString *)description scene:(int)scene
{
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = title;
    message.description = description;
    [message setThumbImage:thumb];
    
    WXWebpageObject *ext = [WXWebpageObject object];
    ext.webpageUrl = @"http://tech.qq.com/zt2012/tmtdecode/252.htm";
    
    message.mediaObject = ext;
    message.mediaTagName = @"WECHAT_TAG_JUMP_SHOWRANK";
    
    SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
    req.bText = NO;
    req.message = message;
    req.scene = scene;
    [WXApi sendReq:req];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            if (self.shareToFriendBlock) {
                self.shareToFriendBlock();
            }
            break;
        case 1:
            if (self.shareToFriendSessionBlock) {
                self.shareToFriendSessionBlock();
            }
            break;
        case 2:
            if (self.collectToWeChatBlock) {
                self.collectToWeChatBlock();
            }
            break;
        default:
            break;
    }
}



@end
