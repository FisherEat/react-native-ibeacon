//
//  XMSNSManager.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/14.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  社交网络管理类
 */
@interface XMSNSManager : NSObject

@property (copy, nonatomic) void (^shareToFriendBlock) (void);
@property (copy, nonatomic) void (^shareToFriendSessionBlock) (void);
@property (copy, nonatomic) void (^collectToWeChatBlock) (void);

//+ (instancetype)shareInstance;

/// 获取分享按钮
- (UIBarButtonItem *)shareBarButton;

/// 分享图片到微信
- (void)sendImage:(UIImage *)image scene:(int)scene;

/// 分享一个纯文字内容到微信
- (void)sendTextMessage:(NSString *)message scene:(int)scene;

/// 分享一个web链接到微信
- (void)sendLink:(NSString *)url thumb:(UIImage *)thumb title:(NSString *)title description:(NSString *)description scene:(int)scene;

@end
