//
//  XMProgressHUD.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/18.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMProgressHUD.h"

@interface XMProgressHUD ()
@property (strong, nonatomic) MBProgressHUD *progressHUD;
@property (strong, nonatomic) UIToolbar     *container;
@property (strong, nonatomic) UILabel       *lbl;

@end

@implementation XMProgressHUD

+ (instancetype)sharedInstance
{
    static XMProgressHUD *progress = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        progress = [[XMProgressHUD alloc] init];
    });
    return progress;
}

- (id)init
{
    self = [super init];
    if (self) {
        self.progressHUD = [MBProgressHUD showHUDAddedTo:mWindow animated:YES];
        self.progressHUD.yOffset = -107;
        self.progressHUD.opacity = 0.6;
        self.progressHUD.dimBackground = YES;
        self.progressHUD.color = kClearColor;
        self.progressHUD.y = 64;
        
        self.container = [[UIToolbar alloc] initWithFrame:CGRectMake((self.progressHUD.width - 80)/2, (self.progressHUD.height - 80)/2 - 95, 80, 80)];
        self.container.cornerRadius = 10;
        [self.progressHUD insertSubview:self.container atIndex:0];
        
        self.lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 45, self.container.width, 20)];
        self.lbl.text = @" 加载中...";
        self.lbl.textAlignment = NSTextAlignmentCenter;
        self.lbl.font = kFont(13);
        self.lbl.textColor = kBlackColor;
        [self.container addSubview:self.lbl];
        
        for (UIView *view  in self.progressHUD.subviews) {
            if ([view isKindOfClass:[UIActivityIndicatorView class]]) {
                UIActivityIndicatorView *indicator = (UIActivityIndicatorView *)view;
                indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
                indicator.color = [UIColor blackColor];
            }
        }
    }
    return self;
}

- (void)showProgress
{
    if (![mKeyWindow.subviews containsObject:self.progressHUD]) {
        [mKeyWindow addSubview:self.progressHUD];
    }
    [self.progressHUD show:YES];
}

- (void)showProgressAtView:(UIView *)aView
{
    if (![aView.subviews containsObject:self.progressHUD]) {
        [aView addSubview:self.progressHUD];
    }
    [self.progressHUD show:YES];
}

- (void)hideProgress
{
    [self.progressHUD hide:YES];
}

+ (void)showTips:(NSString *)tips
{
    [[self class] showTips:tips atView:mKeyWindow];
}

+ (void)showTips:(NSString *)tips delay:(CGFloat)delay
{
    [[self class] showTips:tips atView:mKeyWindow delay:delay];
}

+ (void)showTips:(NSString *)tips atView:(UIView *)view
{
    [[self class] showTips:tips atView:view delay:1.25];
}

+ (void)showTips:(NSString *)tips atView:(UIView *)view delay:(CGFloat)delay
{
    MBProgressHUD *hud = [[MBProgressHUD alloc] initWithView:view];
    hud.mode = MBProgressHUDModeText;
    hud.labelText = tips;
    hud.labelFont = kFont(14);
    hud.yOffset = -100;
    hud.opacity = 0.7;
    [view addSubview:hud];
    [hud show:YES];
    
    [self bk_performBlock:^{
        [hud hide:YES];
    } afterDelay:delay];
}


@end
