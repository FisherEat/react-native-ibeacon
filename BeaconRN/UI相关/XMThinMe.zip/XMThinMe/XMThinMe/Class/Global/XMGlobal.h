//
//  CJGlobalModel.h
//  CJSX
//
//  Created by 何振东 on 14-5-30.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

/**
 *  定义全局通用的对象模型和管理器
 */
#import <Foundation/Foundation.h>

#import "XMPage.h"
#import "XMAuthInfo.h"
#import "XMAppManager.h"
#import "XMBeaconManager.h"
#import "XMDBManager.h"
#import "XMNotificationManager.h"
#import "XMProgressHUD.h"
#import "XMUserManager.h"
#import "XMLocationManager.h"
#import "XMSNSManager.h"

