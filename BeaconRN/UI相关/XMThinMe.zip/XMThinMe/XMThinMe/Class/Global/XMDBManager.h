//
//  XMDBManager.h
//  XMMuseum
//
//  Created by 何振东 on 14-6-29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMBeacon.h"
#import "XMFile.h"

/**
 *  数据库中，使用到的数据管理类，包括对beacon数据的增删改查
 */
@interface XMDBManager : NSObject

/// 获取数据库路径
@property (copy, nonatomic, readonly) NSString *dbPath;

/**
 *  获取DBManager单例
 *
 *  @return DBManager单例对象
 */
+ (instancetype)sharedInstance;

//创建应用所需要的数据库和表
- (void)createDatabaseAndTables;

/// 创建下载文件夹
- (void)createDownloadFolder;

- (void)updateBeaconInfo:(XMBeacon *)beacon;

- (NSArray *)allBeaconList;

- (XMBeacon *)beaconInfoForBeaconId:(NSString *)beacon_id;

- (NSArray *)unreadBeaconList;

- (void)updateEnterTimesForBeaconId:(NSString *)beacon_id;

- (void)deleteBeacon:(XMBeacon *)beacon;

- (void)deleteAllBeacons;

- (void)setRead:(BOOL)isRead forWBeaconId:(NSString *)beacon_id;


 
/**
 *  本地文件管理部分
 *
 */
- (void)updateFileInfo:(XMFile *)file;
- (NSArray *)allFileList;
- (void)deleteAllFiles;
- (void)deleteFile:(XMFile *)file;


@end
