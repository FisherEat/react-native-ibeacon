//
//  CJAuthInfo.m
//  CJSX
//
//  Created by 何振东 on 14-5-29.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import "XMAuthInfo.h"

/**
 *  授权信息对象
 */
@implementation XMAuthInfo

+ (instancetype)sharedInstance
{
    static XMAuthInfo *authInfo = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        authInfo = [[XMAuthInfo alloc] init];
    });
    return authInfo;
}

- (id)init
{
    self = [super init];
    if (self) {
        self.token = @"";
        self.uid = @"18502565746_0";
        self.areaCode = 0;
    }
    return self;
}

- (NSDictionary *)authInfo
{
    if (self.uid && self.token)
    {
        NSDictionary *info = @{@"uid": self.uid,
                               @"token": self.token,
                               @"areaCode": @(self.areaCode)};
        return info;
    }
    return nil;
}

@end
