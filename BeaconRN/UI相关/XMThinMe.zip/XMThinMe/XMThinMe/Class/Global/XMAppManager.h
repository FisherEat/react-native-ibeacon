//
//  CJAppManager.h
//  CJSX
//
//  Created by 何振东 on 14-4-16.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  本类的职责为管理app中的全局功能。如程序配置信息等。
 */
@interface XMAppManager : NSObject 
/**
 *  控制器的单例实现，由于本类的功能为全局实现，所以采用单例模式。
 *
 *  @return AppManager单例对象
 */
+ (instancetype)sharedInstance;

/**
 *  返回设备类型
 */
+ (OOSPlatform)platform;

/**
 *  配置程序初始默认参数
 */
- (void)configureInitialDefaultParams;



@end
