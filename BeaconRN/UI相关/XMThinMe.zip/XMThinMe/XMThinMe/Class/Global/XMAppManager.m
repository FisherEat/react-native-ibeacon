//
//  CJAppManager.m
//  CJSX
//
//  Created by 何振东 on 14-4-16.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import "XMAppManager.h"
#import "XMGuideVC.h"

@interface XMAppManager ()

@end

@implementation XMAppManager

+ (instancetype)sharedInstance
{
    static XMAppManager *manager = nil;
    if (!manager) {
        manager = [[XMAppManager alloc] init];
    }
    return manager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

+ (OOSPlatform)platform
{
    if (mIsPad) {
        return OiPad;
    }
    return OiPhone;
}

- (void)configureInitialDefaultParams
{
    /// 如果程序为第一次运行，配置相关参数
    if (![mUserDefaults boolForKey:mFirstRun]) {
        [mUserDefaults setBool:YES forKey:kReceiveNotificationKey];
        [mUserDefaults setBool:YES forKey:kReceiveNotificationWithSoundKey];
        [mUserDefaults setBool:YES forKey:kReceiveNotificationWithVibrateKey];
        [mUserDefaults setBool:YES forKey:mFirstRun];
        [mUserDefaults synchronize];
        
        [self bk_performBlock:^(id obj) {
            [mKeyWindow.rootViewController presentViewController:[[XMGuideVC alloc] init] animated:YES completion:nil];
        } afterDelay:0.3];
    }
}



@end
