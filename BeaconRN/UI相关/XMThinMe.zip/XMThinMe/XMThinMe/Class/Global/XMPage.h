//
//  CJPage.h
//  CJSX
//
//  Created by 何振东 on 14-5-29.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  分页对象，在所有需要分页的请求体中调用。
 */
@interface XMPage : NSObject
/// 分页索引，初始默认值为0
@property (assign, nonatomic) NSInteger pageIndex;
/// 每条记录的条数，默认值为10
@property (assign, nonatomic) NSInteger pageSize;
/// 总页数，由后台返回
@property (assign, nonatomic) NSInteger pageCount;

@end
