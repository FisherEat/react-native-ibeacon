//
//  XMNearbyBeacon.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^DelayTimerFinishedBlock) (void);

/**
 *  管理最近的一颗基站，统计用户在该基站附近停留时间等
 */
@interface XMNearbyBeaconManager : NSObject
/// 基本参数，自动计算得来
@property (assign, nonatomic, readonly) long long start_time;
@property (assign, nonatomic, readonly) long long end_time;
@property (strong, nonatomic, readonly) NSString       *web_id;

/// 计算用户在某一个基站附近逗留的时间
- (void)startCalculateResidenceTimeForWeb:(NSString *)webId;

/// 控制延时器
- (void)startDelayTimerFinished:(DelayTimerFinishedBlock)finished;
- (void)stopDelayTimer;

/// 将数据发送到服务器
- (void)sendBeaconToService;

@end
