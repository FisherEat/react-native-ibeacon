//
//  XMImageBrowseVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/25.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMImageBrowseVC.h"
#import "XMImage.h"
#import "XMImageCell.h"

static NSString *const cellIdentifier = @"imageCell";

@interface XMImageBrowseVC () <GalleryViewDelegate>
@property (assign, nonatomic) NSInteger pageIndex;
@property (strong, nonatomic) NSMutableArray *images;

@end



@implementation XMImageBrowseVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.images = @[].mutableCopy;
    self.pageIndex = 0;
    self.title = self.product.product_name ? self.product.product_name : self.beaconDetail.title_1;
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[XMImageCell class] forCellReuseIdentifier:cellIdentifier];
    
    [self requestImageList];
}


#pragma mark - network request

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.images.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMImage *image = self.images[indexPath.row];
    if (image.height == 0 || image.width == 0) {
        return 200;
    }
    CGFloat height = (self.view.width-20) * (image.height/image.width);
    return height + 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    XMImage *image = self.images[indexPath.row];
    [cell.thumbIV setImageWithURL:[NSURL URLWithString:image.picture_url] placeholderImage:kPlaceholderImage_rectangle];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSMutableArray *imageUrls = @[].mutableCopy;
    for (XMImage *image in self.images) {
        [imageUrls addObject:image.picture_url];
    }
    GalleryView *galleryView = [[GalleryView alloc] initWithFrame:mKeyWindow.bounds];
    [galleryView setImageUrls:imageUrls];
    galleryView.delegate = self;
    galleryView.alpha = 0;
    [mKeyWindow addSubview:galleryView];
    
    [UIView animateWithDuration:0.75 animations:^{
        galleryView.alpha = 1;
    }];
}


#pragma mark - galleryview delegate

- (void)galleryView:(GalleryView *)galleryView didSelectPageAtIndex:(NSInteger)pageIndex
{
    [UIView animateWithDuration:0.45 animations:^{
        galleryView.alpha = 0.0;
    } completion:^(BOOL finished) {
        [galleryView removeFromSuperview];
    }];
}


#pragma mark - network request

- (void)requestImageList
{
    mWeakSelf;

    NSMutableDictionary *params = @{@"device_type": @([XMAppManager platform]),
                                    @"user_id": [XMUserManager sharedInstance].userId,
                                    @"page_size": @"10",
                                    @"page_index": @(self.pageIndex)}.mutableCopy;
    NSString *path = N_Product_GetEntityPictureList;
    if (self.product.product_id) {
        params[@"product_id"] = self.product.product_id;
    } else if (self.beaconDetail.template_examples_id){
        params[@"template_examples_id"] = self.beaconDetail.template_examples_id;
        path = N_TemplateExamples_GetEntityPictureList;
    } else {
        return;
    }
    
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    [[OURLRequest sharedInstance] postForPath:path withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         if (!error) {
             for (NSDictionary *dict in data) {
                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                 XMImage *image = [[XMImage alloc] initWithJSONData:objectData];
                 [weakSelf.images addObject:image];
             }
             [weakSelf.tableView reloadData];
         }
     }];
}



@end
