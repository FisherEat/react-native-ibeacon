//
//  XMImageBrowseVC.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/25.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OViewController.h"
#import "XMProduct.h"
#import "XMBeaconDetail.h"

@interface XMImageBrowseVC : UITableViewController
@property (strong, nonatomic) XMProduct *product;
@property (strong, nonatomic) XMBeaconDetail *beaconDetail;

@end
