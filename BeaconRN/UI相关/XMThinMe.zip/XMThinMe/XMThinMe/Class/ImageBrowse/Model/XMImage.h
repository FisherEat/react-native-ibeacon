//
//  XMShopImage.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/13.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMImage : NSObject
@property (copy, nonatomic) NSString *picture_id;
@property (copy, nonatomic) NSString *picture_name;
@property (copy, nonatomic) NSString *picture_url;

@property (assign, nonatomic) CGFloat width;
@property (assign, nonatomic) CGFloat height;


@end
