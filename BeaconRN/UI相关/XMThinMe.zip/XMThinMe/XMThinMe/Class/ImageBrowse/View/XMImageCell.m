//
//  XMImageCell.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/26.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMImageCell.h"

@implementation XMImageCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSeparatorStyleNone;
        
        self.thumbIV = [[OImageView alloc] init];
        self.thumbIV.cornerRadius = 4;
        [self.contentView addSubview:self.thumbIV];
        self.seprator.hidden = YES;
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.thumbIV.frame = CGRectMake(10, 5, self.width - 20, self.height - 10);
}

@end
