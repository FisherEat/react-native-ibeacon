//
//  XMFootprintCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/15.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMFootprintCell.h"

@interface XMFootprintCell ()
@property (strong, nonatomic) UILabel *dateLbl;

@end

@implementation XMFootprintCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier];
    if (self) {
        self.backgroundColor = kClearColor;
        self.contentView.backgroundColor = kClearColor;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.verticalLineView = [[UIView alloc] initWithFrame:CGRectMake(20, 0, 2, 160)];
        self.verticalLineView.backgroundColor = mRGB(186, 186, 186);
//        [self.contentView addSubview:self.verticalLineView];
        
        self.largeDotView = [[UIView alloc] initWithFrame:CGRectMake(self.verticalLineView.centerX - 10, 35, 20, 20)];;
        self.largeDotView.backgroundColor = mRGB(232, 232, 232);
        self.largeDotView.cornerRadius = self.largeDotView.width/2;
        self.largeDotView.layer.borderColor = mRGB(255, 162, 0).CGColor;
        self.largeDotView.layer.borderWidth = 3;
        [self.contentView addSubview:self.largeDotView];
        
        self.smallDotView = [[UIView alloc] initWithFrame:CGRectMake(self.largeDotView.right + 11, self.largeDotView.centerY - 2.5, 5, 5)];
        self.smallDotView.backgroundColor = kOrangeColor;
        self.smallDotView.cornerRadius = self.smallDotView.width / 2;
        [self.contentView addSubview:self.smallDotView];
        
        self.horizontalLineView = [[UIView alloc] initWithFrame:CGRectMake(self.largeDotView.right, self.largeDotView.centerY - 0.5, self.smallDotView.x - self.largeDotView.right, 1)];
        self.horizontalLineView.backgroundColor = mRGB(186, 186, 186);
        [self.contentView addSubview:self.horizontalLineView];
        
        self.container = [[UIView alloc] initWithFrame:CGRectMake(self.verticalLineView.right + 10, self.largeDotView.bottom + 8, self.width - self.verticalLineView.right- 25, 90)];
        self.container.backgroundColor = kWhiteColor;
        self.container.cornerRadius = 6;
        [self.contentView addSubview:self.container];
        
        self.titleLbl = [[OLabel alloc] initWithFrame:CGRectMake(10, 20, self.container.width - 20, 20)];
        self.titleLbl.font = kFont(16);
        self.titleLbl.textColor = mRGBToColor(0x4b4b4b);
        [self.container addSubview:self.titleLbl];
        
        self.detailLbl = [[OLabel alloc] initWithFrame:CGRectMake(self.titleLbl.x, self.titleLbl.bottom, self.titleLbl.width, self.container.height - self.titleLbl.bottom - 10)];
        self.detailLbl.textColor = mRGB(159, 159, 159);
        self.detailLbl.numberOfLines = 2;
        self.detailLbl.font = kFont(14);
        [self.container addSubview:self.detailLbl];
        
        self.thumbIV = [[UIImageView alloc] initWithFrame:CGRectMake(self.smallDotView.right + 5, 15, 90, 60)];
        self.thumbIV.cornerRadius = 4;
        [self.thumbIV setBoderColor:mRGBToColor(0xe8e8e8) width:0.5];
        [self.contentView addSubview:self.thumbIV];

        self.readStateView = [[UIView alloc] initWithFrame:CGRectMake(self.thumbIV.right - 10, self.thumbIV.y - 10, 20, 20)];;
        self.readStateView.backgroundColor = kRedColor;
        self.readStateView.cornerRadius = self.readStateView.width/2;
        self.readStateView.layer.borderColor = kWhiteColor.CGColor;
        self.readStateView.layer.borderWidth = 1;
        [self.contentView addSubview:self.readStateView];
        
        self.timeLbl = [[OLabel alloc] initWithFrame:CGRectMake(self.thumbIV.right + 10, self.thumbIV.centerY - 20, 60, 25)];
        self.timeLbl.font = kFont(13);
        self.timeLbl.textColor = mRGB(75, 75, 75);
        [self.contentView addSubview:self.timeLbl];
        
        self.dateLbl = [[OLabel alloc] initWithFrame:CGRectMake(self.container.right - 50, self.thumbIV.centerY - 30, 50, 35)];
        self.dateLbl.cornerRadius = 4;
        self.dateLbl.textAlignment = NSTextAlignmentCenter;
        self.dateLbl.textColor = kBlackColor;
        self.dateLbl.backgroundColor = kWhiteColor;
        [self.contentView addSubview:self.dateLbl];
        
        self.seprator.hidden = YES;
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.verticalLineView.height = self.height;
    [self.dateLbl sizeToFit];
    self.dateLbl.width = self.dateLbl.width + 10;
    self.dateLbl.x = self.container.right - self.dateLbl.width;
}

- (void)configureCellWithCellData:(XMBeacon *)beacon
{
    self.titleLbl.text = beacon.title;
    self.detailLbl.text = beacon.description;
    [self.thumbIV setImageWithURL:[NSURL URLWithString:beacon.img_url] placeholderImage:kPlaceholderImage_rectangle];
    NSDate *updateDate = [NSDate dateWithTimeIntervalSince1970:beacon.last_update_date];
    NVDate *updateDateNV = [[NVDate alloc] initUsingDate:updateDate];

    NVDate *todayDate = [[NVDate alloc] initUsingToday];
    NSString *todyStr = [todayDate stringValueWithFormat:@"YY-MM-dd"];
    NSString *preTodayStr = [[todayDate previousDay] stringValueWithFormat:@"YY-MM-dd"];
    NSString *dateStr = [updateDateNV stringValueWithFormat:@"YY-MM-dd"];
    if ([dateStr isEqualToString:todyStr]) {
        self.dateLbl.text = @"今天";
    } else if ([dateStr isEqualToString:preTodayStr]) {
        self.dateLbl.text = @"昨天";
    } else {
        self.dateLbl.text = dateStr;
    }
    
    self.timeLbl.text = [updateDateNV stringValueWithFormat:@"HH:mm"];
    self.readStateView.hidden = beacon.readed;
}


@end
