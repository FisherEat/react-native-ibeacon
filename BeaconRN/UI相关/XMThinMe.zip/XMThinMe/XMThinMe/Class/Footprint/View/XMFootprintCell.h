//
//  XMFootprintCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/15.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"
#import "XMBeacon.h"

@interface XMFootprintCell : OCell
@property (strong, nonatomic) UIView      *largeDotView;
@property (strong, nonatomic) UIView      *smallDotView;
@property (strong, nonatomic) UIView      *verticalLineView;
@property (strong, nonatomic) UIView      *horizontalLineView;
@property (strong, nonatomic) UIImageView *thumbIV;
@property (strong, nonatomic) OLabel      *timeLbl;
@property (strong, nonatomic) UIView      *container;
@property (strong, nonatomic) OLabel      *titleLbl;
@property (strong, nonatomic) OLabel      *detailLbl;

@property (strong, nonatomic) UIView      *readStateView;

@end
