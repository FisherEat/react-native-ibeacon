//
//  XMFootprintVC.m
//  XMMuseum
//
//  Created by 何振东 on 14-6-25.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMFootprintVC.h"
#import "XMFootprintCell.h"
#import "XMShop.h"
#import "XMExhibitionShopVC.h"
#import "XMTripSpotDetailVC.h"
#import "XMTripVC.h"
#import "XMTripLayout.h"

static NSString *const kCellIdentifier = @"footprintCell";

@interface XMFootprintVC () <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) NSMutableArray *tableData;

@end

@implementation XMFootprintVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"我的足迹";
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] bk_initWithTitle:@"清除" style:0 handler:^(id sender) {
            [[XMDBManager sharedInstance] deleteAllBeacons];
            self.tableData = nil;
            [self.tableView reloadData];
        }];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIView *bgView = [[UIView alloc] initWithFrame:self.view.bounds];    
    UIView *verticalLineView = [[UIView alloc] initWithFrame:CGRectMake(20, 0, 2, bgView.height+40)];
    verticalLineView.backgroundColor = mRGB(186, 186, 186);
    [bgView addSubview:verticalLineView];
    self.tableView.backgroundView = bgView;
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = mRGB(232, 232, 232);
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.tableData = [[XMDBManager sharedInstance] allBeaconList].mutableCopy;
    [self.tableView reloadData];
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.tableData.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 170;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMFootprintCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier];
    if (!cell) {
        cell = [[XMFootprintCell alloc] initWithStyle:0 reuseIdentifier:kCellIdentifier];
    }
    [cell configureCellWithCellData:self.tableData[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    XMBeacon *beacon = self.tableData[indexPath.row];
    [[XMDBManager sharedInstance] setRead:YES forWBeaconId:beacon.beacon_id];
    XMShop *shop = [[XMShop alloc] init];
    shop.shop_id = beacon.shop_id;
    shop.shop_name = beacon.title;
    shop.description = beacon.description;
    if (beacon.type == XMBeaconTypeTrip) {
        XMTripVC *tripVC = [[XMTripVC alloc] initWithCollectionViewLayout:[[XMTripLayout alloc] init]];
        tripVC.shop = shop;
        tripVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:tripVC animated:YES];
    } else {
        XMExhibitionShopVC *exhibitionDetailVC = [[XMExhibitionShopVC alloc] init];
        exhibitionDetailVC.shop = shop;
        exhibitionDetailVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:exhibitionDetailVC animated:YES];
    }
}

@end
