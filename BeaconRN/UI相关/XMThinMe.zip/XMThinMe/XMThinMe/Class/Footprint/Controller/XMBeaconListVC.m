//
//  XMBeaconListVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/7/14.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMBeaconListVC.h"

@interface XMBeaconListVC ()

@end

@implementation XMBeaconListVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        self.title = @"基站列表";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImageView *bgImgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    bgImgView.image = [UIImage imageNamed:@"home_background1"];
    [self.view insertSubview:bgImgView atIndex:0];

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"beaconCell"];
    self.tableView.backgroundColor = kClearColor;
    self.tableView.separatorInset = UIEdgeInsetsZero;
    
    [XMBeaconManager sharedBeacon].allBeacons = ^(NSArray *beacons) {
        self.beacons = beacons;
        [self.tableView reloadData];
    };
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.beacons.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"beaconCell" forIndexPath:indexPath];
    CLBeacon *beacon = self.beacons[indexPath.row];
    NSString *str = [NSString stringWithFormat:@"minor:%@  distance:%.2fm  rssi:%zd", beacon.minor, beacon.accuracy, beacon.rssi];
    if (beacon.accuracy < 0) {
         str = [NSString stringWithFormat:@"minor:%@  distance:unknown  rssi:%zd", beacon.minor, beacon.rssi];
    }
    cell.textLabel.text = str;
    cell.backgroundColor = kClearColor;
    cell.contentView.backgroundColor = kContentBgColor;
    cell.textLabel.textColor = kWhiteColor;
    cell.textLabel.adjustsFontSizeToFitWidth = YES;
    if (indexPath.row == 0) {
        cell.textLabel.textColor = kRedColor;
    }

    return cell;
}




@end
