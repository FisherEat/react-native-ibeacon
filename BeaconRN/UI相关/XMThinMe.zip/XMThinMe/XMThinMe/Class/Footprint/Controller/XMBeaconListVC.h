//
//  XMBeaconListVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/7/14.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMBeaconListVC : UITableViewController
@property (strong, nonatomic) NSArray *beacons;

@end
