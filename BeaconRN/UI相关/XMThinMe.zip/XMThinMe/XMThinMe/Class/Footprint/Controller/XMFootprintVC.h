//
//  XMFootprintVC.h
//  XMMuseum
//
//  Created by 何振东 on 14-6-25.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"

/**
 *  浏览过的beacon信息记录
 */
@interface XMFootprintVC : UITableViewController

@end
