//
//  XMMyCollectionVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMMyCollectionVC.h"
#import "XMMyCollectionCell.h"
#import "XMShop.h"
#import "XMExhibitionShopVC.h"

@interface XMMyCollectionVC ()
@property (strong, nonatomic) NSMutableArray *shopArray;

@end

@implementation XMMyCollectionVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"关注";
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_collection_normal"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_collection_highlighted"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self getEntityAttentionList];
}


#pragma mark - delegate && datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.shopArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"myCollectionCell";
    XMMyCollectionCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMMyCollectionCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    [cell configureCellWithCellData:self.shopArray[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    XMExhibitionShopVC *exhibitionDetailVC = [[XMExhibitionShopVC alloc] init];
    exhibitionDetailVC.shop = self.shopArray[indexPath.row];
    exhibitionDetailVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:exhibitionDetailVC animated:YES];
}


#pragma mark - network request

- (void)getEntityAttentionList
{
    mWeakSelf;
    NSDictionary *params = @{@"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_User_GetEntityAttentionList withParams:params completionHandler:^(id data, NSError *error)
     {
         self.shopArray = nil;
         self.shopArray = @[].mutableCopy;

         for (NSDictionary *dict in data) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
             XMShop *shop = [[XMShop alloc] initWithJSONData:objectData];
             [weakSelf.shopArray addObject:shop];
         }
         [weakSelf.tableView reloadData];
     }];
}


@end
