//
//  XMMyCollectionCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMMyCollectionCell.h"
#import "XMShop.h"

@implementation XMMyCollectionCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.height = 80;
        
        UIView *boxView = [[UIView alloc] initWithFrame:CGRectMake(10, (self.height - 60)/2, 90, 60)];
        boxView.clipsToBounds = YES;
        [boxView setBoderColor:mRGBToColor(0xe8e8e8) width:0.5];
        boxView.cornerRadius = 4;
        [self.contentView addSubview:boxView];
        
        self.thumbIV = [[OImageView alloc] initWithFrame:boxView.bounds];
        [boxView addSubview:self.thumbIV];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kFont(16);
        [self.contentView addSubview:self.titleLbl];
        
        self.addressLbl = [[OLabel alloc] init];
        self.addressLbl.textColor = mRGBToColor(0xa4a4a4);
        self.addressLbl.font = kFont(14);
        [self.contentView addSubview:self.addressLbl];
        
        self.titleLbl.frame = CGRectMake(boxView.right + 10, 10, self.width - boxView.right - 15, 30);
        self.addressLbl.frame = CGRectMake(self.titleLbl.x, self.titleLbl.bottom + 5, self.titleLbl.width, 20);
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
}

- (void)configureCellWithCellData:(XMShop *)shop
{
    NSURL *imgUrl = [NSURL URLWithString:shop.logo_url];
    NSURLRequest *request = [NSURLRequest requestWithURL:imgUrl];
    __weak UIImageView *iv = self.thumbIV;
    [self.thumbIV setImageWithURLRequest:request placeholderImage:kPlaceholderImage_rectangle success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
        iv.image = image;
        CGFloat height = iv.width * (image.size.height / image.size.width);
        if (height > iv.height) {
            iv.frame = CGRectMake(0, -(height - iv.height)/2, iv.width, height);
        } else {
            CGFloat width = iv.height * (image.size.width / image.size.height);
            iv.frame = CGRectMake(-(width - iv.width)/2, 0, width, iv.height);
        }
    } failure:nil];
    
    self.titleLbl.text = shop.shop_name;
    self.addressLbl.text = shop.address;
}

@end
