//
//  XMMyCollectionCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"

@interface XMMyCollectionCell : OCell
@property (strong, nonatomic) OImageView *thumbIV;
@property (strong, nonatomic) OLabel     *titleLbl;
@property (strong, nonatomic) OLabel     *addressLbl;

@end
