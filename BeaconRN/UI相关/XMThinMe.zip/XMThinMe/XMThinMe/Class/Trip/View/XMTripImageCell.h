//
//  XMTripImageCell.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMTripImageCell : UICollectionReusableView <UIScrollViewDelegate>
@property (strong, nonatomic) UIScrollView  *scrollView;
@property (strong, nonatomic) OLabel        *titleLbl;
@property (strong, nonatomic) UIPageControl *pageControl;

@end
