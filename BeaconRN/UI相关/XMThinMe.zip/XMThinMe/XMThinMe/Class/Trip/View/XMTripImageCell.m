//
//  XMTripImageCell.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripImageCell.h"

@interface XMTripImageCell ()
@property (strong, nonatomic) NSArray *images;

@end

@implementation XMTripImageCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:(CGRect)frame];
    if (self) {
        self.backgroundColor = kWhiteColor;
        
        self.scrollView = [[UIScrollView alloc] init];
        self.scrollView.showsHorizontalScrollIndicator = NO;
        self.scrollView.pagingEnabled = YES;
        self.scrollView.bounces = NO;
        self.scrollView.delegate = self;
        [self addSubview:self.scrollView];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
        self.titleLbl.textColor = kWhiteColor;
        [self addSubview:self.titleLbl];
        
        self.pageControl = [[UIPageControl alloc] init];
        [self addSubview:self.pageControl];
    }
    return self;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat   pageWidth   = scrollView.frame.size.width;
    NSInteger currentPage = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.pageControl.currentPage = currentPage;
//    XMAdvertise *advertise = self.advertises[currentPage];
//    self.titleLbl.text = [NSString stringWithFormat:@"  %@", advertise.advertise_title];
}

- (void)configureViewWithData:(NSArray *)images
{
    self.images = images;
    self.height = 200;
    self.scrollView.frame = self.bounds;
    self.titleLbl.frame = CGRectMake(0, self.height - 25, self.width, 25);
    self.pageControl.frame = CGRectMake(self.width - 60, self.titleLbl.y, 60, 25);
    
    for (UIView *view in self.scrollView.subviews) {
        [view removeFromSuperview];
    }
    
    for (int i = 0; i < images.count; i++) {
//        XMAdvertise *advertise = advertises[i];
        CGRect rect = CGRectMake(self.scrollView.width * i, 0, self.scrollView.width, self.scrollView.height);
//        NSURL *imgUrl = [NSURL URLWithString:advertise.picture_url];
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:rect];
        imgView.image = [UIImage imageNamed:@"home_top_bg"];
//        [imgView setImageWithURL:imgUrl placeholderImage:kPlaceholderImage_rectangle];
        [self.scrollView addSubview:imgView];
    }
//    XMAdvertise *advertise = [self.advertises firstObject];
//    self.titleLbl.text = [NSString stringWithFormat:@"  %@", advertise.advertise_title];
    
    self.pageControl.numberOfPages = images.count;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.width * images.count, self.scrollView.height);
}

@end
