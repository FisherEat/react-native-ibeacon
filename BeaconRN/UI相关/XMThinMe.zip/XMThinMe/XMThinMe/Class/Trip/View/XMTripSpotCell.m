//
//  XMTripCell.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripSpotCell.h"
#import "XMProduct.h"

@implementation XMTripSpotCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView.backgroundColor = kWhiteColor;
        self.contentView.cornerRadius = 2;
        
        self.thumbIV = [[OImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height - 40)];;
        self.thumbIV.image = [UIImage imageNamed:@"home_message_bg"];
        [self.contentView addSubview:self.thumbIV];
        
        self.titleLbl = [[OLabel alloc] initWithFrame:CGRectMake(10, self.thumbIV.bottom, self.width/2, self.height - self.thumbIV.bottom)];
        self.titleLbl.font = kFont(14);
        [self.contentView addSubview:self.titleLbl];
        
        self.readTimesLbl = [[OLabel alloc] initWithFrame:CGRectMake(self.titleLbl.right, self.titleLbl.y, self.width - self.titleLbl.right-10, self.titleLbl.height)];
        self.readTimesLbl.textColor = kGrayColor;
        self.readTimesLbl.font = kFont(12);
        self.readTimesLbl.text = @"浏览(932)";
        self.readTimesLbl.adjustsFontSizeToFitWidth = YES;
        self.readTimesLbl.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:self.readTimesLbl];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.thumbIV.frame = CGRectMake(0, 0, self.width, self.height - 40);
    self.titleLbl.frame = CGRectMake(5, self.thumbIV.bottom, self.width/2, self.height - self.thumbIV.bottom);
    self.readTimesLbl.frame = CGRectMake(self.titleLbl.right, self.titleLbl.y, self.width - self.titleLbl.right-10, self.titleLbl.height);
}

- (void)configureViewWithData:(XMProduct *)product
{
    self.titleLbl.text = product.product_name;
    NSURL *imgUrl = [NSURL URLWithString:product.image_url];
    [self.thumbIV setImageWithURL:imgUrl placeholderImage:kPlaceholderImage_rectangle];
}

@end
