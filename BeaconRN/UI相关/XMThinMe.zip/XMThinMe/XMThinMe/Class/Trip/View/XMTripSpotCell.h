//
//  XMTripCell.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMTripSpotCell : UICollectionViewCell
@property (strong, nonatomic) OImageView *thumbIV;
@property (strong, nonatomic) OLabel *titleLbl;
@property (strong, nonatomic) OLabel *readTimesLbl;

@end
