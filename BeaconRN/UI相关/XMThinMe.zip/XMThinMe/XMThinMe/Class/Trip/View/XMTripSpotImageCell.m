//
//  XMTripSpotImageCell.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripSpotImageCell.h"

@implementation XMTripSpotImageCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.thumbIV = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:self.thumbIV];
        
        self.moreBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.moreBtn setTitle:@"更多" forState:UIControlStateNormal];
        [self.moreBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        self.moreBtn.titleLabel.font = kFont(14);
        self.moreBtn.cornerRadius = 4;
        [self.moreBtn setBoderColor:kGrayColor width:1];
        self.moreBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 3, 0, 0);
        [self.moreBtn setImage:[UIImage imageNamed:@"exhibition_more"] forState:UIControlStateNormal];
        [self.contentView addSubview:self.moreBtn];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.thumbIV.frame = self.bounds;
    self.moreBtn.frame = CGRectMake(self.width - 60, self.height - 35, 55, 30);
}


@end
