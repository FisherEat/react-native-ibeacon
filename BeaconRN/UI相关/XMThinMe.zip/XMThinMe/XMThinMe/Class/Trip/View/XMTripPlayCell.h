//
//  XMTripPlayCell.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OCell.h"

@interface XMTripPlayCell : OCell
@property (strong, nonatomic) OButton *playBtn;
@property (strong, nonatomic) UISlider *slider;
@property (strong, nonatomic) OButton *volumeBtn;
@property (strong, nonatomic) OLabel *currentTimeLbl;
@property (strong, nonatomic) OLabel *endTimeLbl;

@property (strong, nonatomic) NSString *audioUrl;

@end
