//
//  XMTripPlayCell.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripPlayCell.h"

@implementation XMTripPlayCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.playBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.playBtn setImage:[UIImage imageNamed:@"play_normal"] forState:UIControlStateNormal];
        [self.playBtn setImage:[UIImage imageNamed:@"play_highlighted"] forState:UIControlStateHighlighted];
        [self.playBtn addTarget:self action:@selector(playAudio:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.playBtn];
        
        self.slider = [[UISlider alloc] init];
        self.slider.minimumTrackTintColor = kOrangeColor;
        self.slider.userInteractionEnabled = NO;
        [self.slider addTarget:self action:@selector(progressSliderValueChanged:) forControlEvents:UIControlEventValueChanged];
        [self.contentView addSubview:self.slider];
        
        self.volumeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.volumeBtn setImage:[UIImage imageNamed:@"volume_open"] forState:UIControlStateNormal];
        [self.contentView addSubview:self.volumeBtn];
        
        self.currentTimeLbl = [[OLabel alloc] init];
        self.currentTimeLbl.text = @"00:00";
        [self.contentView addSubview:self.currentTimeLbl];
        
        self.endTimeLbl = [[OLabel alloc] init];
        self.endTimeLbl.text = @"00:00";
        self.endTimeLbl.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:self.endTimeLbl];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.playBtn.frame = CGRectMake(10, (self.height - 65)/2, 65, 65);
    self.volumeBtn.frame = CGRectMake(self.width - 30 - 15, (self.height - 30)/2, 30, 30);
    self.slider.frame = CGRectMake(self.playBtn.right + 5, (self.height - 30)/2, self.volumeBtn.x - self.playBtn.right - 5 * 2, 30);
    self.currentTimeLbl.frame = CGRectMake(self.slider.x, self.slider.bottom, 120, 20);
    self.endTimeLbl.frame = CGRectMake(self.slider.right - self.currentTimeLbl.width, self.currentTimeLbl.y, self.currentTimeLbl.width, self.currentTimeLbl.height);
}

- (void)setAudioUrl:(NSString *)audioUrl
{
    _audioUrl = audioUrl;
    [AFSoundManager sharedManager].status = AFSoundManagerStatusStopped;
}

- (void)progressSliderValueChanged:(UISlider *)sender
{
    [[AFSoundManager sharedManager] moveToSection:sender.value/sender.maximumValue];
    if ([AFSoundManager sharedManager].status == AFSoundManagerStatusPaused) {
        [[AFSoundManager sharedManager] resume];
        [self.playBtn setImage:[UIImage imageNamed:@"zanting"] forState:UIControlStateNormal];
    }
}

- (void)playAudio:(UIButton *)sender
{
    if (!self.audioUrl) {
        return;
    }
    if ([AFSoundManager sharedManager].status == AFSoundManagerStatusPlaying) {
        [[AFSoundManager sharedManager] pause];
        [self.playBtn setImage:[UIImage imageNamed:@"play_normal"] forState:UIControlStateNormal];
        [self.playBtn setImage:[UIImage imageNamed:@"play_highlighted"] forState:UIControlStateHighlighted];
    }
    else if ([AFSoundManager sharedManager].status == AFSoundManagerStatusPaused) {
        [[AFSoundManager sharedManager] resume];
        [self.playBtn setImage:[UIImage imageNamed:@"pause_normal"] forState:UIControlStateNormal];
        [self.playBtn setImage:[UIImage imageNamed:@"pause_highlighted"] forState:UIControlStateNormal];
    }
    else {
        [[AFSoundManager sharedManager] startStreamingRemoteAudioFromURL:self.audioUrl andBlock:^(int percentage, CGFloat elapsedTime, CGFloat timeRemaining, NSError *error, BOOL finished) {
            [self.playBtn setImage:[UIImage imageNamed:@"pause_normal"] forState:UIControlStateNormal];
            [self.playBtn setImage:[UIImage imageNamed:@"pause_highlighted"] forState:UIControlStateNormal];

            CGFloat totalTime = elapsedTime + timeRemaining;
            NSString *endTime = [NSString timestampFromTimeDuration:totalTime];
            NSString *currentTime = [NSString timestampFromTimeDuration:elapsedTime];
            self.endTimeLbl.text = endTime;
            self.slider.maximumValue = totalTime;
            self.currentTimeLbl.text = currentTime;
            self.slider.value = (percentage/100.0) * totalTime;
            self.slider.userInteractionEnabled = YES;
        }];
    }
}



@end
