//
//  XMTripLayout.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripLayout.h"

@implementation XMTripLayout

- (id)init
{
    self = [super init];
    if (self) {
//        self.itemSize = CGSizeMake(mScreenWidth/2-8, 180);
//        self.scrollDirection = UICollectionViewScrollDirectionVertical;
//        self.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5);
//        self.minimumLineSpacing = 5;
//        self.minimumInteritemSpacing = 5;
    }
    return self;
}


@end
