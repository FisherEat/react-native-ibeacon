//
//  XMTripSpotDetailVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripSpotDetailVC.h"
#import "XMTripSpotImageCell.h"
#import "XMTripPlayCell.h"
#import "XMCommentCell.h"
#import "XMComment.h"
#import "XMCommentBar.h"
#import "XMBeaconDetail.h"
#import "XMImageBrowseVC.h"
#import "XMCommentVC.h"
#import "XMTripOverViewVC.h"

@interface XMTripSpotDetailVC () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
@property (strong, nonatomic) UITableView    *tableView;
@property (strong, nonatomic) NSMutableArray *comments;
@property (strong, nonatomic) XMCommentBar   *commentBar;
@property (assign, nonatomic) NSInteger      pageIndex;
@property (strong, nonatomic) XMBeaconDetail *beaconDetail;
@property (strong, nonatomic) NSArray        *storyList;

@end

@implementation XMTripSpotDetailVC


- (instancetype)init
{
    self = [super init];
    if (self) {
        mWeakSelf;
        XMSNSManager *snsManager = [[XMSNSManager alloc] init];
        __weak XMSNSManager *weakSNS = snsManager;
        snsManager.shareToFriendBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.beaconDetail.content_1 scene:0];
        };
        snsManager.shareToFriendSessionBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.beaconDetail.content_1 scene:1];
        };
        snsManager.collectToWeChatBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.beaconDetail.content_1 scene:2];
        };
        self.navigationItem.rightBarButtonItem = [snsManager shareBarButton];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = self.shop.shop_name;
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = mRGB(232, 232, 232);
    [self.view addSubview:self.tableView];
    
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    
    self.comments = @[].mutableCopy;
    self.storyList = @[].mutableCopy;
    
    mWeakSelf;
    self.commentBar = [[XMCommentBar alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 44)];
    self.commentBar.commentTF.delegate = self;
    self.commentBar.commentTF.bk_shouldReturnBlock = ^(UITextField *tf){
        [tf resignFirstResponder];
        [weakSelf sendComent:tf.text completion:^(BOOL success, XMComment *comment) {
            if (success) {
                tf.text = @"";
                [XMProgressHUD showTips:@"评论成功！" atView:weakSelf.view];
                [weakSelf.comments insertObject:comment atIndex:0];
                [weakSelf.tableView reloadData];
            } else {
                [XMProgressHUD showTips:@"评论失败！" atView:weakSelf.view];
            }
        }];
        return YES;
    };
    NSLog(@"ff:%@", self.navigationController.navigationBar);
    [self requestCommentList];
    [self getTempleInfo];
    
    [mNotificationCenter addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [mNotificationCenter addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    [[AFSoundManager sharedManager] stop];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGRect rect = CGRectMake(0, self.tableView.contentSize.height, self.tableView.width, self.tableView.height);
    [self.tableView scrollRectToVisible:rect animated:YES];
}


#pragma tableView Delegate && datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 2;
    } else if (section == 1) {
        return 1;
    } else if (section == 2) {
        return self.storyList.count;
    } else {
        return self.comments.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.0;
    }
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 3) {
        return 44;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (section == 3) {
        return self.commentBar;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            return 200;
        }
        return 85;
    } else if (indexPath.section == 1) {
        return [self.beaconDetail.content_1 heightForConstraintSize:CGSizeMake(self.view.width-20, 99999) font:kFont(14)] + 40;
    } else if (indexPath.section == 2) {
        return 44;
    } else {
        return [XMCommentCell cellHeightForCellData:self.comments[indexPath.row]];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 3) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.width, 44)];
        view.backgroundColor = mRGB(231, 231, 231);
        
        OLabel *lbl = [[OLabel alloc] initWithFrame:CGRectMake(10, 0, 100, 44)];
        lbl.text = @"热门评论";
        [view addSubview:lbl];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.backgroundColor = kOrangeColor;
        btn.cornerRadius = 4;
        btn.frame = CGRectMake(view.width - 65, 7, 60, 30);
        [btn setTitle:@"所有评论" forState:UIControlStateNormal];
        btn.titleLabel.font = kFont(12);
        [view addSubview:btn];
        
        mWeakSelf;
        [btn bk_addEventHandler:^(id sender) {
            [weakSelf.tableView endEditing:YES];

            XMCommentVC *comentVC = [[XMCommentVC alloc] init];
            comentVC.shop = weakSelf.shop;
            [weakSelf.navigationController pushViewController:comentVC animated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
        
        return view;
    }
    return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    NSArray *titles = @[@"", self.shop.shop_name, @"相关故事", @"热门评论"];
    return titles[section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            static NSString *identifier = @"tripSpotImageCell";
            XMTripSpotImageCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
            if (!cell) {
                mWeakSelf;
                cell = [[XMTripSpotImageCell alloc] initWithStyle:0 reuseIdentifier:identifier];
                [cell.moreBtn bk_addEventHandler:^(id sender) {
                    XMImageBrowseVC *imageBrowseVC = [[XMImageBrowseVC alloc] init];
                    imageBrowseVC.beaconDetail = weakSelf.beaconDetail;
                    [weakSelf.navigationController pushViewController:imageBrowseVC animated:YES];
                } forControlEvents:UIControlEventTouchUpInside];

            }
            NSURL *imgUrl = [NSURL URLWithString:self.shop.logo_url];
            [cell.thumbIV setImageWithURL:imgUrl placeholderImage:kPlaceholderImage_rectangle];

            return cell;
        }
        
        static NSString *identifier = @"tripPlayCell";
        XMTripPlayCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[XMTripPlayCell alloc] initWithStyle:0 reuseIdentifier:identifier];
        }
        cell.audioUrl = self.beaconDetail.audio_url;
        
        return cell;
    } else if (indexPath.section == 1) {
        static NSString *identifier = @"tripDetailCell";
        OCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[OCell alloc] initWithStyle:0 reuseIdentifier:identifier];
        }
        cell.textLabel.text = [NSString stringWithFormat:@"%@", self.beaconDetail.content_1];
        cell.textLabel.font = kFont(14);
        cell.textLabel.numberOfLines = 0;
        return cell;
    } else if (indexPath.section == 2) {
        static NSString *identifier = @"tripRelatedStoryCell";
        OCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[OCell alloc] initWithStyle:0 reuseIdentifier:identifier];
        }
        cell.textLabel.text = self.storyList[indexPath.row][@"template_examples_plate_name"];
        cell.textLabel.font = kFont(14);
        cell.textLabel.numberOfLines = 0;
        return cell;
    } else {
        static NSString *identifier = @"tripCommentCell";
        XMCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[XMCommentCell alloc] initWithStyle:0 reuseIdentifier:identifier];
        }
        [cell configureCellWithCellData:self.comments[indexPath.row]];
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 2) {
        NSDictionary *dict = self.storyList[indexPath.row];
        XMTripOverViewVC *overViewVC = [[XMTripOverViewVC alloc] init];
        overViewVC.showName = dict[@"template_examples_plate_name"];
        overViewVC.detail = dict[@"template_examples_plate_content"];
        [self.navigationController pushViewController:overViewVC animated:YES];
    }
}


#pragma mark - network request

- (void)requestCommentList
{
    if (!self.shop.shop_id) {
        return;
    }
    mWeakSelf;
    
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    NSDictionary *params = @{@"use_id": self.shop.shop_id,
                             @"device_type": @([XMAppManager platform]),
                             @"user_id": [XMUserManager sharedInstance].userId,
                             @"page_index": @(0),
                             @"page_size": @"3"};
    [[OURLRequest sharedInstance] postForPath:N_Product_GetEntityCommentList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

         for (NSDictionary *dict in data) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
             XMComment *comment = [[XMComment alloc] initWithJSONData:objectData];
             [weakSelf.comments addObject:comment];
         }
         NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:3];
         [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
     }];
}

- (void)sendComent:(NSString *)comment completion:(void (^) (BOOL success, XMComment *comment))completion
{
    if (!self.shop.shop_id || comment.length == 0) {
        return;
    }
    
    NSDictionary *params = @{@"use_id": self.shop.shop_id,
                             @"device_type": @([XMAppManager platform]),
                             @"user_id": [XMUserManager sharedInstance].userId,
                             @"comment_title": self.shop.shop_name,
                             @"comment_content": comment,
                             @"ip_address": @""};
    [[OURLRequest sharedInstance] postForPath:N_Product_AddEntityComment withParams:params completionHandler:^(id data, NSError *error)
     {
         if (error) {
             completion(NO, nil);
         } else {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:data options:0 error:nil];
             XMComment *comment = [[XMComment alloc] initWithJSONData:objectData];
             completion(YES, comment);
         }
     }];
}

- (void)getStoryListWithTemplateId:(NSString *)template_id
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    mWeakSelf;
    NSDictionary *params = @{@"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId,
                             @"template_examples_id": self.beaconDetail.template_examples_id,
                             @"page_index": @(0),
                             @"page_size": @"3"};
    [[OURLRequest sharedInstance] postForPath:N_TemplateExamples_GetEntityTemplateExamplesPlateList withParams:params completionHandler:^(NSArray *data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

         if (!error) {
             self.storyList = data;
             NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:2];
             [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
         }
     }];
}

- (void)getTempleInfo
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Shop_GetEntityTemplateExamplesDetailInfo withParams:params completionHandler:^(NSArray *data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         if (!error) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:[data firstObject] options:0 error:nil];
             weakSelf.beaconDetail = [[XMBeaconDetail alloc] initWithJSONData:objectData];
             NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:1];
             [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
         }
     }];
}



#pragma mark keyboard notification

- (void)keyboardWillShow:(NSNotification *)notification
{
    float animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGFloat keyboardHeight = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    mWeakSelf;
    [UIView animateWithDuration:animationDuration animations:^{
        weakSelf.tableView.contentInset = UIEdgeInsetsMake(0, 0, keyboardHeight, 0);
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    self.tableView.contentInset = UIEdgeInsetsMake(mNavHeight, 0, 0, 0);
}


@end
