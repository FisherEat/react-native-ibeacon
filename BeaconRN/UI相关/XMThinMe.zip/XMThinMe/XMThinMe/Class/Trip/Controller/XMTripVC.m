//
//  XMTripVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/11.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripVC.h"
#import "XMTripSpotCell.h"
#import "XMTripImageCell.h"
#import "XMShop.h"
#import "XMTripOverViewVC.h"
#import "XMMapVC.h"
#import "XMIndoorMapVC.h"
#import "XMTripSpotDetailVC.h"
#import "XMTripLayout.h"
#import "XMTripHeaderView.h"
#import "XMAdvertise.h"
#import "XMBeaconDetail.h"
#import "XMProduct.h"

@interface XMTripVC () <UICollectionViewDelegateFlowLayout, OWaterfallLayoutDelegate>
@property (strong, nonatomic) NSMutableArray *products;
@property (strong, nonatomic) XMTripHeaderView *headerView;
@property (strong, nonatomic) XMBeaconDetail *beaconDetail;
@property (assign, nonatomic) NSInteger pageIndex;

@end

@implementation XMTripVC

static NSString * const TripReuseIdentifier         = @"TripCell";
static NSString * const TripFunctionReuseIdentifier = @"TripFunctionCell";
static NSString * const TripImageReuseIdentifier    = @"TripImageCell";

- (instancetype)initWithCollectionViewLayout:(XMTripLayout *)layout
{
    self = [super initWithCollectionViewLayout:layout];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
        self.products = @[].mutableCopy;
        layout.delegate = self;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.collectionView.backgroundColor = mRGB(232, 232, 232);
    self.title = self.shop.shop_name;
    
    mWeakSelf;
    self.headerView = [[XMTripHeaderView alloc] initWithFrame:CGRectMake(0, -290, self.view.width, 290)];
    self.headerView.functionButtonClicked = ^(UIButton *sender) {
        if (sender.tag == TripFunctionButtonOverview) {
            XMTripOverViewVC *overviewVC = [[XMTripOverViewVC alloc] init];
            overviewVC.showName = weakSelf.beaconDetail.title_1;
            overviewVC.detail = weakSelf.beaconDetail.content_1;
            [weakSelf.navigationController pushViewController:overviewVC animated:YES];
        } else if (sender.tag == TripFunctionButtonLocation) {
            XMMapVC *mapVC = [[XMMapVC alloc] init];
            mapVC.shop = weakSelf.shop;
            [weakSelf.navigationController pushViewController:mapVC animated:YES];
        } else if (sender.tag == TripFunctionButtonIndoorMap) {
            XMIndoorMapVC *indoorMapVC = [[XMIndoorMapVC alloc] init];
//            indoorMapVC.sho = weakSelf.shop;
            [weakSelf.navigationController pushViewController:indoorMapVC animated:YES];
        }
    };
    [self.collectionView addSubview:self.headerView];
    
    self.collectionView.contentInset = UIEdgeInsetsMake(290, 0, 0, 0);
    self.collectionView.alwaysBounceVertical = YES;
    [self.collectionView registerClass:[XMTripImageCell class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:TripImageReuseIdentifier];
    [self.collectionView registerClass:[XMTripSpotCell class] forCellWithReuseIdentifier:TripReuseIdentifier];

    [self getTempleInfo];
    [self requestProductList];
    [self requestShopPictureList];
}


#pragma mark <UICollectionViewDataSource>

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
        return self.products.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    XMTripSpotCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:TripReuseIdentifier forIndexPath:indexPath];
    [cell configureViewWithData:self.products[indexPath.item]];
    
    return cell;
}

#pragma mark <UICollectionViewDelegate>

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    XMTripSpotDetailVC *detailVC = [[XMTripSpotDetailVC alloc] init];
    detailVC.shop = self.products[indexPath.item];
    [self.navigationController pushViewController:detailVC animated:YES];
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout heightForItemAtIndexPath:(NSIndexPath *)indexPath
{
    XMProduct *product = self.products[indexPath.item];
    if (product.height == 0 || product.width == 0) {
        return 200;
    }
    CGFloat height = (mScreenWidth/2 - 8) * (product.height/product.width);
    return height + 40;
}


#pragma mark - network request


#pragma mark - network request

- (void)requestShopPictureList
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId,
                             @"page_index": @(0),
                             @"page_size": @(10)};
    [[OURLRequest sharedInstance] postForPath:N_TemplateExamples_GetEntityPictureListByShopid withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         if (!error) {
             NSMutableArray *images = @[].mutableCopy;
             for (NSDictionary *dict in data) {
                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                 XMImage *image = [[XMImage alloc] initWithJSONData:objectData];
                 [images addObject:image];
             }
             [weakSelf.headerView configureViewWithData:images];
         }
     }];
}


- (void)getTempleInfo
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Shop_GetEntityTemplateExamplesDetailInfo withParams:params completionHandler:^(NSArray *data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         if (!error) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:[data firstObject] options:0 error:nil];
             weakSelf.beaconDetail = [[XMBeaconDetail alloc] initWithJSONData:objectData];
         }
     }];
}

- (void)requestProductList
{
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId,
                             @"page_index":@(self.pageIndex),
                             @"page_size":@(10)};
    [[OURLRequest sharedInstance] postForPath:N_Shop_GetEntityProductList withParams:params completionHandler:^(id data, NSError *error)
     {
         if (!error) {
             weakSelf.pageIndex++;
             for (NSDictionary *dict in data) {
                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                 XMProduct *product = [[XMProduct alloc] initWithJSONData:objectData];
                 [weakSelf.products addObject:product];
             }
             [weakSelf.collectionView reloadData];
         }
     }];
}









//- (void)getBusinessShopList
//{
//    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
//
//    mWeakSelf;
//    NSDictionary *params = @{@"business_id": self.business.business_id,
//                             @"device_type":@([XMAppManager platform]),
//                             @"user_id":[XMUserManager sharedInstance].userId};
//    [[OURLRequest sharedInstance] postForPath:N_Business_GetEntityShopList withParams:params completionHandler:^(id data, NSError *error)
//     {
//         [[XMProgressHUD sharedInstance] hideProgress];
//
//         for (NSDictionary *dict in data) {
//             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
//             XMShop *shop = [[XMShop alloc] initWithJSONData:objectData];
//             [weakSelf.shopArray addObject:shop];
//         }
//         
//         [weakSelf.collectionView reloadData];
//     }];
//}
//
//- (void)getBusinessAdvertiseList
//{
//    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
//
//    mWeakSelf;
//    NSDictionary *params = @{@"business_id": self.business.business_id,
//                             @"device_type": @([XMAppManager platform]),
//                             @"user_id": [XMUserManager sharedInstance].userId};
//    [[OURLRequest sharedInstance] postForPath:N_Business_GetEntityAdvertiseList withParams:params completionHandler:^(id data, NSError *error)
//     {
//         [[XMProgressHUD sharedInstance] hideProgress];
//
//         if (!error) {
//             NSMutableArray *advertiseArray = @[].mutableCopy;
//             for (NSDictionary *dict in data) {
//                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
//                 XMAdvertise *advertise = [[XMAdvertise alloc] initWithJSONData:objectData];
//                 [advertiseArray addObject:advertise];
//             }
//             [weakSelf.headerView configureViewWithData:advertiseArray];
//         }
//     }];
//}
//

@end
