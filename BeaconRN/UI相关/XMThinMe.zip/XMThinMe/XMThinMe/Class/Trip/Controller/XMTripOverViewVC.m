//
//  XMTripOverView.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMTripOverViewVC.h"

@interface XMTripOverViewVC ()
@property (strong, nonatomic) OTextView *textView;

@end

@implementation XMTripOverViewVC
@synthesize description;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = self.showName;
    
    self.textView = [[OTextView alloc] initWithFrame:CGRectMake(10, 0, self.view.width - 20, self.view.height)];
    self.textView.editable = NO;
    self.textView.showsVerticalScrollIndicator = NO;
    self.textView.text = self.detail;
    [self.view addSubview:self.textView];
}

@end