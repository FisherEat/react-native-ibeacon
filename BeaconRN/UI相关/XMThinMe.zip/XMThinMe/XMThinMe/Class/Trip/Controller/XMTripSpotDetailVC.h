//
//  XMTripSpotDetailVC.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OViewController.h"
#import "XMShop.h"

@interface XMTripSpotDetailVC : OViewController
@property (strong, nonatomic) XMShop *shop;

@end
