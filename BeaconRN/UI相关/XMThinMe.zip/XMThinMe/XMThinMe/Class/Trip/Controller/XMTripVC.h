//
//  XMTripVC.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/11.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMShop.h"

@interface XMTripVC : UICollectionViewController
@property (strong, nonatomic) XMShop *shop;

@end
