//
//  XMFile.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/16.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMFile : NSObject
@property (copy, nonatomic  ) NSString       *attachment_id;
@property (copy, nonatomic  ) NSString       *attachment_name;
@property (copy, nonatomic  ) NSString       *attachment_url;
@property (copy, nonatomic  ) NSString       *size;
@property (assign, nonatomic) NSTimeInterval upload_time;


/// 判断是否已下载
@property (copy, nonatomic) NSString *local_Path;

@end
