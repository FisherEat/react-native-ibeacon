//
//  XMSettingsCell1.m
//  XMMuseum
//
//  Created by 何振东 on 14-7-2.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMNotificationSettingsCell.h"

@implementation XMNotificationSettingsCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.accessoryType  = UITableViewCellAccessoryNone;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.textLabel.font = [UIFont systemFontOfSize:15];

        CGRect rect = CGRectMake(self.width - 70, 0, 60, 20);
        self.notificationSwitch = [[UISwitch alloc] initWithFrame:rect];
        self.notificationSwitch.backgroundColor = kWhiteColor;
        self.notificationSwitch.onTintColor = mRGB(34, 191, 100);
        self.notificationSwitch.cornerRadius = 15;
        self.notificationSwitch.centerY = self.centerY;
        [self.contentView addSubview:self.notificationSwitch];
    }
    return self;
}

@end
