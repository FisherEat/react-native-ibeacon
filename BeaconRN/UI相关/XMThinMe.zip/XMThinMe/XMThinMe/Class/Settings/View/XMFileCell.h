//
//  XMFileCell.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/14.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OCell.h"
#import "XMFile.h"

@interface XMFileCell : MGSwipeTableCell
@property (strong, nonatomic) OImageView *thumbIV;
@property (strong, nonatomic) OLabel     *titleLbl;
@property (strong, nonatomic) OLabel     *sizeLbl;
@property (strong, nonatomic) OLabel     *uploadDateLbl;
@property (strong, nonatomic) OButton    *downloadBtn;
@property (strong, nonatomic) UIActivityIndicatorView *indicatorView;

@property (strong, nonatomic, readonly) XMFile *file;

- (void)configureCellWithCellData:(XMFile *)file;

@end
