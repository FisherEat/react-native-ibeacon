//
//  XMLogoutView.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/12.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMLogoutView.h"

@implementation XMLogoutView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.autoresizesSubviews = YES;
        self.logoutBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.logoutBtn.frame = CGRectMake(35, 25, 200, 36);
        [self.logoutBtn setTitle:@"退出" forState:UIControlStateNormal];
//        self.logoutBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        self.logoutBtn.backgroundColor = [kRedColor colorWithAlphaComponent:0.8];
        self.logoutBtn.cornerRadius = 4;
        [self addSubview:self.logoutBtn];
    }
    return self;
}

@end
