//
//  XMUserHeaderView.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/7.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMUserInfoView.h"

@interface XMUserInfoView ()

@end

@implementation XMUserInfoView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kWhiteColor;
        
        self.avatarBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.avatarBtn.frame = CGRectMake((self.width - 65)/2, 50, 65, 65);
        [self.avatarBtn setImage:[UIImage imageNamed:@"user_avatar_placeholder"] forState:UIControlStateNormal];
        self.avatarBtn.cornerRadius = self.avatarBtn.width/2;
        [self.avatarBtn setBoderColor:kGrayColor width:1];
        [self addSubview:self.avatarBtn];
        
        self.usernameBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.usernameBtn.frame = CGRectMake((self.width - 120)/2, self.avatarBtn.bottom + 10, 120, 30);
        [self.usernameBtn setTitle:@"点击登录" forState:UIControlStateNormal];
        self.usernameBtn.titleLabel.font = kB_MiddleFont;
        self.usernameBtn.titleLabel.adjustsFontSizeToFitWidth = YES;
        [self addSubview:self.usernameBtn];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(10, self.height - 0.6, self.width - 20, 0.6)];;
        line.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.3];
        [self addSubview:line];
    }
    return self;
}




@end
