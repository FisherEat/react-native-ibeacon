//
//  XMFeedbackView.m
//  XMMuseum
//
//  Created by 何振东 on 14/7/14.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMFeedbackView.h"

@implementation XMFeedbackView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kWhiteColor;
        
        self.scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        self.scrollView.alwaysBounceVertical = YES;
        self.scrollView.delegate = self;
        [self addSubview:self.scrollView];
        
        CGRect rect = CGRectMake(10, -54, self.width - 10*2, 140);
        self.contentTV = [[OTextView alloc] initWithFrame:rect];
        self.contentTV.placeholder = @"请输入您的意见，以帮助我们改进产品，谢谢！";
        [self.contentTV setBoderColor:mRGB(160, 160, 160) width:0.5];
        self.contentTV.cornerRadius = 4;
        [self.scrollView addSubview:self.contentTV];
        
        rect = CGRectMake(self.contentTV.x, self.contentTV.bottom + 25, self.contentTV.width, 40);
        self.submitBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.submitBtn setTitle:@"提交" forState:UIControlStateNormal];
        self.submitBtn.frame = rect;
        self.submitBtn.titleLabel.font = kB_Font(17);
        [self.submitBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        self.submitBtn.backgroundColor = mRGB(160, 160, 160);
        self.submitBtn.cornerRadius = 6;
        [self.scrollView addSubview:self.submitBtn];
    }
    return self;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self endEditing:YES];
}

@end
