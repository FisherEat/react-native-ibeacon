//
//  XMFileCell.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/14.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMFileCell.h"

@interface XMFileCell () <UIActionSheetDelegate>
@property (strong, nonatomic) UIView       *seprator;
@property (strong, nonatomic) NSDictionary *fileThumbs;
@property (strong, nonatomic) XMFile       *file;

@end

@implementation XMFileCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.thumbIV = [[OImageView alloc] init];
        self.thumbIV.cornerRadius = 4;
        [self.contentView addSubview:self.thumbIV];
        
        self.indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        [self.contentView addSubview:self.indicatorView];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kB_Font(16);
        [self.contentView addSubview:self.titleLbl];
        
        self.sizeLbl = [[OLabel alloc] init];
        self.sizeLbl.textColor = kGrayColor;
        self.sizeLbl.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.sizeLbl];
        
        self.uploadDateLbl = [[OLabel alloc] init];
        self.uploadDateLbl.textColor = self.sizeLbl.textColor;
        [self.contentView addSubview:self.uploadDateLbl];
        
        self.downloadBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.downloadBtn setImage:[UIImage imageNamed:@"file_download"] forState:UIControlStateNormal];
        [self.contentView addSubview:self.downloadBtn];
                
        self.seprator = [[UIView alloc] init];
        self.seprator.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.3];
        [self.contentView addSubview:self.seprator];

        self.fileThumbs = @{@"doc": [UIImage imageNamed:@"file_doc"],
                            @"jpeg": [UIImage imageNamed:@"file_img"],
                            @"jpg": [UIImage imageNamed:@"file_img"],
                            @"png": [UIImage imageNamed:@"file_img"],
                            @"bmp": [UIImage imageNamed:@"file_img"],
                            @"pdf": [UIImage imageNamed:@"file_pdf"],
                            @"ppt": [UIImage imageNamed:@"file_ppt"],
                            @"sound": [UIImage imageNamed:@"file_sound"],
                            @"xml": [UIImage imageNamed:@"file_xls"],
                            @"unknow": [UIImage imageNamed:@"file_unknow"],
                        };
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.thumbIV.frame = CGRectMake(10, 10, 60, 60);
    self.indicatorView.frame = self.thumbIV.frame;
    self.titleLbl.frame = CGRectMake(self.thumbIV.right + 10, 10, self.width - self.thumbIV.right - 20, 30);
    self.sizeLbl.frame = CGRectMake(self.titleLbl.x, self.titleLbl.bottom + 10, 60, 20);
    self.uploadDateLbl.frame = CGRectMake(self.sizeLbl.right + 15, self.sizeLbl.y, 120, self.sizeLbl.height);
    self.downloadBtn.frame = CGRectMake(self.width - 40, self.uploadDateLbl.y, 40, self.uploadDateLbl.height);
    
    self.seprator.frame = CGRectMake(0, self.contentView.height - 0.5, self.contentView.width, 0.5);
    [self.contentView bringSubviewToFront:self.seprator];
}

- (void)configureCellWithCellData:(XMFile *)file
{
    self.file = file;
    
    NSString *suffix = [[file.attachment_url componentsSeparatedByString:@"."] lastObject];
    suffix = [[suffix componentsSeparatedByString:@"_"] firstObject];
    if ([self.fileThumbs.allKeys containsObject:suffix]) {
        self.thumbIV.image = self.fileThumbs[suffix];
    } else {
        self.thumbIV.image = self.fileThumbs[@"unknow"];
    }
    
    NSString *path = [NSString stringWithFormat:@"%@/%@.%@", kXM_Download_Dir, file.attachment_name, suffix];
    if (![[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:NO]) {
        [self.downloadBtn setImage:[UIImage imageNamed:@"file_download"] forState:UIControlStateNormal];
    } else {
        [self.downloadBtn setImage:[UIImage imageNamed:@"file_downloaded"] forState:UIControlStateNormal];
    }
    
    NSDate *uploadTime  = [NSDate dateWithTimeIntervalSince1970:file.upload_time];
    NSString *startStr = [[[NVDate alloc] initUsingDate:uploadTime] stringValueWithFormat:@"YYYY年MM月dd日"];

    self.titleLbl.text = file.attachment_name;
    self.sizeLbl.text = file.size;
    self.uploadDateLbl.text = startStr;
}

@end
