//
//  XMUserHeaderView.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/7.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OView.h"

/**
 *  侧边栏用户概要信息页
 */
@interface XMUserInfoView : UIView
/// 显示用户头像，登录后，点击进入用户个人信息
@property (strong, nonatomic) OButton *avatarBtn;
/// 用户名，未登录时，显示登录按钮，登录后，显示用户名
@property (strong, nonatomic) OButton *usernameBtn;

@end
