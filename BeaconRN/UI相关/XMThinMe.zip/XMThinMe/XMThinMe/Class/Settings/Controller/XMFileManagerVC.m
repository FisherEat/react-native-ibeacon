//
//  XMFileManagerVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/14.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMFileManagerVC.h"
#import "XMFileCell.h"
#import "XMReadFileVC.h"

@interface XMFileManagerVC () <UIActionSheetDelegate, GalleryViewDelegate>
@property (strong, nonatomic) NSArray *files;
@property (strong, nonatomic) XMFile *shareFile;

@end

@implementation XMFileManagerVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"文件管理";
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.files = [[XMDBManager sharedInstance] allFileList];
}


#pragma mark - delegate && datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.files.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 85;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"exhibitionNewsCell";
    XMFileCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        mWeakSelf;
        cell = [[XMFileCell alloc] initWithStyle:0 reuseIdentifier:identifier];
        MGSwipeButton *deleteBtn = [MGSwipeButton buttonWithTitle:nil icon:[UIImage imageNamed:@"file_delete"] backgroundColor:mRGB(225, 76, 77) callback:^BOOL(MGSwipeTableCell *sender) {
            [[XMDBManager sharedInstance] deleteFile:weakSelf.files[indexPath.row]];
            weakSelf.files = [[XMDBManager sharedInstance] allFileList];
            [tableView reloadData];

            return YES;
        }];
        deleteBtn.width = 85;
        MGSwipeButton *shareBtn = [MGSwipeButton buttonWithTitle:nil icon:[UIImage imageNamed:@"file_share"] backgroundColor:mRGB(251, 136, 50) callback:^BOOL(MGSwipeTableCell *sender) {
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"分享到..." delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"微信好友", @"微信朋友圈", @"收藏到微信", nil];
            [actionSheet showInView:mKeyWindow];
            
            XMFileCell *cell1 = (XMFileCell *)sender;
            weakSelf.shareFile = cell1.file;
            
            return YES;
        }];
        cell.rightButtons = @[deleteBtn, shareBtn];
    }
    [cell configureCellWithCellData:self.files[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    XMFile *file = self.files[indexPath.row];
    
    NSString *suffix = [[file.attachment_url componentsSeparatedByString:@"."] lastObject];
    suffix = [[suffix componentsSeparatedByString:@"_"] firstObject];
    NSString *path = [NSString stringWithFormat:@"%@/%@.%@", kXM_Download_Dir, file.attachment_name, suffix];
    [self showFile:path suffix:suffix];
}

- (void)showFile:(NSString *)path suffix:(NSString *)suffix
{
    NSString *type = @"jpg png jpeg";
    if ([type containString:suffix]) {
        UIImage *image = [UIImage imageWithContentsOfFile:path];
        if (image) {
            GalleryView *galleryView = [[GalleryView alloc] initWithFrame:mKeyWindow.bounds];
            galleryView.delegate = self;
            galleryView.alpha = 0;
            [galleryView setImages:@[image]];
            [mKeyWindow addSubview:galleryView];
            
            [UIView animateWithDuration:0.75 animations:^{
                galleryView.alpha = 1;
            }];
        } else {
            [XMProgressHUD showTips:@"文件不存在" atView:self.view];
        }
    } else {
        XMReadFileVC *readFileVC = [[XMReadFileVC alloc] init];
        readFileVC.filePath = path;
        [self.navigationController pushViewController:readFileVC animated:YES];
    }
}


#pragma mark - galleryview delegate

- (void)galleryView:(GalleryView *)galleryView didSelectPageAtIndex:(NSInteger)pageIndex
{
    [UIView animateWithDuration:0.45 animations:^{
        galleryView.alpha = 0.0;
    } completion:^(BOOL finished) {
        [galleryView removeFromSuperview];
    }];
}



@end
