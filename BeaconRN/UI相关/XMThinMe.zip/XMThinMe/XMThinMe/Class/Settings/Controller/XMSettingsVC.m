//
//  XMSettingsVC.m
//  XMMuseum
//
//  Created by 何振东 on 14-6-16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMSettingsVC.h"
#import "XMNotificationSettingsCell.h"
#import "XMFeedbackVC.h"
#import "XMAboutMeVC.h"
#import "XMLoginVC.h"
#import "XMUserInfoView.h"
#import "XMLogoutView.h"
#import "XMNotificationSettingsVC.h"
#import "OCheckUpdate.h"
#import "XMFileManagerVC.h"
#import "XMLaunchingVC.h"

static NSString *const kCellIdentifier = @"settingCell";


@interface XMSettingsVC () <UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate>
@property (strong, nonatomic) NSArray     *titles;
@property (strong, nonatomic) UITableView *tableView;

@property (strong, nonatomic) UIImage *avatar;

@end

@implementation XMSettingsVC

- (id)init
{
    self = [super init];
    if (self) {
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_me_normal"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_me_highlighted"];
        self.tabBarItem.title = @"我";
    }
    return self;
}

- (void)gotoLogin
{
    XMLoginVC *loginNC = [[XMLoginVC alloc] init];
    loginNC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:loginNC animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.titles = @[@"消息设置", @"已下载资料", @"意见反馈", @"软件说明", @"检测新版本", @"清除缓存", @"注销登录"];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.contentInset = UIEdgeInsetsMake(-self.navigationController.navigationBar.height-20, 0, 0, 0);
    [self.tableView registerClass:[OCell class] forCellReuseIdentifier:kCellIdentifier];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSData *data = [NSFileManager findFile:@"user_avatar.png" atPath:kDocuments];
    self.avatar = [UIImage imageWithData:data];
    
    [self.tableView reloadData];
    [self hideNavigationBarBackground];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self showNavigationBarBackground];
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([mUserDefaults boolForKey:kUser_HadLoginKey]) {
        return self.titles.count;
    }
    
    return self.titles.count - 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 175;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    XMUserInfoView *headerView = [[XMUserInfoView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.width, 175)];
    if ([mUserDefaults boolForKey:kUser_HadLoginKey]) {
        [headerView.usernameBtn setTitle:[mUserDefaults stringForKey:kUser_NameKey] forState: UIControlStateNormal];
        [headerView.usernameBtn removeTarget:self action:@selector(gotoLogin) forControlEvents:UIControlEventTouchUpInside];
        [headerView.avatarBtn removeTarget:self action:@selector(gotoLogin) forControlEvents:UIControlEventTouchUpInside];
        [headerView.avatarBtn addTarget:self action:@selector(setUserAvatar:) forControlEvents:UIControlEventTouchUpInside];
        if (self.avatar) {
            [headerView.avatarBtn setImage:self.avatar forState:UIControlStateNormal];
        }
    }
    else {
        [headerView.avatarBtn setImage:[UIImage imageNamed:@"user_avatar_placeholder"] forState:UIControlStateNormal];
        [headerView.usernameBtn setTitle:@"点击登录" forState: UIControlStateNormal];
        [headerView.usernameBtn addTarget:self action:@selector(gotoLogin) forControlEvents:UIControlEventTouchUpInside];
        [headerView.avatarBtn addTarget:self action:@selector(gotoLogin) forControlEvents:UIControlEventTouchUpInside];
        [headerView.avatarBtn removeTarget:self action:@selector(setUserAvatar:) forControlEvents:UIControlEventTouchUpInside];
    }

    return headerView;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier forIndexPath:indexPath];
    cell.textLabel.font  = [UIFont systemFontOfSize:16];
    cell.textLabel.text  = self.titles[indexPath.row];
    NSString *imageName  = [NSString stringWithFormat:@"settings%zd", indexPath.row];
    cell.imageView.image = [UIImage imageNamed:imageName];

    [self bk_performBlock:^(id obj) {
        cell.seprator.frame = CGRectMake(10, cell.seprator.y, cell.width - 20, cell.seprator.height);
    } afterDelay:0.1];
    
    if ([[OCheckUpdate sharedInstance] hasNew]) {
        for (UIView *view in cell.contentView.subviews) {
            if ([view isKindOfClass:[OLabel class]]) {
                [view removeFromSuperview];
            }
        }
        if (indexPath.row == 4) {
            OLabel *lbl = [[OLabel alloc] initWithFrame:CGRectMake(225, 10, 35, 24)];
            lbl.text = @"new";
            lbl.backgroundColor = kRedColor;
            lbl.highlightedTextColor = kRedColor;
            lbl.textColor = kWhiteColor;
            lbl.cornerRadius = 12;
            lbl.font = kFont(13);
            lbl.textAlignment = NSTextAlignmentCenter;
            [cell.contentView addSubview:lbl];
        }
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *vc = nil;
    switch (indexPath.row) {
        case 0:
            vc = [[XMNotificationSettingsVC alloc] init];
            break;
        case 1:
        {
            vc = [[XMFileManagerVC alloc] init];
        }
            break;
        case 2:
        {
            vc = [[XMFeedbackVC alloc] init];
        }
            break;
        case 3:
            vc = [[XMAboutMeVC alloc] init];
            break;
        case 4:
        {
            mWeakSelf
            [[OCheckUpdate sharedInstance] checkUpdateCompletion:^(BOOL hasNew) {
                if (!hasNew) {
                    [weakSelf bk_performBlock:^(id obj) {
                        [XMProgressHUD showTips:@"当前版本已是最新" atView:weakSelf.view];
                    } onQueue:dispatch_get_main_queue() afterDelay:0];
                }
            }];
        }
            break;
        case 5:
        {
            [self bk_performBlock:^(id obj) {
                [XMProgressHUD showTips:@"缓存已清除！"];
            } onQueue:dispatch_get_main_queue() afterDelay:0.45];
        }
            break;
        case 6:
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"注销提示" message:@"您确定要注销登录吗？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"注销", nil];
            [alertView show];
        }
    }
    
    if (vc) {
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        [[XMUserManager sharedInstance] logout:^{
            [self.tableView reloadData];
        }];
    }
}


#pragma mark - set user avatar

- (void)setUserAvatar:(UIButton *)sender
{
    UIActionSheet *as = [[UIActionSheet alloc] initWithTitle:@"设置头像..." delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从像册选择", @"拍照", nil];
    [as showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != 2) {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.mediaTypes = @[(NSString *)kUTTypeImage];
        picker.sourceType = buttonIndex;
        picker.delegate = self;
        picker.allowsEditing = YES;
        [self presentViewController:picker animated:YES completion:nil];
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    self.avatar = info[@"UIImagePickerControllerEditedImage"];
    [NSFileManager saveData:UIImagePNGRepresentation(self.avatar) withName:@"user_avatar.png" atPath:kDocuments];
    [self.tableView reloadData];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}


@end
