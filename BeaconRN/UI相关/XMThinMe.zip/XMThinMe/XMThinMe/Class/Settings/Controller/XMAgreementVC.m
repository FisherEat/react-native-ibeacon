//
//  XMAgreementVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/26.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMAgreementVC.h"

@interface XMAgreementVC ()
@property (strong, nonatomic) UIWebView *webView;
@property (strong, nonatomic) OTextView *textView;

@end

@implementation XMAgreementVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"寻觅隐私和条款";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    NSString *path = [[NSBundle mainBundle] pathForResource:@"agreement" ofType:@"doc"];
//    NSError *error = nil;
//    NSString *str = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];

//    self.textView = [[OTextView alloc] initWithFrame:CGRectMake(10, 0, self.view.width - 20, self.view.height)];
//    self.textView.editable = NO;
//    self.textView.showsVerticalScrollIndicator = NO;
//    self.textView.text = str;
//    [self.view addSubview:self.textView];

    self.webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    self.webView.scalesPageToFit = YES;
    [self.view addSubview:self.webView];
    
    NSURL *url = [NSURL fileURLWithPath:path];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [self.webView loadRequest:request];
}

@end
