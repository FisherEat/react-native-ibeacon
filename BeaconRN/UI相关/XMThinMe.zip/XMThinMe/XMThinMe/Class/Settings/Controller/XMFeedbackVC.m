//
//  XMFeedbackVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/7/14.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMFeedbackVC.h"
#import "XMFeedbackView.h"
#import "UMFeedback.h"

@interface XMFeedbackVC () <UMFeedbackDataDelegate>
@property (strong, nonatomic) XMFeedbackView *feedbackView;

@end

@implementation XMFeedbackVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"意见反馈";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.view.backgroundColor = mRGB(232, 232, 232);
    
    [UMFeedback sharedInstance].delegate = self;
    
    self.feedbackView = [[XMFeedbackView alloc] initWithFrame:CGRectMake(15, 64+15, self.view.width - 30, 300)];
    self.feedbackView.cornerRadius = 4;
    [self.feedbackView.submitBtn addTarget:self action:@selector(submitFeedback) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.feedbackView];
}

- (void)submitFeedback{
    if (self.feedbackView.contentTV.text.length == 0) {
        mAlertView(@"提示", @"请输入您的意见反馈！");
        return;
    }
    
    NSDictionary *posts = @{@"content": self.feedbackView.contentTV.text,
                            @"contact": [mUserDefaults stringForKey:kUser_NameKey] ? [mUserDefaults stringForKey:kUser_NameKey] : @""};
    [[UMFeedback sharedInstance] post:posts];
}


#pragma mark - UFeedbackDataDelegate

- (void)postFinishedWithError:(NSError *)error
{
    if (!error) {
        mAlertView(@"提示", @"您的建议我们已收到，我们会尽快处理，谢谢您的支持！");
    } else {
        mAlertView(@"提示", @"意见发送失败，请重试！");
    }
}

@end
