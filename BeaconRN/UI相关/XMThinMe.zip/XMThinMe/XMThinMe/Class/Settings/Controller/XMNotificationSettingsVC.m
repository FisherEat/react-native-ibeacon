//
//  XMMessageSettingsVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/15.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMNotificationSettingsVC.h"
#import "XMNotificationSettingsCell.h"

static NSString *const kCellIdentifier = @"settingCell";

@interface XMNotificationSettingsVC () <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) NSArray     *titles;
@property (strong, nonatomic) UITableView *tableView;

@end

@implementation XMNotificationSettingsVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"消息设置";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.titles = @[@"消息提示", @"声音", @"振动"];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

    [self.tableView registerClass:[XMNotificationSettingsCell class] forCellReuseIdentifier:kCellIdentifier];
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([mUserDefaults boolForKey:kReceiveNotificationKey]) {
        return self.titles.count;
    }
    
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMNotificationSettingsCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier forIndexPath:indexPath];
    cell.textLabel.text = self.titles[indexPath.row];
    cell.notificationSwitch.tag = indexPath.row;
    
    switch (indexPath.row) {
        case 0:
            cell.notificationSwitch.on = [mUserDefaults boolForKey:kReceiveNotificationKey];
            break;
        case 1:
            cell.notificationSwitch.on = [mUserDefaults boolForKey:kReceiveNotificationWithSoundKey];
            break;
        case 2:
            cell.notificationSwitch.on = [mUserDefaults boolForKey:kReceiveNotificationWithVibrateKey];
            break;
    }

    [cell.notificationSwitch bk_addEventHandler:^(UISwitch *sender) {
        switch (sender.tag) {
            case 0:
            {
                [mUserDefaults setBool:sender.on forKey:kReceiveNotificationKey];
                [tableView reloadData];
            }
                break;
            case 1:
                [mUserDefaults setBool:sender.on forKey:kReceiveNotificationWithSoundKey];
                break;
            case 2:
                [mUserDefaults setBool:sender.on forKey:kReceiveNotificationWithVibrateKey];
                break;
        }
        [mUserDefaults synchronize];
    } forControlEvents:UIControlEventValueChanged];

    return cell;
}


@end
