//
//  XMFeedbackVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/7/14.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"

/**
 *  用户反馈，接受用户反馈信息
 */
@interface XMFeedbackVC : OViewController

@end
