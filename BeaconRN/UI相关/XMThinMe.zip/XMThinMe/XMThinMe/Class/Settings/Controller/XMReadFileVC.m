//
//  XMReadFileVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/20.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMReadFileVC.h"

@interface XMReadFileVC ()
@property (strong, nonatomic) UIWebView *webView;

@end

@implementation XMReadFileVC

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"文件查看";
    
    self.webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.webView];
    
    NSURL *url = [NSURL fileURLWithPath:self.filePath];
    if ([self.filePath hasPrefix:@"http://"]) {
         url = [NSURL URLWithString:self.filePath];
    }
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
}

@end
