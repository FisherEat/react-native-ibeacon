//
//  XMAboutMeVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/7/15.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMAboutMeVC.h"
#import "XMAgreementVC.h"


@interface XMAboutMeVC ()

@end

@implementation XMAboutMeVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"软件说明";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    CGRect rect = CGRectMake((self.view.width - 100)/2, 90, 100, 100);
    UIImageView *logo = [[UIImageView alloc] initWithFrame:rect];
    logo.image = [UIImage imageNamed:@"icon120"];
    logo.cornerRadius = 8;
    logo.backgroundColor = kBlueColor;
    [self.view addSubview:logo];
    
    rect = CGRectMake(0, logo.bottom + 15, self.view.width, 20);
    OLabel *nameLbl = [[OLabel alloc] initWithFrame:rect];
    nameLbl.text = @"寻觅生活";
    nameLbl.font = kB_Font(20);
    nameLbl.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:nameLbl];
    
    rect = CGRectMake(nameLbl.x, nameLbl.bottom + 10, nameLbl.width, nameLbl.height);
    OLabel *versionLbl = [[OLabel alloc] initWithFrame:rect];
    versionLbl.text = [NSString stringWithFormat:@"当前版本:v%@", mAPPVersion];
    versionLbl.textAlignment = NSTextAlignmentCenter;
    versionLbl.textColor = [kGrayColor colorWithAlphaComponent:1.0];
    [self.view addSubview:versionLbl];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, versionLbl.bottom + 20, self.view.width, 40);
    [btn setTitle:@"使用条款和隐私政策" forState:UIControlStateNormal];
    [btn setTitleColor:kBrownColor forState:UIControlStateNormal];
    btn.titleLabel.font = kFont(16);
    [btn bk_addEventHandler:^(id sender) {
        XMAgreementVC *agreementVC = [[XMAgreementVC alloc] init];
        [self.navigationController pushViewController:agreementVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    rect = CGRectMake(0, self.view.height - 40, self.view.width, 40);
    OLabel *copyrightLbl = [[OLabel alloc] initWithFrame:rect];
    copyrightLbl.text = @"Copyright©2014 Xunmitech\nAll Rights Reserved.";
    copyrightLbl.textAlignment = NSTextAlignmentCenter;
    copyrightLbl.font = kFont(12);
    copyrightLbl.numberOfLines = 0;
    copyrightLbl.textColor = [kGrayColor colorWithAlphaComponent:0.7];
    [self.view addSubview:copyrightLbl];
    
}


@end
