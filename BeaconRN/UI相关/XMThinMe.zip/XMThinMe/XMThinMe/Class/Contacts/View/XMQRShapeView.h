//
//  XMQRShapeView.h
//  XMMuseum
//
//  Created by 何振东 on 14/9/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  指示扫描目标区域，包围二维码形状。
 */
@interface XMQRShapeView : UIView
/// 目标二维码边沿点数组
@property (strong, nonatomic) NSArray *outlinePoints;
/// 指示目标区域边围形状态
@property (strong, nonatomic, readonly) CAShapeLayer *outlineLayer;

@end
