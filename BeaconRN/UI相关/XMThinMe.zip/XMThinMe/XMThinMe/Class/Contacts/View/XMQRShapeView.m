//
//  XMQRShapeView.m
//  XMMuseum
//
//  Created by 何振东 on 14/9/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMQRShapeView.h"

@interface XMQRShapeView ()
@property (strong, nonatomic) CAShapeLayer *outlineLayer;

@end

@implementation XMQRShapeView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.outlineLayer = [CAShapeLayer layer];
        self.outlineLayer.strokeColor = kGreenColor.CGColor;
        self.outlineLayer.lineWidth = 2.0;
        self.outlineLayer.lineCap = @"round";
        self.outlineLayer.fillColor = kClearColor.CGColor;
        [self.layer addSublayer:self.outlineLayer];
    }
    return self;
}

- (void)setOutlinePoints:(NSArray *)corners
{
    if (corners != _outlinePoints) {
        _outlinePoints = corners;
        self.outlineLayer.path = [self pathFromPoints:corners].CGPath;
    }
}

- (UIBezierPath *)pathFromPoints:(NSArray *)points
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:[[points firstObject] CGPointValue]];
    for (NSInteger i = 1; i < points.count; i++) {
        [path addLineToPoint:[points[i] CGPointValue]];
    }
    [path addLineToPoint:[[points firstObject] CGPointValue]];
    return path;
}

@end
