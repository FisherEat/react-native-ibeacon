//
//  XMQRGeneratorVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/9/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMQRGeneratorVC.h"

@interface XMQRGeneratorVC ()
@property (strong, nonatomic) UIImageView *imageView;
@property (strong, nonatomic) OTextField *tf;
@property (strong, nonatomic) OButton *btn;

@end

@implementation XMQRGeneratorVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"创建二维码";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.width-70)/2, 64, 70, 70)];;
    self.imageView.backgroundColor = kOrangeColor;
    [self.view addSubview:self.imageView];
    
    self.tf = [[OTextField alloc] initWithFrame:CGRectMake(10, self.imageView.bottom + 20, 290, 30)];
    [self.view addSubview:self.tf];
    
    self.btn = [OButton buttonWithType:UIButtonTypeCustom];
    self.btn.frame = CGRectMake(10, self.tf.bottom + 20, 290, 40);
    [self.btn setTitle:@"generate" forState:UIControlStateNormal];
    [self.view addSubview:self.btn];
    
    mWeakSelf;
    [self.btn bk_addEventHandler:^(id sender) {
        CIImage *qrCode = [weakSelf createQRForString:weakSelf.tf.text];
        UIImage *qrImg = [weakSelf imageFromCIImage:qrCode scale:2 * [UIScreen mainScreen].scale];
        weakSelf.imageView.image = qrImg;
    } forControlEvents:UIControlEventTouchUpInside];
}

- (CIImage *)createQRForString:(NSString *)string
{
    NSData *strData = [string dataUsingEncoding:NSUTF8StringEncoding];
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [filter setValue:strData forKey:@"inputMessage"];
    [filter setValue:@"H" forKey:@"inputCorrectionLevel"];
    return filter.outputImage;
}

- (UIImage *)imageFromCIImage:(CIImage *)image scale:(CGFloat)scale
{
    CGImageRef imageRef = [[CIContext contextWithOptions:nil] createCGImage:image fromRect:image.extent];
    UIGraphicsBeginImageContext(CGSizeMake(image.extent.size.width * scale, image.extent.size.width * scale));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetInterpolationQuality(context, kCGInterpolationNone);
    CGContextDrawImage(context, CGContextGetClipBoundingBox(context), imageRef);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    CGImageRelease(imageRef);
    UIImage *flippedImage = [UIImage imageWithCGImage:[scaledImage CGImage]
                                                scale:scaledImage.scale
                                          orientation:UIImageOrientationDownMirrored];
    
    return flippedImage;
}


@end
