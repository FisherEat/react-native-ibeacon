//
//  XMContactsVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/9/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMContactsVC.h"
#import "XMQRScanVC.h"
#import "XMQRGeneratorVC.h"

@interface XMContactsVC ()

@end

@implementation XMContactsVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"我的名片";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    mWeakSelf;
    OButton *btn = [OButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(99, 99, 99, 99);
    [btn setTitle:@"scan" forState:UIControlStateNormal];
    [btn bk_addEventHandler:^(id sender) {
        XMQRScanVC *qrScanVC = [[XMQRScanVC alloc] init];
        [weakSelf.navigationController pushViewController:qrScanVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    btn = [OButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(99, 299, 99, 99);
    [btn setTitle:@"create" forState:UIControlStateNormal];
    [btn bk_addEventHandler:^(id sender) {
        XMQRGeneratorVC *qrGeneratorVC = [[XMQRGeneratorVC alloc] init];
        [weakSelf.navigationController pushViewController:qrGeneratorVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

}


@end
