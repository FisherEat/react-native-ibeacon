//
//  XMContactsVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/9/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"

@interface XMContactsVC : OViewController

@end
