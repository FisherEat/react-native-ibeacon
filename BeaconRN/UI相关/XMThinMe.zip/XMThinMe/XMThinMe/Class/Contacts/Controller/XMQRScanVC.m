//
//  XMQRScanVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/9/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMQRScanVC.h"
#import "XMQRShapeView.h"
@import AVFoundation;

@interface XMQRScanVC () <AVCaptureMetadataOutputObjectsDelegate>
@property (strong, nonatomic) AVCaptureVideoPreviewLayer *previewLayer;
@property (strong, nonatomic) UILabel                    *decodedMessageLbl;
@property (strong, nonatomic) XMQRShapeView              *qrShapeView;
@property (strong, nonatomic) NSTimer                    *timer;
@property (strong, nonatomic) AVCaptureSession           *session;


@end

@implementation XMQRScanVC

- (id)init
{
    self = [super init];
    if (self) {

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.session = [[AVCaptureSession alloc] init];
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    if (input) {
        [self.session addInput:input];
    }
    else {
        NSLog(@"error:%@", error);
        return;
    }
    
    AVCaptureMetadataOutput *output = [[AVCaptureMetadataOutput alloc] init];
    [self.session addOutput:output];
    output.metadataObjectTypes = @[AVMetadataObjectTypeQRCode];
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    self.previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:self.session];
    self.previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    self.previewLayer.bounds = self.view.bounds;
    self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds));;
    [self.view.layer addSublayer:self.previewLayer];
    
    self.decodedMessageLbl = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.height - 49, self.view.width, 49)];
    self.decodedMessageLbl.numberOfLines = 0;
    self.decodedMessageLbl.backgroundColor = [UIColor colorWithWhite:1.000 alpha:0.730];
    self.decodedMessageLbl.textColor = kBlackColor;
    self.decodedMessageLbl.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.decodedMessageLbl];
    
    self.qrShapeView = [[XMQRShapeView alloc] initWithFrame:self.view.bounds];
    self.qrShapeView.hidden = YES;
    [self.view addSubview:self.qrShapeView];
    
    [self.session startRunning];
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    for (AVMetadataObject *metadata in metadataObjects) {
        AVMetadataMachineReadableCodeObject *transformed = (AVMetadataMachineReadableCodeObject *)[self.previewLayer transformedMetadataObjectForMetadataObject:metadata];
        self.decodedMessageLbl.text = [transformed stringValue];
        
        NSArray *outlinePoints = [self translatePoints:transformed.corners fromView:self.view toView:self.qrShapeView];
        self.qrShapeView.frame = transformed.bounds;
        self.qrShapeView.hidden = NO;
        self.qrShapeView.outlinePoints = outlinePoints;
        [self startOverlayHideTimer];
    }
    
}

- (NSArray *)translatePoints:(NSArray *)points fromView:(UIView *)fromView toView:(UIView *)toView
{
    NSMutableArray *arr = [NSMutableArray array];
    for (NSDictionary *point in points) {
        CGPoint pointValue = CGPointMake([point[@"X"] floatValue], [point[@"Y"] floatValue]);
        CGPoint p = [fromView convertPoint:pointValue toView:toView];
        [arr addObject:[NSValue valueWithCGPoint:p]];
    }
    return arr.copy;
}

- (void)startOverlayHideTimer
{
    if (self.timer) {
        [self.timer invalidate];
    }
    
    self.timer = [NSTimer bk_scheduledTimerWithTimeInterval:0.2 block:^(NSTimer *timer) {
        self.qrShapeView.hidden = YES;
        self.decodedMessageLbl.text = @"";
    } repeats:NO];
}


@end
