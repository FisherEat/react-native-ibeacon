//
//  XMMessage.h
//  XMMuseum
//
//  Created by 何振东 on 14/9/25.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMMessage : NSObject
@property (strong, nonatomic) NSString *batch_id;
@property (strong, nonatomic) NSString *coupon_id;
@property (strong, nonatomic) NSString *coupon_content_1;
@property (strong, nonatomic) NSString *coupon_content_2;
@property (strong, nonatomic) NSString *coupon_title;
@property (assign, nonatomic) NSTimeInterval failure_time;
@property (assign, nonatomic) NSTimeInterval generation_time;

@end
