//
//  XMMessageListVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/9/25.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMMessageVC.h"
#import "XMMessageCell.h"
#import "XMMessage.h"

@interface XMMessageVC ()
@property (strong, nonatomic) NSMutableArray *messages;

@end

@implementation XMMessageVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"消息";
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_message_normal"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_message_highlighted"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.messages = @[].mutableCopy;
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = mRGB(232, 232, 232);
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.messages removeAllObjects];
    [self.tableView reloadData];
    
    [self getMessageList];
}

    
#pragma mark - delegate && datasource
    
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.messages.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 370;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"messageCell";
    XMMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMMessageCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    [cell configureCellWithCellData:self.messages[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark - network request

- (void)getMessageList
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    mWeakSelf;
    NSDictionary *params = @{@"device_type": @([XMAppManager platform]),
                             @"user_id": @"201410291414000001"};
    [[OURLRequest sharedInstance] postForPath:N_User_GetEntityCouponList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

        for (NSDictionary *dict in data) {
            NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
            XMMessage *message = [[XMMessage alloc] initWithJSONData:objectData];
            [weakSelf.messages addObject:message];
        }
        [weakSelf.tableView reloadData];
     }];
}

@end
