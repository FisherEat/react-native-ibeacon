//
//  XMMessageCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMMessageCell.h"

@implementation XMMessageCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = kClearColor;
        self.contentView.backgroundColor = kClearColor;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.seprator.hidden = YES;
        
        self.saveDateLbl = [[OLabel alloc] init];
        self.saveDateLbl.backgroundColor = mRGBToColor(0xc3c3c3);
        self.saveDateLbl.textColor = kWhiteColor;
        self.saveDateLbl.cornerRadius = 3;
        self.saveDateLbl.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.saveDateLbl];
        
        self.boxBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.boxBtn.backgroundColor = kWhiteColor;
        self.boxBtn.cornerRadius = 4;
        [self.boxBtn bk_addEventHandler:^(id sender) {

        } forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.boxBtn];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kFont(16);
        self.titleLbl.backgroundColor = kClearColor;
        [self.boxBtn addSubview:self.titleLbl];
        
        self.releaseDateLbl = [[OLabel alloc] init];
        self.releaseDateLbl.textColor = mRGB(176, 176, 176);
        self.releaseDateLbl.backgroundColor = kClearColor;
        [self.boxBtn addSubview:self.releaseDateLbl];
        
        self.thumbIV = [[OImageView alloc] init];
        self.thumbIV.image = [UIImage imageNamed:@"home_top_bg"];
        [self.boxBtn addSubview:self.thumbIV];
        
        self.detailLbl = [[OLabel alloc] init];
        self.detailLbl.numberOfLines = 3;
        self.detailLbl.textColor = mRGB(163, 163, 163);
        self.detailLbl.backgroundColor = kClearColor;
        [self.boxBtn addSubview:self.detailLbl];
        
        self.moreBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.moreBtn setImage:[UIImage imageNamed:@"home_right_arrow"] forState:UIControlStateNormal];
        [self.moreBtn setTitle:@"查看详情" forState:UIControlStateNormal];
        self.moreBtn.titleLabel.font = kFont(15);
        self.moreBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -35, 0, 0);
        self.moreBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 65, 0, 0);
        self.moreBtn.userInteractionEnabled = NO;
        [self.boxBtn addSubview:self.moreBtn];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.saveDateLbl.frame = CGRectMake((self.width - self.saveDateLbl.width)/2, 20, self.saveDateLbl.width + 10, self.saveDateLbl.height);
    self.boxBtn.frame = CGRectMake(10, self.saveDateLbl.bottom + 8, self.width - 20, self.height - self.saveDateLbl.height - 25);
    self.titleLbl.frame = CGRectMake(10, 5, self.boxBtn.width - 20, 30);
    self.releaseDateLbl.frame = CGRectMake(self.titleLbl.x, self.titleLbl.bottom + 0, self.titleLbl.width, 20);
    self.thumbIV.frame = CGRectMake(self.titleLbl.x, self.releaseDateLbl.bottom + 10, self.titleLbl.width, 145);
    self.detailLbl.frame = CGRectMake(self.titleLbl.x, self.thumbIV.bottom + 10, self.titleLbl.width, 50);
    self.moreBtn.frame = CGRectMake(self.titleLbl.x, self.detailLbl.bottom + 10, 80, 30);
}

- (void)configureCellWithCellData:(XMMessage *)message
{
    NSDate *failureTime         = [NSDate dateWithTimeIntervalSince1970:message.failure_time];
    NSDate *generationTime      = [NSDate dateWithTimeIntervalSince1970:message.generation_time];
    NSString *failureTimeStr    = [[[NVDate alloc] initUsingDate:failureTime] stringValueWithFormat:@"YYYY年MM月dd日"];
    NSString *generationTimeStr = [[[NVDate alloc] initUsingDate:generationTime] stringValueWithFormat:@"YYYY年MM月dd日"];

    self.titleLbl.text = message.coupon_title;
    self.saveDateLbl.text = generationTimeStr;
    self.releaseDateLbl.text = failureTimeStr;
    [self.saveDateLbl sizeToFit];
    self.detailLbl.text = message.coupon_content_1;
}

@end
