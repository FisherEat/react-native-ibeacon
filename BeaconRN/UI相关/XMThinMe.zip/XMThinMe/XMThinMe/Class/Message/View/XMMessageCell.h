//
//  XMMessageCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"
#import "XMMessage.h"

@interface XMMessageCell : OCell
@property (strong, nonatomic) OLabel     *saveDateLbl;
@property (strong, nonatomic) OButton    *boxBtn;
@property (strong, nonatomic) OLabel     *titleLbl;
@property (strong, nonatomic) OLabel     *releaseDateLbl;
@property (strong, nonatomic) OImageView *thumbIV;
@property (strong, nonatomic) OLabel     *detailLbl;
@property (strong, nonatomic) OButton    *moreBtn;

@end
