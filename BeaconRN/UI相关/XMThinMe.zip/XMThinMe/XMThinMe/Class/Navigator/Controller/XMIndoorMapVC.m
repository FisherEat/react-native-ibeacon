//
//  XMIndoorMapVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMIndoorMapVC.h"

@interface XMIndoorMapVC ()
@property (strong, nonatomic) GalleryView *galleryView;

@end

@implementation XMIndoorMapVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"导航";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (!self.business.navigation_image) {
        [XMProgressHUD showTips:@"无导航图" atView:self.view];
        return;
    }
    self.galleryView = [[GalleryView alloc] initWithFrame:self.view.bounds];
    self.galleryView.imageUrls = @[self.business.navigation_image];
    self.galleryView.backgroundColor = kClearColor;
    [self.view addSubview:self.galleryView];
}


@end
