//
//  XMMapVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMMapVC.h"

@interface XMMapVC () <BMKMapViewDelegate>

@end

@implementation XMMapVC

- (id)init
{
    self = [super init];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mapView = [[BMKMapView alloc] initWithFrame:self.view.bounds];
    self.mapView.showsUserLocation = YES;
    self.mapView.showMapScaleBar = YES;
    self.mapView.zoomLevel = 19;
    [self.view addSubview:self.mapView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (self.business) {
        self.title = self.business.business_name;

        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(self.business.latitude, self.business.longitude);
        [self.mapView setCenterCoordinate:coordinate animated:YES];
        [self addAnnotationWithCoordinate:coordinate title:self.business.business_name subtitle:self.business.address];
    } else if (self.shop) {
        self.title = self.shop.shop_name;
        
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(self.shop.latitude, self.shop.longitude);
        [self.mapView setCenterCoordinate:coordinate animated:YES];
        [self addAnnotationWithCoordinate:coordinate title:self.shop.shop_name subtitle:self.shop.address];
    }
    else {
        self.title = @"位置";
        __weak XMMapVC *weakSelf = (XMMapVC *)self;
        self.locationManager = [XMLocationManager manager];
        [self.locationManager updateUserLocation:^(BMKUserLocation *userLocation, NSError *error) {
            [weakSelf.mapView updateLocationData:userLocation];
            [weakSelf.mapView setCenterCoordinate:userLocation.location.coordinate animated:YES];
        }];
    }
}

- (void)addAnnotationWithCoordinate:(CLLocationCoordinate2D)coordinate title:(NSString *)title subtitle:(NSString *)subtitle
{
    BMKPointAnnotation *annotation = [[BMKPointAnnotation alloc] init];
    annotation.title = title;
    annotation.subtitle = subtitle;
    annotation.coordinate = coordinate;
    [self.mapView addAnnotation:annotation];
}

- (BMKAnnotationView *)mapView:(BMKMapView *)mapView viewForAnnotation:(id<BMKAnnotation>)annotation
{
    static NSString *identifier = @"annotationView";
    BMKPinAnnotationView *annotationView = (BMKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!annotationView) {
        annotationView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        annotationView.calloutOffset = CGPointMake(0, -5);
        annotationView.canShowCallout = YES;
    }
    annotationView.annotation = annotation;
    [annotationView setSelected:YES animated:YES];

    return annotationView;
}


@end
