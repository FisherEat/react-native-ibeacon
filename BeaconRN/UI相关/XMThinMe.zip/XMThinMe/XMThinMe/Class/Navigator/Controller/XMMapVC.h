//
//  XMMapVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"
#import "BMKMapView.h"
#import "BMapKit.h"
#import "XMBusiness.h"
#import "XMShop.h"

@interface XMMapVC : OViewController <BMKMapViewDelegate>
@property (strong, nonatomic) XMLocationManager  *locationManager;
@property (strong, nonatomic) BMKMapView         *mapView;
@property (strong, nonatomic) UIButton           *updateLocationBtn;


@property (strong, nonatomic) XMBusiness *business;

@property (strong, nonatomic) XMShop *shop;


@end
