//
//  XMUserLocationView.m
//  XMMuseum
//
//  Created by 何振东 on 14/9/2.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMLocationView.h"

#define MYBUNDLE_NAME @ "mapapi.bundle"
#define MYBUNDLE_PATH [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: MYBUNDLE_NAME]
#define MYBUNDLE [NSBundle bundleWithPath: MYBUNDLE_PATH]


@interface XMLocationView ()
@property (strong, nonatomic) UIImageView *locationIV;

@end

@implementation XMLocationView


+ (NSString*)getMyBundlePath:(NSString *)filename
{
	NSBundle * libBundle = MYBUNDLE ;
	if ( libBundle && filename ){
		NSString * s = [[libBundle resourcePath ] stringByAppendingPathComponent : filename];
		return s;
	}
	return nil ;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.locationIV = [[UIImageView alloc] initWithFrame:CGRectMake((self.width-6)/2, (self.height-6)/2, 6, 6)];
        self.locationIV.cornerRadius = self.locationIV.width/2;
        self.locationIV.image = [[UIImage imageWithContentsOfFile:[[self class] getMyBundlePath:@"images/icon_center_point@2x.png"]] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        self.locationIV.tintColor = mRGB(2, 125, 255);
        [self addSubview:self.locationIV];
        
//        PulsingHaloLayer *layer = [PulsingHaloLayer layer];
//        layer.radius = self.width/2;
//        layer.backgroundColor = mRGB(2, 125, 255).CGColor;
//        layer.position = CGPointMake(self.width/2, self.height/2);
//        layer.animationDuration = 4;
//        [self.layer addSublayer:layer];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
