//
//  XMAnnotationButton.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/5.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMKAnnotation.h"

@interface XMAnnotationButton : UIButton
@property (strong, nonatomic) id<BMKAnnotation> pinAnnotation;

@end
