//
//  XMAnnotationButton.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/5.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMAnnotationButton.h"

@implementation XMAnnotationButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kOrangeColor;
        self.titleLabel.font = kFont(11);
        self.showsTouchWhenHighlighted = YES;
        [self setTitle:@"步行" forState:UIControlStateNormal];
    }
    return self;
}



@end
