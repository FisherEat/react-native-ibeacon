//
//  XMPOIAnnotation.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/6.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMPOIAnnotation.h"

@implementation XMPOIAnnotation

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

@end
