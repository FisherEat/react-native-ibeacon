//
//  XMAnnotationModel.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMAnnotationModel.h"
#import "XMAnnotationButton.h"
#import "XMRouteAnnotation.h"
#import "XMPressAnnotation.h"
#import "XMPOIAnnotation.h"

#define MYBUNDLE_NAME @ "mapapi.bundle"
#define MYBUNDLE_PATH [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: MYBUNDLE_NAME]
#define MYBUNDLE [NSBundle bundleWithPath: MYBUNDLE_PATH]


@implementation XMAnnotationModel


+ (NSString*)getMyBundlePath:(NSString *)filename
{
	NSBundle * libBundle = MYBUNDLE ;
	if ( libBundle && filename ){
		NSString * s = [[libBundle resourcePath ] stringByAppendingPathComponent : filename];
		return s;
	}
	return nil ;
}

+ (id)annotationViewWith:(BMKMapView *)mapView annotation:(id<BMKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[XMPOIAnnotation class]]) {
        return [[self class] xmPOIAnnotationWithMapView:mapView annotation:annotation];
    }
    else if ([annotation isKindOfClass:[XMRouteAnnotation class]])
    {
        return [[self class] routeAnnotationWithMapView:mapView annotation:annotation];
    }
    else if ([annotation isKindOfClass:[XMPressAnnotation class]])
    {
        return [[self class] pressAnnotationWithMapView:mapView annotation:annotation];
    }

    return [[self class] defaultAnnotationWithMapView:mapView annotation:annotation];
}

+ (id)xmPOIAnnotationWithMapView:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation
{
    static NSString *annotationId = @"xmPOIAnnoation";
    BMKPinAnnotationView *annotationView = (BMKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:annotationId];;
    if (!annotationView) {
        annotationView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationId];;
        annotationView.canShowCallout = YES;
        annotationView.pinColor = BMKPinAnnotationColorGreen;
        
        XMAnnotationButton *rightBtn = [XMAnnotationButton buttonWithType:UIButtonTypeCustom];
        rightBtn.frame = CGRectMake(0, 0, 33, 33);
        rightBtn.cornerRadius = rightBtn.width/2;
        annotationView.rightCalloutAccessoryView = rightBtn;
        
        XMAnnotationButton *leftBtn = [XMAnnotationButton buttonWithType:UIButtonTypeCustom];
        leftBtn.frame = CGRectMake(0, 0, 33, 33);
        leftBtn.cornerRadius = leftBtn.width/2;
        [leftBtn setTitle:@"导航" forState:UIControlStateNormal];
        leftBtn.backgroundColor = kGreenColor;
        annotationView.leftCalloutAccessoryView = leftBtn;
    }
    annotationView.annotation = annotation;
    
    XMAnnotationButton *leftBtn = (XMAnnotationButton *)annotationView.leftCalloutAccessoryView;
    leftBtn.pinAnnotation = annotation;
    
    XMAnnotationButton *rightBtn = (XMAnnotationButton *)annotationView.rightCalloutAccessoryView;
    rightBtn.pinAnnotation = annotation;
    
    return annotationView;
}

+ (id)routeAnnotationWithMapView:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation
{
    static NSString *annotationId = @"RouteAnnoation";
    BMKPinAnnotationView *annotationView = (BMKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:annotationId];
    if (!annotationView) {
        annotationView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationId];;
        annotationView.canShowCallout = YES;
        annotationView.pinColor = BMKPinAnnotationColorPurple;
    }
    
    XMRouteAnnotation *routeAnnotation = (XMRouteAnnotation *)annotation;
    if (routeAnnotation.type == kRouteAnnotationStart) {
        annotationView.image = [UIImage imageWithContentsOfFile:[[self class] getMyBundlePath:@"images/icon_nav_start.png"]];
    }
    else if (routeAnnotation.type == kRouteAnnotationEnd) {
        annotationView.image = [UIImage imageWithContentsOfFile:[[self class] getMyBundlePath:@"images/icon_nav_end.png"]];
    }
    else if (routeAnnotation.type == kRouteAnnotationDirectionNode) {
        UIImage* image = [UIImage imageWithContentsOfFile:[[self class] getMyBundlePath:@"images/icon_direction.png"]];
        annotationView.image = [image imageRotatedByDegrees:routeAnnotation.degree];
    }
    
    annotationView.annotation = annotation;
    XMAnnotationButton *annotationBtn = (XMAnnotationButton *)annotationView.rightCalloutAccessoryView;
    annotationBtn.pinAnnotation = annotation;
    return annotationView;
}

+ (id)defaultAnnotationWithMapView:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation
{
    /// 默认标注
    static NSString *annotationId = @"defaultAnnotation";
    BMKPinAnnotationView *annotationView = (BMKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:annotationId];;
    if (!annotationView) {
        annotationView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationId];;
        annotationView.canShowCallout = YES;
        annotationView.pinColor = BMKPinAnnotationColorPurple;
        
        XMAnnotationButton *rightBtn = [XMAnnotationButton buttonWithType:UIButtonTypeCustom];
        rightBtn.frame = CGRectMake(0, 0, 33, 33);
        rightBtn.cornerRadius = rightBtn.width/2;
        annotationView.rightCalloutAccessoryView = rightBtn;
        
        XMAnnotationButton *leftBtn = [XMAnnotationButton buttonWithType:UIButtonTypeCustom];
        leftBtn.frame = CGRectMake(0, 0, 33, 33);
        leftBtn.cornerRadius = leftBtn.width/2;
        [leftBtn setTitle:@"导航" forState:UIControlStateNormal];
        leftBtn.backgroundColor = kGreenColor;
        //        annotationView.leftCalloutAccessoryView = leftBtn;
    }
    annotationView.annotation = annotation;
    
    XMAnnotationButton *leftBtn = (XMAnnotationButton *)annotationView.leftCalloutAccessoryView;
    leftBtn.pinAnnotation = annotation;
    
    XMAnnotationButton *rightBtn = (XMAnnotationButton *)annotationView.rightCalloutAccessoryView;
    rightBtn.pinAnnotation = annotation;
    
    return annotationView;
}

+ (id)pressAnnotationWithMapView:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation
{
    /// 默认标注
    static NSString *annotationId = @"defaultAnnotation";
    BMKPinAnnotationView *annotationView = (BMKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:annotationId];;
    if (!annotationView) {
        annotationView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationId];;
        annotationView.canShowCallout = YES;
        annotationView.pinColor = BMKPinAnnotationColorRed;
//        annotationView.draggable = YES;
        
        XMAnnotationButton *rightBtn = [XMAnnotationButton buttonWithType:UIButtonTypeCustom];
        rightBtn.frame = CGRectMake(0, 0, 33, 33);
        rightBtn.cornerRadius = rightBtn.width/2;
        annotationView.rightCalloutAccessoryView = rightBtn;
        
        XMAnnotationButton *leftBtn = [XMAnnotationButton buttonWithType:UIButtonTypeCustom];
        leftBtn.frame = CGRectMake(0, 0, 33, 33);
        leftBtn.cornerRadius = leftBtn.width/2;
        [leftBtn setTitle:@"导航" forState:UIControlStateNormal];
        leftBtn.backgroundColor = kGreenColor;
        //        annotationView.leftCalloutAccessoryView = leftBtn;
    }
    annotationView.annotation = annotation;
    
    XMAnnotationButton *leftBtn = (XMAnnotationButton *)annotationView.leftCalloutAccessoryView;
    leftBtn.pinAnnotation = annotation;
    
    XMAnnotationButton *rightBtn = (XMAnnotationButton *)annotationView.rightCalloutAccessoryView;
    rightBtn.pinAnnotation = annotation;
    
    return annotationView;
}

@end
