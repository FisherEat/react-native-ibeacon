//
//  XMPOIInfo.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/18.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  公司自定义POI信息对象
 */

/// 定义POI类型
typedef NS_ENUM(NSUInteger, POIType) {
    kPOITypeEntrance = 0,
    kPOITypeExit,
    kPOITypePark,
    kPOITypeWC,
    kPOITypeTicketOffice,
    kPOITypePartner
};

@interface XMPOIInfo : NSObject
@property (assign, nonatomic) double lat;
@property (assign, nonatomic) double lon;
@property (assign, nonatomic) POIType poiType;

@end
