//
//  XMPressAnnotation.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/8.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMPressAnnotation.h"

@implementation XMPressAnnotation

@end
