//
//  XMAnnotationModel.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMAnnotationModel : NSObject

+ (id)annotationViewWith:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation;

+ (id)xmPOIAnnotationWithMapView:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation;
+ (id)routeAnnotationWithMapView:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation;
+ (id)defaultAnnotationWithMapView:(BMKMapView *)mapView annotation:(id <BMKAnnotation>)annotation;

@end
