//
//  XMPOIAnnotation.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/6.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "BMKPointAnnotation.h"

/**
 *  公司自定义标注
 */
@interface XMPOIAnnotation : BMKPointAnnotation
@property (assign, nonatomic) int      type;
@property (copy, nonatomic  ) NSString *beacon_id;

@end
