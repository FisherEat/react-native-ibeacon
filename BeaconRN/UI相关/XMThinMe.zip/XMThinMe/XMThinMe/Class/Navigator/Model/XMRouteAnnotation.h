//
//  XMRouteAnnotation.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/5.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "BMKPointAnnotation.h"

/**
 *  路线规划标注类
 */

///<0:起点 1：终点 2：公交 3：地铁 4:驾乘 5:途经点
typedef NS_ENUM(NSUInteger, RouteAnnotationType) {
    kRouteAnnotationStart = 0,
    kRouteAnnotationEnd,
    kRouteAnnotationBus,
    kRouteAnnotationSubway,
    kRouteAnnotationDrive,
    kRouteAnnotationDirectionNode,
};


@interface XMRouteAnnotation : BMKPointAnnotation
@property (nonatomic) RouteAnnotationType type;
@property (nonatomic) int degree;

@end
