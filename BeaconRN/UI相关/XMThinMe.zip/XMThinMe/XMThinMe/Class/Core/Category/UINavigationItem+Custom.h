//
//  UINavigationItem+Custom.h
//  XMMuseum
//
//  Created by 何振东 on 14/7/24.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationItem (Custom)

@end
