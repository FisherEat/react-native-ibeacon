//
//  UIView+Data.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/12.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "UIView+Data.h"

@implementation UIView (Data)

- (void)configureViewWithData:(id)viewData
{
    
}

@end
