#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/** 
 *  AppConfig接口 定义APP中的相关配置
 *  包含社交网络帐号、用户简单个人信息、程序界面中的常用字体、字号、颜色等的通用定义等。
 */

/// 程序中用到的第三方帐号的相关Key和SecretKey
static NSString *const kWeChatAppId      = @"wxc070c02fb0a72487";
static NSString *const kUmengKey         = @"53d763cf56240bceda037f5f";
static NSString *const kShareSDKKey      = @"";
static NSString *const kQZoneID          = @"";
static NSString *const kQZoneKey         = @"";
static NSString *const kBaiDuMapKey      = @"2v5USi1Vn0Xvsr3gRl2yyaTC";
static NSString *const kJPushKey         = @"40d8740f2efa0315bce7b3b8";
static NSString *const kBDCloudAK        = @"8qj8xohPKxPsEeQHHlxZPF58";
static int const       kBDTableID        = 74224;
static NSString *const kMessageAPPID     = @"2a67c5ec75b8";
static NSString *const kMessageAPPSecret = @"e7c6b61353bb6fac5146dd19762f5ed2";


/// 用户相关信息存储字典key
//static NSString *const kUser_LifeNumberKey = @"User_LifeNumberKey";
static NSString *const kUser_UIDKey        = @"User_UIDKey";
static NSString *const kUser_NameKey       = @"User_NameKey";
static NSString *const kUser_NicknameKey   = @"User_NicknameKey";
static NSString *const kUser_PasswordKey   = @"User_PasswordKey";
static NSString *const kUser_HadLoginKey   = @"User_HadLoginKey";

/// 存储是否接受推送通知、是否有声音提示、是否震动提示，值为bool类型，程序第一次安装时，初始化为YES
static NSString *const kReceiveNotificationKey            = @"receiveNotificationKey";
static NSString *const kReceiveNotificationWithSoundKey   = @"receiveNotificationWithSoundKey";
static NSString *const kReceiveNotificationWithVibrateKey = @"receiveNotificationWithVibrateKey";

/// 下载目录文件夹名名
#define  kXM_Download_Dir [NSString stringWithFormat:@"%@/xm_download", kDocuments]

/// 程序相关常数 App Id、下载地址、评价地址等
static NSString *const kAppId = @"899155970";

#define kAppUrl     [NSString stringWithFormat:@"https://itunes.apple.com/us/app/ling-hao-xian/id%@?ls=1&mt=8", kAppId]
#define kRateUrl    [NSString stringWithFormat:@"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=%@",kAppId]


/// 程序全局通知
static NSString *const kReLoginNotification  = @"ReLoginNotification";


/// 占位图片
#define kPlaceholderImage_square    [UIImage imageNamed:@"placeholder_square"]
#define kPlaceholderImage_rectangle [UIImage imageNamed:@"placeholder_rectangle"]

/// 常用三级加粗字体字号
#define kB_LargeFont   [UIFont boldSystemFontOfSize:20]
#define kB_MiddleFont  [UIFont boldSystemFontOfSize:18]
#define kB_SmallFont   [UIFont boldSystemFontOfSize:15]
/// 常用三级正常字体字号
#define kN_LargeFont   [UIFont systemFontOfSize:17]
#define kN_MiddleFont  [UIFont systemFontOfSize:15]
#define kN_SmallFont   [UIFont systemFontOfSize:12]
/// 内容部分正常显示颜色和突出显示颜色
#define kNormalColor      [UIColor colorWithRed:57/255.0 green:32/255.0 blue:0/255.0   alpha:1]
#define kHighlightColor   [UIColor colorWithRed:0/255.0 green:191/255.0 blue:225/255.0 alpha:1]
/// 几个常用色彩
#define kAppBgColor             [UIColor colorWithRed:235/255.0 green:235/255.0 blue:235/255.0 alpha:1]
#define kBrownColor             [UIColor colorWithRed:255/255.0 green:133/255.0 blue:0/255.0 alpha:1]
#define kGreenColor             [UIColor colorWithRed:1/255.0 green:209/255.0 blue:1/255.0 alpha:1]
#define kOrangeColor            [UIColor colorWithRed:255/255.0 green:141/255.0 blue:22/255.0 alpha:1]
#define kGrayColor              [UIColor colorWithRed:192/255.0 green:192/255.0 blue:192/255.0 alpha:1]
#define kBlackColor             [UIColor colorWithRed:50/255.0 green:50/255.0 blue:50/255.0 alpha:1]
#define kRedColor               [UIColor colorWithRed:249/255.0 green:41/255.0 blue:0/255.0 alpha:1]
#define kBlueColor              [UIColor colorWithRed:0/255.0 green:191/255.0 blue:253/255.0 alpha:1]
#define kClearColor             [UIColor clearColor]
#define kWhiteColor             [UIColor whiteColor]
#define kContentBgColor         [UIColor colorWithWhite:0.000 alpha:0.360]


