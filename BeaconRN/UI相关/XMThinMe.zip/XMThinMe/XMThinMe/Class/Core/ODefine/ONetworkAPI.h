//
//  NetworkAPI.h
//  Line0New
//
//  Created by line0 on 13-4-8.
//  Copyright (c) 2013年 makeLaugh. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  定义所有的网络接口，所有与网络交互的接口，都通过类来定义管理与修改。
 */

///网络请求状态返回码
typedef enum
{
    ORequestStatusSuccess   = 2000,//请求成功有数据
    ORequestStatusFailed    = 2001,//请求失败

    ORequestStatusDataNotExist     = 3001,//数据不存在
    ORequestStatusDataHadExist     = 3002,//数据已存在
    ORequestStatusPasswordError    = 3003,//密码错误
    ORequestStatusUserHadForbidden = 3004,//用户已被禁止
    ORequestStatusAccountTypeError = 3005,//帐户类型错误(需要判断用户帐号类型时)
    ORequestStatusNeedRelogin      = 3006,//需要重新登录，该token已过期

    ORequestStatusParamsError      = 4001,//参数错误
    ORequestStatusClientNeedUpdate = 4002,//客户端需要升级
    ORequestStatusOtherError       = 4010,//其它错误
}ORequestStatusCode;


///操作系统平台
typedef enum
{
    OiPhone       = 0,
    OiPad         = 1,
    OAndroid      = 2,
}OOSPlatform;


///线上主站点地址
#define N_HostSite         @"http://www.xunmitech.com/BeaconService/BeaconService.asmx"
//#define N_HostSite         @"http://192.168.1.20/Beacon/BeaconService.asmx"

/**
 * user模块接口，与用户相关的接口
 */
/// 创建会员终身号
#define N_User_CreateLifeNumber       @"user_createLifeNumber"
/// 普通登录
#define N_User_Login                  @"user_login"
/// 注册接口
#define N_User_Register               @"user_register"
/// 登出
#define N_User_Logout                 @"user_logout"
/// 获取用户信息
#define N_User_GetUserInfo            @"user_getUserInfo"
/// 修改个人信息
#define N_User_UpdateUserInfo         @"user_updateUserInfo"
/// 修改密码
#define N_User_ChangePassword         @"user_changePassword"
/// 找回密码
#define N_User_RetrievePassword       @"user_retrievePassword"
/// 关注商铺/商品
#define N_User_AddEntityAttention     @"user_addEntityAttention"
/// 取消关注商铺/商品
#define N_User_DeleteEntityAttention  @"user_deleteEntityAttention"
/// 获取关注列表
#define N_User_GetEntityAttentionList @"user_getEntityAttentionList"
/// 根据商铺编号获取优惠券列表
#define N_User_GetEntityCouponList    @"user_getEntityCouponList"

/**
 *  xbeacon模块接口
 */
/// 获取基站对应实体的基本信息
#define N_Beacon_GetEntityBasicInfo     @"beacon_getEntityBasicInfo"

/**
 *  business模块接口
 */
/// 根据类型获取商户列表
#define N_Business_GetEntityList          @"business_getEntityList"
/// 根据商户编号获取商户详情
#define N_Business_GetEntityDetailInfo    @"business_getEntityDetailInfo"
/// 根据商户编号获取广告列表
#define N_Business_GetEntityAdvertiseList @"business_getEntityAdvertiseList"
/// 根据商户编号获取议程列表
#define N_Business_GetEntityAgendaList    @"business_getEntityAgendaList"
/// 根据商户编号获取商铺列表
#define N_Business_GetEntityShopList      @"business_getEntityShopList"


/**
 *  shop模块接口
 */
/// 根据类型、经纬度排序获取周边商铺
#define N_Shop_GetEntityListPlus                        @"shop_getEntityListPlus"
/// 根据商铺编号获取商铺详细信息
#define N_Shop_getEntityDetailInfo                      @"shop_getEntityDetailInfo"
/// 根据商铺编号获取附件列表
#define N_Shop_GetEntityAttachmentList                  @"shop_getEntityAttachmentList"
/// 根据商铺编号获取新闻列表
#define N_Shop_GetEntityNewsList                        @"shop_getEntityNewsList"
/// 根据商铺编号获取商品列表
#define N_Shop_GetEntityProductList                     @"shop_getEntityProductList"
/// 根据商铺编号获取模板实例详细信息
#define N_Shop_GetEntityTemplateExamplesDetailInfo      @"shop_getEntityTemplateExamplesDetailInfo"
/// 根据商铺编号获取模板实例大屏图片列表
#define N_TemplateExamples_GetEntityPictureListByShopid @"templateExamples_getEntityPictureListByShopid"

/**
 *  product模块接口
 */
/// 根据商品编号获取商品详情
#define N_Product_GetEntityAttachmentList @"product_getEntityDetailInfo"
/// 根据商品编号获取图片列表
#define N_Product_GetEntityPictureList    @"product_getEntityPictureList"
/// 根据商品编号获取评论列表
#define N_Product_GetEntityCommentList    @"product_getEntityCommentList"
/// 插入商品评论信息
#define N_Product_AddEntityComment        @"product_addEntityComment"
/// 根据商品编号获取商品详情
#define N_Product_GetEntityDetailInfo     @"product_getEntityDetailInfo"



/**
 *  statistics模块接口
 */
/// 上传用户在某个基站附近停留时间，具体时间则服务器生成
#define N_Statistics_UploadUserStayInBeaconNearbyTime @"statistics_uploadUserStayInBeaconNearbyTime"

/**
 *  template模块接口
 */
/// 根据模板实例编号获取模板实例详细信息
#define N_TemplateExamples_GetEntityDetailInfo @"templateExamples_getEntityDetailInfo"
/// 根据模板实例编号获取模板实例板块（故事）信息列表
#define N_TemplateExamples_GetEntityTemplateExamplesPlateList @"templateExamples_getEntityTemplateExamplesPlateList"
/// 根据模板实例编号获取商品列表
#define N_TemplateExamples_GetEntityProductList @"templateExamples_getEntityProductList"
/// 根据信息模板编号获取大屏图片列表
#define N_TemplateExamples_GetEntityPictureList @"templateExamples_getEntityPictureList"


/**
 * Entity模块接口
 */
/// 根据商户名称或商铺名称或地址查询对应实体列表信息
#define N_Entity_GetEntityList @"entity_getEntityList"
