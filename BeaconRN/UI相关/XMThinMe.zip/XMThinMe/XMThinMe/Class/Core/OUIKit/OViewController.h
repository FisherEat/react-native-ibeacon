//
//  ViewController.h
//  TWApp
//
//  Created by line0 on 13-7-6.
//  Copyright (c) 2013年 makeLaugh. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  项目中所有ViewController的根类。
 *  在本类里，设置背景颜色、错误提示、加载等待提示、状态栏样式等等功能。
 */
@interface OViewController : UIViewController
/// 在iOS7中，放在状态栏后面，默认为nil，调用showCustomStatusBar后创建
@property (strong, nonatomic) UIView      *statusBar;

/// 调用返回按钮事件
- (void)back;

//// 返回自定义的返回按钮
- (void)showCustomBackBarButtonItem;

/// 隐藏导航栏背景
- (void)hideNavigationBarBackground;

- (void)showCustomStatusBar;

@end
