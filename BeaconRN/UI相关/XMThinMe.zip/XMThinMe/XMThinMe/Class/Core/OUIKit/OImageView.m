//
//  OImageView.m
//  XMMuseum
//
//  Created by 何振东 on 14-6-30.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OImageView.h"

@implementation OImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


@end
