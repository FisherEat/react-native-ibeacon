//
//  OWaterfallLayout.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/13.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OWaterfallLayout.h"

@interface OWaterfallLayout ()
@property (assign, nonatomic) NSInteger      itemCount;
@property (assign, nonatomic) CGFloat        interitemSpacing;
@property (strong, nonatomic) NSMutableArray *columnHeights;
@property (strong, nonatomic) NSMutableArray *itemAttributes;

@end

@implementation OWaterfallLayout

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self defaultInit];
    }
    return self;
}

- (void)defaultInit
{
    self.columnCount = 2;
    self.itemWidth = [UIScreen mainScreen].bounds.size.width/2 - 8;
    self.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5);
}


#pragma mark - accessors

- (void)setColumnCount:(NSUInteger)columnCount
{
    if (_columnCount != columnCount) {
        _columnCount = columnCount;
        [self invalidateLayout];
    }
}

- (void)setItemWidth:(CGFloat)itemWidth
{
    if (_itemWidth != itemWidth) {
        _itemWidth = itemWidth;
        [self invalidateLayout];
    }
}

- (void)setSectionInset:(UIEdgeInsets)sectionInset
{
    if (!UIEdgeInsetsEqualToEdgeInsets(_sectionInset, sectionInset)) {
        _sectionInset = sectionInset;
        [self invalidateLayout];
    }
}


#pragma mark - methods to override

- (void)prepareLayout
{
    [super prepareLayout];
    
    self.itemCount = [self.collectionView numberOfItemsInSection:0];
    CGFloat width = self.collectionView.width - self.sectionInset.left - self.sectionInset.right;
    self.interitemSpacing = floorf((width - self.columnCount * self.itemWidth) / (self.columnCount - 1));
    self.itemAttributes = [NSMutableArray arrayWithCapacity:self.itemCount];
    self.columnHeights = [NSMutableArray arrayWithCapacity:self.columnCount];
    for (int i = 0; i < self.columnCount; i++) {
        [self.columnHeights addObject:@(self.sectionInset.top)];
    }
    
    for (NSInteger i = 0; i < self.itemCount; i++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
        CGFloat itemHeight = [self.delegate collectionView:self.collectionView layout:self heightForItemAtIndexPath:indexPath];
        NSUInteger columnIndex = [self shortestColumnIndex];
        CGFloat xOffset = self.sectionInset.left + (self.itemWidth + self.interitemSpacing) * columnIndex;
        CGFloat yOffset = [self.columnHeights[columnIndex] floatValue];
        UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];;
        attributes.frame = CGRectMake(xOffset, yOffset, self.itemWidth, itemHeight);
        [self.itemAttributes addObject:attributes];
        self.columnHeights[columnIndex] = @(yOffset + itemHeight + self.interitemSpacing);
    }
}

- (CGSize)collectionViewContentSize
{
    if (self.itemCount == 0) {
        return CGSizeZero;
    }
    
    CGSize contentSize = self.collectionView.frame.size;
    NSUInteger columnIndex = [self longestColumnIndex];
    CGFloat height = [self.columnHeights[columnIndex] floatValue];
    contentSize.height = height - self.interitemSpacing + self.sectionInset.bottom;
    return contentSize;
}

- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return self.itemAttributes[indexPath.item];
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect
{
    NSPredicate *predicate = [NSPredicate predicateWithBlock:^BOOL(UICollectionViewLayoutAttributes *evaluatedObject, NSDictionary *bindings) {
        return CGRectIntersectsRect(rect, [evaluatedObject frame]);
    }];
    return [self.itemAttributes filteredArrayUsingPredicate:predicate];
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds
{
    return YES;
}


#pragma makr - private methods

- (NSUInteger)shortestColumnIndex
{
    __block NSUInteger index = 0;
    __block CGFloat shortestHeight = MAXFLOAT;
    [self.columnHeights enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        CGFloat height = [obj floatValue];
        if (height < shortestHeight) {
            shortestHeight = height;
            index = idx;
        }
    }];
    return index;
}

- (NSUInteger)longestColumnIndex
{
    __block NSUInteger index = 0;
    __block CGFloat longestHeight = 0;
    [self.columnHeights enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        CGFloat height = [obj floatValue];
        if (height > longestHeight) {
            longestHeight = height;
            index = idx;
        }
    }];
    return index;
}


@end
