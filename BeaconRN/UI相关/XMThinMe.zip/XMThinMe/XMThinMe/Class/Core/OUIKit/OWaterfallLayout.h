//
//  OWaterfallLayout.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/13.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OWaterfallLayout;
@protocol OWaterfallLayoutDelegate <UICollectionViewDelegate>

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout heightForItemAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface OWaterfallLayout : UICollectionViewLayout
/// 有多少列
@property (assign, nonatomic) NSUInteger columnCount;

/// 每列有多宽
@property (assign, nonatomic) CGFloat itemWidth;

/// 每个区之间的间隔
@property (assign, nonatomic) UIEdgeInsets sectionInset;

@property (weak, nonatomic) id <OWaterfallLayoutDelegate> delegate;

/// 计算Cell的高度，必须调用，否则报错
//@property (copy, nonatomic) CGFloat (^cellHeight) (UICollectionView *collectionView, UICollectionViewLayout *layout, NSIndexPath *indexPath);

@end
