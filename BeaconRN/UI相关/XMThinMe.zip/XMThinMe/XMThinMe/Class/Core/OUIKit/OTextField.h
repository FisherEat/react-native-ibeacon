//
//  TWTextField.h
//  TWApp
//
//  Created by line0 on 13-7-6.
//  Copyright (c) 2013年 makeLaugh. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  统一认定文本框的外观样式及字体大小
 */
@interface OTextField : UITextField

@end
