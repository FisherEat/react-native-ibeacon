//
//  CJNavController.h
//  CJSX
//
//  Created by 何振东 on 14-4-25.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  通用导航控制器，在本类里，定义一些通用的导航行为，如手势等
 */
@interface ONavController : UINavigationController


@end
