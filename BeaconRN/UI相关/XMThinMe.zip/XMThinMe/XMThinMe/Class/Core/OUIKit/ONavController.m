
//  CJNavController.m
//  CJSX
//
//  Created by 何振东 on 14-4-25.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import "ONavController.h"

@interface ONavController ()

@end

@implementation ONavController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    self.hidesBarsOnTap = YES;
//    self.hidesBarsOnSwipe = YES;
//    self.hidesBarsWhenVerticallyCompact = YES;
    
    
    self.view.cornerRadius = 4;
}



@end
