//
//  TWButton.h
//  TWAppNew
//
//  Created by line0 on 13-8-28.
//  Copyright (c) 2013年 makeLaugh. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  给UIButton认定统一的外观样式，标题字体，点击效果。
 */

@interface OButton : UIButton

@end
