//
//  TWLabel.h
//  TWApp
//
//  Created by line0 on 13-7-6.
//  Copyright (c) 2013年 makeLaugh. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  给UILabel认定统一的外观样式，字体，清除背景。
 */
@interface OLabel : UILabel

@end
