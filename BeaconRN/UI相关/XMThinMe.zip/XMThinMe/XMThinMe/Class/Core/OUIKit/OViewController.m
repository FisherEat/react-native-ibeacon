//
//  ViewController.m
//  TWApp
//
//  Created by line0 on 13-7-6.
//  Copyright (c) 2013年 makeLaugh. All rights reserved.
//

#import "OViewController.h"

@interface OViewController ()

@end

@implementation OViewController

- (id)init
{
    self  = [super init];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.view.backgroundColor = kWhiteColor;
}

- (void)hideNavigationBarBackground
{
    //去掉导航栏的原生背景
    for (UIView *view in self.navigationController.navigationBar.subviews)
    {
        if ([view isKindOfClass:NSClassFromString(@"_UINavigationBarBackground")])
        {
            view.hidden = YES;
        }
    }
}

- (void)showCustomBackBarButtonItem
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 60, 40);
    btn.imageEdgeInsets = UIEdgeInsetsMake(0, -30, 0, 30);
    [btn setImage:[UIImage imageNamed:@"nav_back"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = backBarButtonItem;
}

- (void)showCustomStatusBar
{
    if (!self.statusBar) {
        self.statusBar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 20)];
        self.statusBar.backgroundColor = kWhiteColor;
        [self.view addSubview:self.statusBar];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (self.statusBar) {
        [self.view bringSubviewToFront:self.statusBar];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)back
{
    [self.view endEditing:YES];
    [self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
