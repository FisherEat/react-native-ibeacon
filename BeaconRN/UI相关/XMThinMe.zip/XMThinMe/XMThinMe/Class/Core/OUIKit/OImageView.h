//
//  OImageView.h
//  XMMuseum
//
//  Created by 何振东 on 14-6-30.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OImageView : UIImageView

@end
