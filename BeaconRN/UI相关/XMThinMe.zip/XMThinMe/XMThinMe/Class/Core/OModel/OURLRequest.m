//
//  OSession.m
//  CJSX
//
//  Created by 何振东 on 14-5-7.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import "OURLRequest.h"

static OURLRequest *SINGLETON = nil;

/// 默认请求Tag
static NSInteger const kDefaultTag = -1;

// 判断是否是通过单例方法获取实例，若不是，则抛出异常。
static BOOL isFirstAccess = YES;

@interface OURLRequest ()
/// 请求管理器
@property (strong, nonatomic, readwrite) AFHTTPSessionManager *sessionManager;
/// 基站点url
@property (strong, nonatomic, readwrite) NSURL *baseURL;

@end

@implementation OURLRequest

+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        isFirstAccess = NO;
        SINGLETON = [[OURLRequest alloc] init];
    });
    return SINGLETON;
}

- (instancetype)init
{
    if (SINGLETON) {
        return SINGLETON;
    }
    if (isFirstAccess) {
        [self doesNotRecognizeSelector:_cmd];
    }
    self = [super init];
    if (self) {
        [self defaultInit];
    }
    return self;
}

- (void)cancelRequest
{
    [self.sessionManager invalidateSessionCancelingTasks:YES];
}

- (void)defaultInit
{
    self.baseURL = [NSURL URLWithString:N_HostSite];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    configuration.timeoutIntervalForRequest = 30;
    configuration.timeoutIntervalForResource = 30;
    self.sessionManager = [[AFHTTPSessionManager alloc] initWithBaseURL:self.baseURL sessionConfiguration:configuration];
    self.sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", @"text/json", @"application/json", @"text/plain", nil];
}

- (void)postForPath:(NSString *)path withParams:(NSDictionary *)params completionHandler:(void (^)(id data, NSError *error))completionHandler
{
    [self postForPath:path withParams:params withTag:kDefaultTag completionHandler:^(id data, NSError *error, NSInteger tag) {
        if (completionHandler) {
            completionHandler(data, error);
        }
    } ];
}

- (void)postForPath:(NSString *)path withParams:(NSDictionary *)params withTag:(NSUInteger)tag completionHandler:(void (^)(id data, NSError *error, NSInteger tag))completionHandler
{
    [self.sessionManager POST:path
                   parameters:params
                      success:^(NSURLSessionDataTask *task, id responseObject)
     {
         NSInteger status = [responseObject[@"status"] integerValue];
         NSDictionary *resultData = nil;
         NSError *error = nil;
         if (status == ORequestStatusSuccess) {
              resultData = responseObject[@"data"];
         } else {
             error = [NSError errorWithDomain:@"请求错误" code:status userInfo:nil];
         }
         if (completionHandler) {
             completionHandler(resultData, error, tag);
         }
     }
                      failure:^(NSURLSessionDataTask *task, NSError *error)
     {
         if (completionHandler) {
             completionHandler(nil, error, tag);
         }
     }];
}

- (void)getForPath:(NSString *)path withParams:(NSDictionary *)params completionHandler:(void (^)(id data, NSError *error))completionHandler
{
    [self getForPath:path withParams:params withTag:kDefaultTag completionHandler:^(id data, NSError *error, NSInteger tag) {
        if (completionHandler) {
            completionHandler(data, error);
        }
    }];
}

- (void)getForPath:(NSString *)path withParams:(NSDictionary *)params withTag:(NSUInteger)tag completionHandler:(void (^)(id data, NSError *error, NSInteger tag))completionHandler
{
    [self.sessionManager GET:path
                  parameters:params
                     success:^(NSURLSessionDataTask *task, id responseObject)
     {
         if (completionHandler) {
             completionHandler(responseObject, nil, tag);
         }
     }
                     failure:^(NSURLSessionDataTask *task, NSError *error)
     {
         if (completionHandler) {
             completionHandler(nil, error, tag);
         }
     }];
}

+ (void)downloadFile:(NSString *)fileUrl toPath:(NSString *)path completionHandler:(void (^)(id data, NSError *error))completionHandler
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", @"text/json", @"application/json", @"text/plain", nil];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:fileUrl]];
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request
                                                                     progress:nil
                                                                  destination:^NSURL *(NSURL *targetPath, NSURLResponse *response)
    {
        return [NSURL fileURLWithPath:path];
    }
                                                            completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error)
    {
        if (completionHandler) {
            completionHandler(filePath.path, error);
        }
    }];
    [downloadTask resume];
}

+ (void)uploadFile:(NSString *)filePath withFileName:(NSString *)fileName toPath:(NSString *)toPath completionHandler:(void (^)(id data, NSError *error))completionHandler
{
    NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:toPath]
                                                           cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                       timeoutInterval:60];
    NSString *bounary = @"AaB03x";
    NSString *endBounary = [[NSString alloc]initWithFormat:@"\r\n--%@--", bounary];
    
    NSMutableString *bodyStr = [[NSMutableString alloc] init];
    [bodyStr appendFormat:@"--%@\r\n", bounary];
    [bodyStr appendFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"%@\"\r\n", fileName];
    [bodyStr appendFormat:@"Content-Type: video/mpeg4\r\n\r\n"];
    
    NSMutableData *bodyData = [NSMutableData data];
    [bodyData appendData:[bodyStr dataUsingEncoding:NSUTF8StringEncoding]];
    [bodyData appendData:[NSData dataWithContentsOfFile:filePath]];
    [bodyData appendData:[endBounary dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSString *contentType=[[NSString alloc]initWithFormat:@"multipart/form-data; boundary=%@", bounary];
    [request setValue:contentType forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%zd", [bodyData length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:bodyData];
    [request setHTTPMethod:@"POST"];
    
    NSURLSession *urlSession = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [urlSession dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
    {
        if (completionHandler) {
            id responseObject = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            completionHandler(responseObject, error);
        }
    }];
    [dataTask resume];
}

+ (void)synchronousRequest:(NSString *)urlPath withParams:(NSDictionary *)params completionHandler:(void (^)(id data, NSError *error))completionHandler
{
    NSMutableString *json = [NSMutableString string];
    for (NSString *key in params.allKeys) {
        [json appendFormat:@"%@=%@,", key, params[key]];
    }
    NSError *error = nil;
    NSData *bodyData = [json dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    if (error) {
        if (completionHandler) {
            completionHandler(nil, error);
            return;
        }
    }

    NSString *bodyLength = [NSString stringWithFormat:@"%zd", bodyData.length];
    NSURL *url = [NSURL URLWithString:urlPath];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:bodyLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:bodyData];
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    if (completionHandler) {
        completionHandler(dict, error);
    }
}


@end
