//
//  OSession.h
//  CJSX
//
//  Created by 何振东 on 14-5-7.
//  Copyright (c) 2014年 CJTX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

/**
 *  网络交互主类。
 *  简化网络操作工具类。请求操作只返回成功数据代理，失败处理在本类里统一做处理。
 */

@interface OURLRequest : NSObject
/// 网络交互主操作类，所有的操作通过该实例完成。
@property (strong, nonatomic, readonly) AFHTTPSessionManager *sessionManager;

/// 网络交互基站点，可为域名或ip地址，必须在初始化时配置
@property (strong, nonatomic, readonly) NSURL *baseURL;


/**
 *  OURLRequest单例返回方法
 *
 *  @warning 应始终通过单例获取
 *  @return 返回OURLRequest单例
 */
+ (instancetype)sharedInstance;

- (void)cancelRequest;

/**
 *  post方式请求网络
 *
 *  @param path    请求地址的路径，无须路径则为nil。
 *  @param params  请求的参数，无须参数则为nil
 *  @param completionHandler 请求完成后进入的代理，返回相应的的数据或错误信息
 */
- (void)postForPath:(NSString *)path withParams:(NSDictionary *)params completionHandler:(void (^)(id data, NSError *error))completionHandler;

/// 带tag标记的post请求，其它如上
- (void)postForPath:(NSString *)path withParams:(NSDictionary *)params withTag:(NSUInteger)tag completionHandler:(void (^)(id data, NSError *error, NSInteger requestTag))completionHandler;

/**
 *  get方式请求网络
 *
 *  @param path    请求地址的路径，无须路径则为nil。
 *  @param params  请求的参数，无须参数则为nil
 *  @param completionHandler 请求完成后进入的代理，返回相应的的数据或错误信息
 */
- (void)getForPath:(NSString *)path withParams:(NSDictionary *)params completionHandler:(void (^)(id data, NSError *error))completionHandler;

/// 带tag标记的get请求，其它如上
- (void)getForPath:(NSString *)path withParams:(NSDictionary *)params withTag:(NSUInteger)tag completionHandler:(void (^)(id data, NSError *error, NSInteger requestTag))completionHandler;


/**
 *  下载文件
 *
 *  @param fileUrl 下载链接
 *  @param path    下载到所在的文件路径
 *  @param completionHandler 请求完成后进入的代理，返回相应的的数据或错误信息
 */
+ (void)downloadFile:(NSString *)fileUrl toPath:(NSString *)path completionHandler:(void (^)(id data, NSError *error))completionHandler;

/**
 *  上传文件
 *
 *  @param filePath          上传文件的路径
 *  @param fileName          上传的文件名
 *  @param toPath            上传目的地址链接
 *  @param completionHandler 请求完成后进入的代理，返回相应的的数据或错误信息
 */
+ (void)uploadFile:(NSString *)filePath withFileName:(NSString *)fileName toPath:(NSString *)toPath completionHandler:(void (^)(id data, NSError *error))completionHandler;

/**
 *  同步请求数据
 *
 *  @param urlPath           请求地址的完整url
 *  @param params            请求参数
 *  @param completionHandler 请求完成后进入的代理，返回相应的的数据或错误信息
 */
+ (void)synchronousRequest:(NSString *)urlPath withParams:(NSDictionary *)params completionHandler:(void (^)(id data, NSError *error))completionHandler;


@end
