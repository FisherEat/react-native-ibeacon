//
//  XMBeacon.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/14.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

/// 定义Beacon类型枚举变量
typedef NS_ENUM(NSInteger, XMBeaconType) {
    XMBeaconTypeAll        = -1,
    XMBeaconTypeTrip       = 0,
    XMBeaconTypeExhibition = 1,
    XMBeaconTypeMuseum     = 2,
    XMBeaconTypeFood       = 3,
    XMBeaconTypeDress      = 4,
    XMBeaconTypeCar        = 5,
};

@interface XMBeacon : NSObject
@property (copy, nonatomic) NSString *uuid;
@property (copy, nonatomic) NSString *major;
@property (copy, nonatomic) NSString *minor;
@property (copy, nonatomic) NSString *rssi;

@property (copy, nonatomic) NSString *beacon_id;
@property (copy, nonatomic) NSString *title;
@property (copy, nonatomic) NSString *img_url;
@property (copy, nonatomic) NSString *shop_id;
@property (copy, nonatomic) NSString *template_examples_id;
@property (copy, nonatomic) NSString *description;
@property (assign, nonatomic) NSInteger type;

@property (assign, nonatomic) NSInteger enter_times;
@property (assign, nonatomic) double last_update_date;

@property (assign, nonatomic) BOOL collected;
@property (assign, nonatomic) BOOL readed;


@end
