//
//  XMBeaconDetail.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/17.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMBeaconDetail.h"

@implementation XMBeaconDetail

@end
