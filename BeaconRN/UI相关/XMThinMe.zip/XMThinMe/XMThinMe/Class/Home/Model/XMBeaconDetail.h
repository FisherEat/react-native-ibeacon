//
//  XMBeaconDetail.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/17.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMBeacon.h"

@interface XMBeaconDetail : NSObject
@property (strong, nonatomic) XMBeacon *beacon;

@property (copy, nonatomic) NSString *audio_url;
@property (copy, nonatomic) NSString *content_1;
@property (copy, nonatomic) NSString *image_url;
@property (copy, nonatomic) NSString *shop_id;
@property (copy, nonatomic) NSString *template_examples_id;
@property (copy, nonatomic) NSString *template_examples_plate_title;
@property (copy, nonatomic) NSString *template_examples_title;

@property (copy, nonatomic) NSString *title_1;
@property (copy, nonatomic) NSString *video_url;

@end
