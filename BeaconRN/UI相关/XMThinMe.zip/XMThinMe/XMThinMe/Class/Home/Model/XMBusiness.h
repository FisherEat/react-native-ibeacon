//
//  BaseEntity.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/3.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMBusiness : NSObject
@property (copy, nonatomic) NSString *business_id;
@property (copy, nonatomic) NSString *business_name;
@property (copy, nonatomic) NSString *description;
@property (copy, nonatomic) NSString *logo_url;
@property (copy, nonatomic) NSString *address;

@property (assign, nonatomic) NSInteger      type;
@property (assign, nonatomic) NSTimeInterval start_time;
@property (assign, nonatomic) NSTimeInterval end_time;
@property (assign, nonatomic) CGFloat        ticket_price;

@property (assign, nonatomic) CGFloat latitude;
@property (assign, nonatomic) CGFloat longitude;

@property (copy, nonatomic) NSString *navigation_image;

@end
