//
//  XMHomeTypeView.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/18.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OView.h"

@interface XMHomeTypeView : UIControl
@property (assign, nonatomic) XMBeaconType type;

@property (copy, nonatomic) void (^selectedType) (NSInteger type, NSString *name);
@property (copy, nonatomic) void (^typeViewHide) (void);


- (void)showAtView:(UIView *)aView point:(CGPoint)point;
- (void)hide;

@end
