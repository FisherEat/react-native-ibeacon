//
//  XMHomeMessageView.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/7.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMHomeMessageCell.h"

@interface XMHomeMessageCell ()
@property (assign, nonatomic) BOOL       showing;
@property (strong, nonatomic) OView      *boxView;
@property (strong, nonatomic) OImageView *bgIV;
@property (strong, nonatomic) XMBeacon   *beacon;

@end

@implementation XMHomeMessageCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSeparatorStyleNone;
        
        self.bgIV = [[OImageView alloc] init];
        self.bgIV.image = [UIImage imageNamed:@"home_message_bg"];
        [self addSubview:self.bgIV];
        
        self.boxView = [[OView alloc] init];
        self.boxView.backgroundColor = kWhiteColor;
        self.boxView.userInteractionEnabled = NO;
        [self addSubview:self.boxView];
        
        self.thumbIV = [[OImageView alloc] init];
        self.thumbIV.image = [UIImage imageNamed:@"home_top_bg"];
        self.thumbIV.cornerRadius = 4;
        [self.thumbIV setBoderColor:mRGBToColor(0xe8e8e8) width:0.5];
        [self.boxView addSubview:self.thumbIV];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kFont(16);
        self.titleLbl.textColor = mRGBToColor(0x4b4b4b);
        [self.boxView addSubview:self.titleLbl];
        
        self.dateLbl = [[OLabel alloc] init];
        self.dateLbl.textColor = mRGBToColor(0x838383);
        self.dateLbl.font = kFont(12);
        [self.boxView addSubview:self.dateLbl];
        
        self.subtitleLbl = [[OLabel alloc] init];
        self.subtitleLbl.textColor = mRGBToColor(0xa4a4a4);
        self.subtitleLbl.font = kFont(14);
        self.subtitleLbl.numberOfLines = 2;
        [self.boxView addSubview:self.subtitleLbl];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.bgIV.frame = self.bounds;
    self.boxView.frame = CGRectMake(6, 10, self.width - 6 * 2, self.height - 20);
    self.thumbIV.frame = CGRectMake(9, (self.boxView.height-100)/2, 140, 100);
    self.titleLbl.frame = CGRectMake(self.thumbIV.right + 10, self.thumbIV.y+10, self.boxView.width - self.thumbIV.right - 15, 20);
    self.subtitleLbl.frame = CGRectMake(self.titleLbl.x, self.titleLbl.bottom, self.titleLbl.width, 40);
    self.dateLbl.frame = CGRectMake(self.titleLbl.x, self.subtitleLbl.bottom + 5, self.titleLbl.width, 20);
}

- (void)hideMessageView:(void (^) (void))completion
{
    self.showing = NO;

    [UIView animateWithDuration:0.45 animations:^{
    } completion:^(BOOL finished) {
        if (completion) {
            completion();
        }
    }];
}

- (void)showMessageViewWithBeacon:(XMBeacon *)beacon completion:(void (^)(void))completion
{
    self.showing = YES;
    self.beacon = beacon;
    
    self.titleLbl.text = beacon.title;
    self.subtitleLbl.text = beacon.description;
    NSURL *url = [NSURL URLWithString:beacon.img_url];
    [self.thumbIV setImageWithURL:url placeholderImage:kPlaceholderImage_rectangle];
    
    [UIView animateWithDuration:0.45 animations:^{
    } completion:^(BOOL finished) {
        if (completion) {
            completion();
        }
    }];
}


@end
