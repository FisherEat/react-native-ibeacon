//
//  XMHomeMessageView.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/7.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OView.h"
#import "XMBeacon.h"

@interface XMHomeMessageCell : OCell
@property (strong, nonatomic) OImageView *thumbIV;
@property (strong, nonatomic) OLabel     *titleLbl;
@property (strong, nonatomic) OLabel     *dateLbl;
@property (strong, nonatomic) OLabel     *subtitleLbl;

/// 判断消息是否在显示中
@property (assign, nonatomic, readonly) BOOL showing;

/// 显示的数据模型
@property (strong, nonatomic, readonly) XMBeacon *beacon;

///
- (void)showMessageViewWithBeacon:(XMBeacon *)beacon completion:(void (^) (void))completion;

- (void)hideMessageView:(void (^) (void))completion;

@end
