//
//  XMHomeExhibitionCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/17.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMHomeExhibitionCell.h"

@implementation XMHomeExhibitionCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.thumbIV = [[OImageView alloc] init];
        self.thumbIV.cornerRadius = 4;
        [self.thumbIV setBoderColor:mRGBToColor(0xe8e8e8) width:0.5];
        [self.contentView addSubview:self.thumbIV];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kFont(16);
        self.titleLbl.textColor = mRGBToColor(0x4b4b4b);
        self.titleLbl.numberOfLines = 2;
        [self.contentView addSubview:self.titleLbl];
        
        self.addressLbl = [[OLabel alloc] init];
        self.addressLbl.textColor = mRGBToColor(0xa4a4a4);
        self.addressLbl.font = kFont(14);
        [self.contentView addSubview:self.addressLbl];
        
        self.dateLbl = [[OLabel alloc] init];
        self.dateLbl.font = kFont(12);
        self.dateLbl.textColor = mRGBToColor(0x838383);
        [self.contentView addSubview:self.dateLbl];
        
//        self.priceLbl = [[OLabel alloc] init];
//        self.priceLbl.textColor = mRGBToColor(0xa4a4a4);
//        self.priceLbl.adjustsFontSizeToFitWidth = YES;
//        self.priceLbl.font = kFont(12);
//        self.priceLbl.textAlignment = NSTextAlignmentRight;
//        [self.contentView addSubview:self.priceLbl];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.thumbIV.frame = CGRectMake(10, (self.height-80)/2, 120, 80);
    self.titleLbl.frame = CGRectMake(self.thumbIV.right + 11, 11, self.width - self.thumbIV.right - 14, 30);
    self.addressLbl.frame = CGRectMake(self.titleLbl.x, self.titleLbl.bottom, self.titleLbl.width, 15);
    self.dateLbl.frame = CGRectMake(self.titleLbl.x, self.height - 28, 160, 15);
    self.priceLbl.frame = CGRectMake(self.width - 48, self.dateLbl.y, 40, self.dateLbl.height);
}

- (void)configureCellWithCellData:(XMBusiness *)business
{
    NSDate *startDate  = [NSDate dateWithTimeIntervalSince1970:business.start_time];
    NSDate *endDate    = [NSDate dateWithTimeIntervalSince1970:business.end_time];
    NSString *startStr = [[[NVDate alloc] initUsingDate:startDate] stringValueWithFormat:@"YYYY年MM月dd日"];
    NSString *endStr   = [[[NVDate alloc] initUsingDate:endDate] stringValueWithFormat:@"MM月dd日"];
    if (business.type == XMBeaconTypeTrip) {
        startStr = [[[NVDate alloc] initUsingDate:startDate] stringValueWithFormat:@"HH:mm"];
        endStr = [[[NVDate alloc] initUsingDate:endDate] stringValueWithFormat:@"HH:mm"];
    } else if (business.type == XMBeaconTypeExhibition) {
        
    }

    NSURL *imgUrl = [NSURL URLWithString:business.logo_url];
    [self.thumbIV setImageWithURL:imgUrl placeholderImage:kPlaceholderImage_rectangle];
    self.titleLbl.text = business.business_name;
    self.addressLbl.text = business.address;
    self.dateLbl.text = [NSString stringWithFormat:@"%@—%@", startStr, endStr];
    
    if (business.ticket_price > 0) {
        self.priceLbl.text = [NSString stringWithFormat:@"￥%.f", business.ticket_price];
    } else if (business.type == XMBeaconTypeExhibition) {
        self.priceLbl.text = @"免费";
    }
}

+ (CGFloat)cellHeightForCellData:(id)cellData
{
    return 100;
}


@end
