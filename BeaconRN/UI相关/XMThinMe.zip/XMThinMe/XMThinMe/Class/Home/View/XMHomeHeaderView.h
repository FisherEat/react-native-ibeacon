//
//  XMHomeHeaderView.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/17.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OView.h"

#define kTripButtonTag 0
#define kExhibitionTag 1


@interface XMHomeHeaderView : OView
@property (strong, nonatomic) OButton     *mapBtn;
@property (strong, nonatomic) OButton     *cityBtn;
@property (strong, nonatomic) OButton     *footprintBtn;
@property (strong, nonatomic) UISearchBar *searchBar;
@property (strong, nonatomic) UIControl   *searchBgView;
@property (assign, nonatomic) NSInteger   selectedType;

@property (strong, nonatomic) OButton     *typeBtn;

/// 未读数
@property (assign, nonatomic) NSInteger   unreadCount;


@end
