//
//  XMHomeHeaderView.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/17.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMHomeHeaderView.h"

@interface XMHomeHeaderView ()
@property (strong, nonatomic) OImageView *bgIV;
@property (strong, nonatomic) UILabel    *footprintCountLbl;

@end

@implementation XMHomeHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kWhiteColor;
        self.selectedType = kTripButtonTag;
        
        self.bgIV = [[OImageView alloc] initWithFrame:CGRectMake(0, -160, self.width, 260)];
        self.bgIV.image = [UIImage imageNamed:@"home_top_bg"];
        [self addSubview:self.bgIV];
        
        self.mapBtn = [[OButton alloc] initWithFrame:CGRectMake(15, 35, 60, 65)];
        [self.mapBtn setImage:[UIImage imageNamed:@"home_location_normal"] forState:UIControlStateNormal];
        [self.mapBtn setImage:[UIImage imageNamed:@"home_location_highlighted"] forState:UIControlStateHighlighted];
        [self addSubview:self.mapBtn];
        
        self.cityBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.cityBtn.frame = CGRectMake(self.mapBtn.right + 5, self.mapBtn.y + 10, 100, 25);
        self.cityBtn.titleLabel.font = kB_Font(19);
        [self.cityBtn setTitleColor:mRGB(122, 84, 56) forState:UIControlStateNormal];
        self.cityBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [self addSubview:self.cityBtn];
        
        self.typeBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.typeBtn setTitle:@"全部" forState:UIControlStateNormal];
        self.typeBtn.frame = CGRectMake(self.cityBtn.x, self.cityBtn.bottom + 0, 140, 25);
        self.typeBtn.titleLabel.font = kFont(14);
        self.typeBtn.showsTouchWhenHighlighted = YES;
        [self.typeBtn setTitleColor:mRGB(122, 84, 56) forState:UIControlStateNormal];
        self.typeBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        self.typeBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        self.typeBtn.imageEdgeInsets = UIEdgeInsetsMake(0, self.typeBtn.titleLabel.width - (mIsiP4 ? 0:3), 0, 0);
        self.typeBtn.tintColor = mRGB(122, 84, 56);
        [self.typeBtn setImage:[[UIImage imageNamed:@"home_down_arrow"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
        [self addSubview:self.typeBtn];
        
        self.searchBgView = [[UIControl alloc] initWithFrame:CGRectMake(0, self.bgIV.bottom, self.width, 44)];
        self.searchBgView.backgroundColor = mRGB(232, 232, 232);
        [self addSubview:self.searchBgView];
        
        self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, self.bgIV.bottom, self.width-85, 44)];
        self.searchBar.placeholder = @"搜索";
        self.searchBar.textField.backgroundColor = kWhiteColor;
        self.searchBar.userInteractionEnabled = NO;
        self.searchBar.backgroundImage = [UIImage grabImageWithView:self.searchBgView scale:1];
        [self addSubview:self.searchBar];
        
        self.footprintBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.footprintBtn.frame = CGRectMake(self.width - 77 - 7, self.bgIV.bottom - 77/2-2, 77, 77);
        [self.footprintBtn setImage:[UIImage imageNamed:@"home_footprint"] forState:UIControlStateNormal];
        [self addSubview:self.footprintBtn];
        
        self.footprintCountLbl = [[UILabel alloc] initWithFrame:CGRectMake(self.footprintBtn.width - 25, 10, 24, 20)];
        self.footprintCountLbl.backgroundColor = kRedColor;
        self.footprintCountLbl.cornerRadius = 10;
        self.footprintCountLbl.font = kFont(13);
        self.footprintCountLbl.textColor = kWhiteColor;
        self.footprintCountLbl.textAlignment = NSTextAlignmentCenter;
        [self.footprintBtn addSubview:self.footprintCountLbl];
        
        self.unreadCount = [[XMDBManager sharedInstance] unreadBeaconList].count;
    }
    return self;
}

- (void)setUnreadCount:(NSInteger)unreadCount
{
    if (unreadCount < 0) {
        return;
    }
    mWeakSelf;
    _unreadCount = unreadCount;
    self.footprintCountLbl.text = [NSString stringWithFormat:@"%zd", unreadCount];
    if (unreadCount == 0) {
        [UIView animateWithDuration:0.1 animations:^{
            weakSelf.footprintCountLbl.width = 0;
        }];
    } else if (unreadCount < 10 && unreadCount > 0) {
        [UIView animateWithDuration:0.1 animations:^{
            weakSelf.footprintCountLbl.width = 20;
        }];
    } else if (unreadCount < 100 && unreadCount >= 10) {
        [UIView animateWithDuration:0.1 animations:^{
            weakSelf.footprintCountLbl.width = 24;
        }];
    } else {
        [UIView animateWithDuration:0.1 animations:^{
            weakSelf.footprintCountLbl.width = 30;
        }];
    }
}


@end
