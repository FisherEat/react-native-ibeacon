//
//  XMHomeTypeView.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/18.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMHomeTypeView.h"

#define kRank 3

@interface XMHomeTypeView ()
@property (strong, nonatomic) NSArray   *titles;
@property (strong, nonatomic) NSArray   *normalImages;
@property (strong, nonatomic) NSArray   *highlightedImages;

@property (strong, nonatomic) UIToolbar *bgBar;

@property (strong, nonatomic) UIControl *bgView;

@property (strong, nonatomic) UIView *shadowView;

/// 类型映射字典
@property (strong, nonatomic) NSDictionary *typeDict;

@end

@implementation XMHomeTypeView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:[UIScreen mainScreen].bounds];
    if (self) {
        self.backgroundColor = kClearColor;
        
        self.bgView = [[UIControl alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
        self.bgView.backgroundColor = [kBlackColor colorWithAlphaComponent:0.3];
        [self.bgView addTarget:self action:@selector(hide) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.bgView];
        
        self.bgBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.width, 220)];
        [self addSubview:self.bgBar];
        
        self.type = XMBeaconTypeAll;
        
        self.typeDict = @{@(0): @(XMBeaconTypeAll),
                          @(1): @(XMBeaconTypeExhibition),
                          @(2): @(XMBeaconTypeCar),
                          @(3): @(XMBeaconTypeTrip),
                          @(4): @(XMBeaconTypeFood),
                          @(5): @(XMBeaconTypeDress)};
        
        self.titles = @[@"全部", @"展会", @"汽车",  @"景点", @"餐厅", @"服装"];
        self.normalImages = @[[UIImage imageNamed:@"home_category_all_normal"],
                              [UIImage imageNamed:@"home_category_exhibition_normal"],
                              [UIImage imageNamed:@"home_category_car_normal"],
                              [UIImage imageNamed:@"home_category_trip_normal"],
                              [UIImage imageNamed:@"home_category_food_normal"],
                              [UIImage imageNamed:@"home_category_dress_normal"]];
        self.highlightedImages = @[[UIImage imageNamed:@"home_category_all_highlighted"],
                                   [UIImage imageNamed:@"home_category_exhibition_highlighted"],
                                   [UIImage imageNamed:@"home_category_car_highlighted"],
                                   [UIImage imageNamed:@"home_category_trip_highlighted"],
                                   [UIImage imageNamed:@"home_category_food_highlighted"],
                                   [UIImage imageNamed:@"home_category_dress_highlighted"]];
        
        for (int i = 0; i < self.titles.count; i++) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            NSInteger row = floor(i / kRank);
            static NSInteger rank = 0;
            btn.frame = CGRectMake(self.width/3 * rank, self.width/3 * row, self.width/3, self.width/3);
            [btn setTitle:self.titles[i] forState:UIControlStateNormal];
            [btn setImage:self.normalImages[i] forState:UIControlStateNormal];
            [btn setTitleColor:mRGB(122, 84, 56) forState:UIControlStateNormal];
            btn.imageEdgeInsets = UIEdgeInsetsMake(0, 15, 15, 0);
            btn.titleEdgeInsets = UIEdgeInsetsMake(btn.imageView.bottom, -60, 0, 0);
            btn.tag = i;
            btn.titleLabel.font = kFont(15);
            [btn addTarget:self action:@selector(typeButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
            [btn setImage:self.highlightedImages[i] forState:UIControlStateHighlighted];
            [self.bgBar addSubview:btn];
            
            rank++;
            if (rank >= kRank) {
                rank = 0;
            }
        }
        
        [self addTarget:self action:@selector(hide) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)typeButtonClicked:(UIButton *)sender
{
    [self hide];
    
    self.type = [self.typeDict[@(sender.tag)] integerValue];
    
    if (self.selectedType) {
        self.selectedType([self.typeDict[@(sender.tag)] integerValue], self.titles[sender.tag]);
    }
}

- (void)showAtView:(UIView *)aView point:(CGPoint)point
{
    self.alpha = 1.0;
    [aView addSubview:self];
    
    self.bgBar.y = point.y;
    self.bgBar.alpha = 0;
    self.bgView.y = point.y;
    
    mWeakSelf;
    [UIView animateWithDuration:0.45 animations:^{
        weakSelf.bgBar.alpha = 1;
    }];
}

- (void)hide
{
    mWeakSelf;
    [UIView animateWithDuration:0.45 animations:^{
        weakSelf.bgBar.alpha = 0.0;
        weakSelf.alpha = 0;
    } completion:^(BOOL finished) {
    }];
    
    if (self.typeViewHide) {
        self.typeViewHide();
    }
}

@end
