//
//  XMHomeVC.m
//  XMMuseum
//
//  Created by 何振东 on 14-6-16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMHomeVC.h"
#import "XMFootprintVC.h"
#import "XMBeaconListVC.h"
#import "XMNearbyBeaconManager.h"
#import "XMHomeExhibitionCell.h"
#import "XMHomeHeaderView.h"
#import "XMSearchVC.h"
#import "XMExhibitionVC.h"
#import "XMMapVC.h"
#import "XMBusiness.h"
#import "XMTripVC.h"
#import "XMTripLayout.h"
#import "XMBeacon.h"
#import "XMHomeMessageCell.h"
#import "XMExhibitionShopVC.h"
#import "XMTripSpotDetailVC.h"
#import "XMBeaconDetail.h"
#import "XMHomeTypeView.h"
#import "XMExhibitionShopCell.h"

static NSString *const messageCellIdentifier = @"messageCellIdentifier";
static NSString *const shopCellIdentifier    = @"shopCell";

@interface XMHomeVC ()
/// 附近的基站管理器
@property (strong, nonatomic) XMNearbyBeaconManager  *nearbyBeaconManager;

@property (strong, nonatomic) NSMutableArray         *tableData;

@property (strong, nonatomic) XMHomeHeaderView       *headerView;

@property (strong, nonatomic) UIView                 *statusBar;

@property (strong, nonatomic) XMHomeTypeView         *homeTypeView;

@property (strong, nonatomic) XMBeacon               *beacon;

@property (assign, nonatomic) CLLocationCoordinate2D userLocation;

/// 显示beacon消息的定时器
@property (strong, nonatomic) NSTimer                *showBeaconTimer;

@property (assign, nonatomic) NSInteger              pageIndex;

@end


@implementation XMHomeVC

- (id)init
{
    self = [super init];
    if (self) {
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_home_normal"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_home_highlighted"];
        self.tabBarItem.title = @"首页";

        self.pageIndex = 0;
        self.tableData = @[].mutableCopy;
        self.nearbyBeaconManager = [[XMNearbyBeaconManager alloc] init];
        
//        mWeakSelf;
//        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] bk_initWithTitle:@"beacons" style:0 handler:^(id sender) {
//            XMBeaconListVC *beaconListVC = [[XMBeaconListVC alloc] init];
//            [weakSelf.navigationController pushViewController:beaconListVC animated:YES];
//        }];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    self.tableView.bounces = NO;
    
    mWeakSelf;
    self.headerView = [[XMHomeHeaderView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 154)];
    [self.headerView.searchBgView bk_addEventHandler:^(id sender) {
        XMSearchVC *searchVC = [[XMSearchVC alloc] init];
        ONavController *searchNC = [[ONavController alloc] initWithRootViewController:searchVC];
        [weakSelf presentViewController:searchNC animated:YES completion:nil];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.headerView.footprintBtn bk_addEventHandler:^(id sender) {
        XMFootprintVC *footprintVC = [[XMFootprintVC alloc] init];
        footprintVC.hidesBottomBarWhenPushed = YES;
        [weakSelf.navigationController pushViewController:footprintVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.headerView.mapBtn bk_addEventHandler:^(UIButton *sender) {
        XMMapVC *mapVC = [[XMMapVC alloc] init];
        [weakSelf.navigationController pushViewController:mapVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.headerView.typeBtn bk_addEventHandler:^(UIButton *sender) {
        [sender.imageView setRotation:180 finished:nil];
        CGPoint point = [mKeyWindow convertPoint:sender.frame.origin fromView:weakSelf.headerView];
        [weakSelf.homeTypeView showAtView:mKeyWindow point:CGPointMake(point.x, point.y + sender.height + 5)];
    } forControlEvents:UIControlEventTouchUpInside];
    
    self.homeTypeView = [[XMHomeTypeView alloc] initWithFrame:mKeyWindow.bounds];
    self.homeTypeView.selectedType = ^(NSInteger type, NSString *name) {
        weakSelf.pageIndex = 0;
        [weakSelf.tableData removeAllObjects];
        NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:1];
        [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        [weakSelf getShopListByType:type];
        [weakSelf.headerView.typeBtn setTitle:name forState:UIControlStateNormal];
    };
    self.homeTypeView.typeViewHide = ^(){
        [weakSelf.headerView.typeBtn.imageView setRotation:0 finished:nil];
    };
    
    self.tableView.contentInset = UIEdgeInsetsMake(-self.navigationController.navigationBar.height-20, 0, 0, 0);
    [self.tableView registerClass:[XMExhibitionShopCell class] forCellReuseIdentifier:shopCellIdentifier];
    [self.tableView registerClass:[XMHomeMessageCell class] forCellReuseIdentifier:messageCellIdentifier];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.tableView addFooterWithCallback:^{
        [weakSelf getShopListByType:weakSelf.homeTypeView.type];
    }];

    self.statusBar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 20)];
    self.statusBar.backgroundColor = kWhiteColor;
    self.statusBar.alpha = 0;
    [mKeyWindow addSubview:self.statusBar];

    [self startBeaconManager];
    
    XMLocationManager *locationManager = [XMLocationManager manager];
    [locationManager updateUserLocation:^(BMKUserLocation *userLocation, NSError *error) {
        weakSelf.userLocation = userLocation.location.coordinate;
        [weakSelf.tableData removeAllObjects];
        NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:1];
        [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];

        [weakSelf getShopListByType:XMBeaconTypeAll];
        
        [locationManager.locationService stopUserLocationService];
        [locationManager reverseCoordinate:userLocation.location.coordinate completionHandle:^(BMKReverseGeoCodeResult *result, BMKSearchErrorCode errorCode)
        {
            if (result.addressDetail.city) {
                [weakSelf.headerView.cityBtn setTitle:result.addressDetail.city forState:UIControlStateNormal];
            } else {
                [weakSelf.headerView.cityBtn setTitle:@"未知" forState:UIControlStateNormal];
            }
        }];
    }];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.statusBar.hidden = NO;
    [self hideNavigationBarBackground];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    self.headerView.unreadCount = [[XMDBManager sharedInstance] unreadBeaconList].count;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self showNavigationBarBackground];
    
    [self.homeTypeView hide];
    self.statusBar.hidden = YES;
}

- (void)startBeaconManager
{
    mWeakSelf;
    [[XMBeaconManager sharedBeacon] startMonitor];
    [XMBeaconManager sharedBeacon].bluetoothStateChanged = ^(CBPeripheralManagerState state){
        if (state != CBPeripheralManagerStatePoweredOn) {
            /// 若蓝牙关闭，则最后一次显示10s，然后消失
            [weakSelf bk_performBlock:^(id obj) {
                weakSelf.beacon = nil;
                NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:0];
                [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationBottom];
            } onQueue:dispatch_get_main_queue() afterDelay:10];
        }
    };
    [XMBeaconManager sharedBeacon].findNearestBeacon = ^(CLBeacon *beacon)
    {
        if (!beacon) {
            [self.nearbyBeaconManager startDelayTimerFinished:nil];
            return ;
        }
        
        NSString *beaconId = [NSString stringWithFormat:@"%@%@", [beacon.major toHex], [beacon.minor toHex]];

        /// 若本地数据库已缓存数据，则显示，若没有数据，则请求网络数据
        XMBeacon *aBeacon = [[XMDBManager sharedInstance] beaconInfoForBeaconId:beaconId];
        if (aBeacon) {
            [[XMDBManager sharedInstance] updateEnterTimesForBeaconId:aBeacon.beacon_id];
            [self showBeaconInfo:aBeacon playSoundAndVibrate:NO];
        }
        else {
            NSDictionary *params = @{@"uuid": beacon.proximityUUID.UUIDString,
                                     @"major": [beacon.major toHex],
                                     @"minor": [beacon.minor toHex],
                                     @"beacon_id": beaconId};
            [self getBeaconInfoWithParams:params];
        }
    };
}

- (void)showBeaconInfo:(XMBeacon *)beacon playSoundAndVibrate:(BOOL)play
{
    if ([XMBeaconManager sharedBeacon].peripheralManager.state != CBPeripheralManagerStatePoweredOn) {
        self.beacon = nil;
        return;
    }
    
    if ([beacon.beacon_id isEqualToString:self.beacon.beacon_id]) {
        return;
    }

    self.headerView.unreadCount = [[XMDBManager sharedInstance] unreadBeaconList].count;

    // 开启延时显示定时器
    if (!self.showBeaconTimer) {
        self.showBeaconTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(showBeaconTimer:) userInfo:nil repeats:YES];
        [self.showBeaconTimer fire];
    }
    
    self.beacon = beacon;

    if ([UIApplication sharedApplication].applicationState == UIApplicationStateBackground) {
        [[XMNotificationManager sharedInstance] showNotificationWithMessage:beacon.title];
    } else {
        if (play) {
            [[XMNotificationManager sharedInstance] playSystemSoundAndVibrate];
        }
    }
    
    // 显示消息，并且滑动到最开始展示
    NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:0];
    [self.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationFade];

    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)showBeaconTimer:(NSTimer *)timer
{
    static NSInteger count = 0;
    if (count >= 3) {
        count=0;
        [self.showBeaconTimer invalidate];
        self.showBeaconTimer = nil;
    }
}


#pragma tableView Delegate && DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        if ([XMBeaconManager sharedBeacon].peripheralManager.state != CBPeripheralManagerStatePoweredOn) {
            return 0;
        }
        if (self.beacon) {
            return 1;
        } else {
            return 0;
        }
    }
    return self.tableData.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 100+44;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return self.headerView;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 140;
    }
    return 100;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        XMHomeMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:messageCellIdentifier];
        [cell showMessageViewWithBeacon:self.beacon completion:nil];
        return cell;
    }

    XMExhibitionShopCell *cell = [tableView dequeueReusableCellWithIdentifier:shopCellIdentifier];
    cell.backgroundColor = kClearColor;
    cell.backgroundView.backgroundColor = kClearColor;
    [cell configureCellWithCellData:self.tableData[indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        XMShop *shop = [[XMShop alloc] init];
        shop.shop_id = self.beacon.shop_id;
        shop.shop_name = self.beacon.title;
        shop.description = self.beacon.description;
        if (self.beacon.type == XMBeaconTypeTrip) {
            XMTripVC *tripVC = [[XMTripVC alloc] initWithCollectionViewLayout:[[XMTripLayout alloc] init]];
            tripVC.shop = shop;
            tripVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:tripVC animated:YES];
        }
        else {
            XMExhibitionShopVC *exhibitionDetailVC = [[XMExhibitionShopVC alloc] init];
            exhibitionDetailVC.shop = shop;
            exhibitionDetailVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:exhibitionDetailVC animated:YES];
        }
        return;
    }
    
    XMShop *shop = self.tableData[indexPath.row];
    if (shop.type == XMBeaconTypeTrip) {
        XMTripVC *tripVC = [[XMTripVC alloc] initWithCollectionViewLayout:[[XMTripLayout alloc] init]];
        tripVC.shop = shop;
        tripVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:tripVC animated:YES];
    } else {
        XMExhibitionShopVC *exhibitionShopVC = [[XMExhibitionShopVC alloc] init];
        exhibitionShopVC.shop = shop;
        exhibitionShopVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:exhibitionShopVC animated:YES];
    }
}


#pragma mark - scrollview delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    mWeakSelf;
    if (scrollView.contentOffset.y > 84) {
        [UIView animateWithDuration:0.45 animations:^{
            weakSelf.statusBar.alpha = 1;
        }];
    } else {
        [UIView animateWithDuration:0.45 animations:^{
            weakSelf.statusBar.alpha = 0;
        }];
    }
}


#pragma mark - network handle

- (void)getBeaconInfoWithParams:(NSDictionary *)aParams
{
    mWeakSelf;
    NSDictionary *params = @{@"beacon_id": aParams[@"beacon_id"],
                             @"user_id": [[XMUserManager sharedInstance] userId],
                             @"device_type": @([XMAppManager platform])};
    [[OURLRequest sharedInstance] postForPath:N_Beacon_GetEntityBasicInfo withParams:params completionHandler:^(NSArray *data, NSError *error) {
        if (!error) {
            NSData *jsonObject = [NSJSONSerialization dataWithJSONObject:[data firstObject] options:NSJSONWritingPrettyPrinted error:nil];
            XMBeacon *beacon = [[XMBeacon alloc] initWithJSONData:jsonObject];
            beacon.beacon_id = params[@"beacon_id"];
            beacon.uuid = aParams[@"uuid"];
            beacon.major = aParams[@"major"];
            beacon.minor = aParams[@"minor"];
            beacon.rssi = aParams[@"rssi"];
            
            [[XMDBManager sharedInstance] updateBeaconInfo:beacon];
            [weakSelf showBeaconInfo:beacon playSoundAndVibrate:YES];
        }
    }];
}

- (void)getShopListByType:(XMBeaconType)type
{
    mWeakSelf;
    NSDictionary *params = @{@"type": @(type),
                             @"user_longitude": @(self.userLocation.longitude),
                             @"user_latitude": @(self.userLocation.latitude),
                             @"page_index": @(self.pageIndex),
                             @"page_size": @(10),
                             @"user_id": [[XMUserManager sharedInstance] userId],
                             @"device_type": @([XMAppManager platform])};
    [[OURLRequest sharedInstance] postForPath:N_Shop_GetEntityListPlus withParams:params completionHandler:^(id data, NSError *error) {
        [weakSelf.tableView footerEndRefreshing];
        
        if (!error) {
            weakSelf.pageIndex++;
            
            for (NSDictionary *dict in data) {
                NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                XMShop *shop = [[XMShop alloc] initWithJSONData:objectData];
                [weakSelf.tableData addObject:shop];
            }
            
            NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:1];
            [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }];
}



@end
