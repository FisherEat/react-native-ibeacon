//
//  XMComment.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/16.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMComment : NSObject
@property (copy, nonatomic  ) NSString       *comment_id;
@property (copy, nonatomic  ) NSString       *comment_title;
@property (copy, nonatomic  ) NSString       *comment_content;
@property (copy, nonatomic  ) NSString       *head_image;
@property (copy, nonatomic  ) NSString       *ip_address;
@property (copy, nonatomic  ) NSString       *nick_name;
@property (copy, nonatomic  ) NSString       *user_id;
@property (assign, nonatomic) NSTimeInterval comment_time;


@end
