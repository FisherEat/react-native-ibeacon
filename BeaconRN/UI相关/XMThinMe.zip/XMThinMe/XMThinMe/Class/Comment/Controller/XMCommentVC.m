//
//  XMCommentVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMCommentVC.h"
#import "XMCommentCell.h"
#import "XMCommentBar.h"
#import "XMComment.h"

@interface XMCommentVC () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
@property (strong, nonatomic) UITableView    *tableView;

@property (strong, nonatomic) NSMutableArray *tableData;
@property (strong, nonatomic) XMCommentBar *commentBar;
@property (assign, nonatomic) NSInteger pageIndex;

@end

@implementation XMCommentVC

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = [NSString stringWithFormat:@"%@的评论", self.product.product_name ? self.product.product_name:self.shop.shop_name];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height - 44)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = mRGB(232, 232, 232);
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    [self.view addSubview:self.tableView];
    
    [mNotificationCenter addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [mNotificationCenter addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    mWeakSelf;
    self.commentBar = [[XMCommentBar alloc] initWithFrame:CGRectMake(0, self.tableView.bottom, self.view.width, 44)];
    self.commentBar.commentTF.delegate = self;
    self.commentBar.commentTF.bk_shouldReturnBlock = ^(UITextField *tf){
        [tf resignFirstResponder];
        [weakSelf sendComent:tf.text completion:^(BOOL success, XMComment *comment) {
            if (success) {
                tf.text = @"";
                [XMProgressHUD showTips:@"评论成功！" atView:weakSelf.view];
                [weakSelf.tableData insertObject:comment atIndex:0];
                [weakSelf.tableView reloadData];
            } else {
                [XMProgressHUD showTips:@"评论失败！" atView:weakSelf.view];
            }
        }];
        return YES;
    };
    [self.view addSubview:self.commentBar];

    self.tableData = @[].mutableCopy;
    
    [self.tableView addFooterWithCallback:^{
        [weakSelf requestCommentList];
    }];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGRect rect = CGRectMake(0, self.tableView.contentSize.height+246, self.tableView.width, self.tableView.height);
    [self.tableView scrollRectToVisible:rect animated:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self requestCommentList];
    [self.tableView reloadData];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}


#pragma mark - delegate && datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.tableData.count;
}
//
//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    return 44;
//}
//
//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    return self.commentBar;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [XMCommentCell cellHeightForCellData:self.tableData[indexPath.row]];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"commentCell";
    XMCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMCommentCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    [cell configureCellWithCellData:self.tableData[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark - network request

- (void)sendComent:(NSString *)comment completion:(void (^) (BOOL success, XMComment *comment))completion
{
    if (!self.product.product_id  && !self.shop.shop_id) {
        return;
    }
    
    if (comment.length == 0) {
        return;
    }

    NSMutableDictionary *params = @{@"device_type": @([XMAppManager platform]),
                                    @"user_id":[XMUserManager sharedInstance].userId,
                                    @"comment_title": @"",
                                    @"comment_content": comment,
                                    @"ip_address": @""}.mutableCopy;
    if (self.product.product_id) {
        params[@"use_id"] = self.product.product_id;
    } else {
        params[@"use_id"] = self.shop.shop_id;
    }
        
    [[OURLRequest sharedInstance] postForPath:N_Product_AddEntityComment withParams:params completionHandler:^(id data, NSError *error)
     {
         if (error) {
             completion(NO, nil);
         } else {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:data options:0 error:nil];
             XMComment *comment = [[XMComment alloc] initWithJSONData:objectData];
             completion(YES, comment);
         }
     }];
}

- (void)requestCommentList
{
    if (!self.product.product_id  && !self.shop.shop_id) {
        return;
    }
    mWeakSelf;
    NSDictionary *params = @{@"use_id": self.product.product_id ? self.product.product_id : self.shop.shop_id,
                             @"device_type": @([XMAppManager platform]),
                             @"user_id": [XMUserManager sharedInstance].userId,
                             @"page_index": @(self.pageIndex),
                             @"page_size": @"10"};
    [[OURLRequest sharedInstance] postForPath:N_Product_GetEntityCommentList withParams:params completionHandler:^(id data, NSError *error)
     {
         [weakSelf.tableView footerEndRefreshing];
         if (!error) {
             weakSelf.pageIndex++;
             for (NSDictionary *dict in data) {
                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                 XMComment *comment = [[XMComment alloc] initWithJSONData:objectData];
                 [weakSelf.tableData addObject:comment];
             }
             NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:0];
             [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
         }
     }];
}

#pragma mark keyboard notification

- (void)keyboardWillShow:(NSNotification *)notification
{
    float animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGFloat keyboardHeight = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    self.tableView.contentInset = UIEdgeInsetsMake(keyboardHeight + mNavHeight, 0, 0, 0);
    mWeakSelf;
    [UIView animateWithDuration:animationDuration animations:^{
        weakSelf.tableView.y = -keyboardHeight;
        weakSelf.commentBar.y = weakSelf.tableView.bottom;
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    self.tableView.contentInset = UIEdgeInsetsMake(mNavHeight, 0, 0, 0);
    mWeakSelf;
    [UIView animateWithDuration:0.45 animations:^{
        weakSelf.tableView.y = 0;
        weakSelf.commentBar.y = weakSelf.tableView.bottom;
    }];
}



@end
