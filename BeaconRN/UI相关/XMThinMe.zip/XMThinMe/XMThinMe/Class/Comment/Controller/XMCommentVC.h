//
//  XMCommentVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"
#import "XMProduct.h"
#import "XMShop.h"

@interface XMCommentVC : OViewController
@property (strong, nonatomic) XMProduct *product;
@property (strong, nonatomic) XMShop *shop;

@end
