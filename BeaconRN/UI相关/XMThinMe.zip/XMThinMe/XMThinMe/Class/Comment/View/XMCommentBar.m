//
//  XMCommentBar.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/16.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMCommentBar.h"

@implementation XMCommentBar

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = mRGB(242, 242, 242);
        UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 25, 25)];
        leftView.image = [UIImage imageNamed:@"comment_logo"];
        self.commentTF = [[OTextField alloc] initWithFrame:CGRectMake(10, 7, self.width - 20, 30)];
        self.commentTF.leftView = leftView;
        self.commentTF.placeholder = @"写评论";
        self.commentTF.layer.borderColor = kGrayColor.CGColor;
        self.commentTF.layer.borderWidth = 0.3;
        self.commentTF.cornerRadius = 8;
        self.commentTF.clearButtonMode = UITextFieldViewModeNever;
        self.commentTF.returnKeyType = UIReturnKeySend;
        [self addSubview:self.commentTF];
    }
    return self;
}

@end
