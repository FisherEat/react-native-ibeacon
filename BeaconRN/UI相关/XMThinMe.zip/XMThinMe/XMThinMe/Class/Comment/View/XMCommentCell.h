//
//  XMCommentCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"
#import "XMComment.h"

@interface XMCommentCell : OCell
@property (strong, nonatomic) OImageView *avatarIV;
@property (strong, nonatomic) OLabel *dateLbl;
@property (strong, nonatomic) OLabel *contentLbl;
@property (strong, nonatomic) OLabel *titleLbl;

@end
