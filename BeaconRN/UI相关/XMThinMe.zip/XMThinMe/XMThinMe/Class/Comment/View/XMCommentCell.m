//
//  XMCommentCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMCommentCell.h"

@implementation XMCommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier];
    if (self) {
        self.avatarIV = [[OImageView alloc] init];
        self.avatarIV.image = [UIImage imageNamed:@"exhibition_location_normal"];
        [self.contentView addSubview:self.avatarIV];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kB_SmallFont;
        [self.contentView addSubview:self.titleLbl];
        
        self.dateLbl = [[OLabel alloc] init];
        self.dateLbl.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.dateLbl];
        
        self.contentLbl = [[OLabel alloc] init];
        self.contentLbl.numberOfLines = 0;
        [self.contentView addSubview:self.contentLbl];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.avatarIV.frame = CGRectMake(10, 10, 30, 30);
    self.avatarIV.cornerRadius = self.avatarIV.width/2;
    self.titleLbl.frame = CGRectMake(self.avatarIV.right + 10, self.avatarIV.y, self.width - self.avatarIV.right - 20, self.avatarIV.height);
    self.dateLbl.frame = CGRectMake(self.width - 95, self.avatarIV.y-5, 90, self.titleLbl.height);
    CGFloat height = [self.contentLbl.text heightForConstraintSize:CGSizeMake(mScreenWidth - 20, 9999) font:kN_MiddleFont];
    self.contentLbl.frame = CGRectMake(10, self.avatarIV.bottom + 10, self.width - 20, height);
}

+ (CGFloat)cellHeightForCellData:(XMComment *)comment
{
    return [comment.comment_content heightForConstraintSize:CGSizeMake(mScreenWidth - 20, 9999) font:kN_MiddleFont] + 60;
}

- (void)configureCellWithCellData:(XMComment *)comment
{
    NSDate *commentTime  = [NSDate dateWithTimeIntervalSince1970:comment.comment_time];
    self.dateLbl.text = [[[NVDate alloc] initUsingDate:commentTime] stringValueWithFormat:@"MM月dd日 HH:mm"];
    
    self.contentLbl.text = comment.comment_content;
    self.titleLbl.text = comment.user_id;
    NSURL *url = [NSURL URLWithString:comment.head_image];
    [self.avatarIV setImageWithURL:url placeholderImage:[UIImage imageNamed:@"user_avatar_placeholder"]];
}



@end
