//
//  XMSearchStoryView.m
//  XMThinMe
//
//  Created by 何振东 on 14/12/2.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMSearchStoryView.h"

@interface XMSearchStoryView () <UITableViewDelegate, UITableViewDataSource>


@end

@implementation XMSearchStoryView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kClearColor;
        
        UIToolbar *tb = [[UIToolbar alloc] initWithFrame:self.bounds];
        [self addSubview:tb];
        
        self.tableView = [[UITableView alloc] initWithFrame:self.bounds];
        self.tableView.delegate = self;
        self.tableView.backgroundColor = kClearColor;
        self.tableView.dataSource = self;
        self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 290, 0);
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self addSubview:self.tableView];
    }
    return self;
}

- (void)setHidden:(BOOL)hidden
{
    [super setHidden:hidden];
    
    [self.tableView reloadData];
}


#pragma mark - tableView delegate && datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [mUserDefaults stringArrayForKey:searchStoryKey].count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"搜索历史";
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (mIsiP4) {
        return 40;
    }
    return 44;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OCell *cell = [tableView dequeueReusableCellWithIdentifier:@"searchStoryCell"];
    if (!cell) {
        cell = [[OCell alloc] initWithStyle:0 reuseIdentifier:@"searchStoryCell"];
        cell.textLabel.backgroundColor = kClearColor;
        cell.backgroundColor = kClearColor;
        cell.backgroundView.backgroundColor = kClearColor;
    }
    NSArray *searchStoryList = [mUserDefaults stringArrayForKey:searchStoryKey];
    cell.textLabel.text = searchStoryList[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (self.selectCellBlock) {
        self.selectCellBlock(indexPath, [mUserDefaults stringArrayForKey:searchStoryKey][indexPath.row]);
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
//    [mKeyWindow endEditing:YES];
}



@end
