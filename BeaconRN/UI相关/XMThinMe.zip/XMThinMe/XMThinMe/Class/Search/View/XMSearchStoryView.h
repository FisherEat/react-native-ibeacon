//
//  XMSearchStoryView.h
//  XMThinMe
//
//  Created by 何振东 on 14/12/2.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OView.h"

static NSString *const searchStoryKey = @"searchStoryKey";

@interface XMSearchStoryView : OView
@property (strong, nonatomic) UITableView *tableView;

@property (copy, nonatomic) SelectCellBlock selectCellBlock;

@end
