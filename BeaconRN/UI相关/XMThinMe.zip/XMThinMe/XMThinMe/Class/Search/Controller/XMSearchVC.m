//
//  XMSearchVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/20.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMSearchVC.h"
#import "XMHomeExhibitionCell.h"
#import "XMExhibitionShopCell.h"
#import "XMTripLayout.h"
#import "XMTripVC.h"
#import "XMExhibitionVC.h"
#import "XMTripSpotDetailVC.h"
#import "XMExhibitionShopVC.h"
#import "XMSearchStoryView.h"

static NSString *const businessCell = @"businessCell";
static NSString *const shopCell = @"shopCell";

@interface XMSearchVC () <UISearchBarDelegate>
@property (strong, nonatomic) UISearchBar    *searchBar;
@property (assign, nonatomic) NSInteger      pageIndex;
@property (strong, nonatomic) NSMutableArray *businessArray;
@property (strong, nonatomic) NSMutableArray *shopArray;
@property (strong, nonatomic) NSString       *keyword;

/// 判断是否显示搜索历史
@property (strong, nonatomic) XMSearchStoryView *searchStoryView;;

@end

@implementation XMSearchVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.title = @"搜索";
        
        self.pageIndex = 0;
        self.businessArray = @[].mutableCopy;
        self.shopArray = @[].mutableCopy;
        
        self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 120, 44)];
        self.searchBar.placeholder = @"搜索";
        self.searchBar.showsCancelButton = YES;
        self.searchBar.delegate = self;
        self.searchBar.textField.backgroundColor = mRGB(235, 235, 235);
        self.searchBar.searchFieldBackgroundPositionAdjustment = UIOffsetMake(5, 0);
        self.searchBar.textField.autocapitalizationType = NO;
        self.navigationItem.titleView = self.searchBar;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /// 给搜索栏添加Blur背景
    self.tableView.backgroundView = [mKeyWindow snapshotViewAfterScreenUpdates:YES];
    UIToolbar *tb = [[UIToolbar alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.tableView.backgroundView addSubview:tb];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[XMHomeExhibitionCell class] forCellReuseIdentifier:businessCell];
    [self.tableView registerClass:[XMExhibitionShopCell class] forCellReuseIdentifier:shopCell];
    
    mWeakSelf;
    self.searchStoryView = [[XMSearchStoryView alloc] initWithFrame:CGRectMake(0, mNavHeight, self.view.width, self.view.height)];
    self.searchStoryView.hidden = YES;
    self.searchStoryView.selectCellBlock = ^(NSIndexPath *indexPath, NSString *keyword){
        weakSelf.searchStoryView.hidden = YES;
        weakSelf.keyword = [mUserDefaults stringArrayForKey:searchStoryKey][indexPath.row];
        weakSelf.searchBar.text = keyword;
        weakSelf.pageIndex = 0;
        [weakSelf.shopArray removeAllObjects];
        [weakSelf.businessArray removeAllObjects];
        [weakSelf.tableView reloadData];
        
        [[XMProgressHUD sharedInstance] showProgressAtView:weakSelf.view];
        [weakSelf searchEntityList];
    };
    [mKeyWindow addSubview:self.searchStoryView];
    
    [self.tableView addFooterWithCallback:^{
        [weakSelf searchEntityList];
    }];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (self.searchBar.text.length == 0) {
        [self.searchBar becomeFirstResponder];
    }
}


#pragma mark - tableView delegate && datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return self.businessArray.count;
    }
    
    return self.shopArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section) {
        return [XMHomeExhibitionCell cellHeightForCellData:nil];
    }
    
    return [XMExhibitionShopCell cellHeightForCellData:nil];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        XMHomeExhibitionCell *cell = [tableView dequeueReusableCellWithIdentifier:businessCell];
        cell.backgroundColor = kClearColor;
        cell.backgroundView.backgroundColor = kClearColor;
        [cell configureCellWithCellData:self.businessArray[indexPath.row]];
        return cell;
    }
    
    XMExhibitionShopCell *cell = [tableView dequeueReusableCellWithIdentifier:shopCell];
    cell.backgroundColor = kClearColor;
    cell.backgroundView.backgroundColor = kClearColor;
    [cell configureCellWithCellData:self.shopArray[indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
//        XMBusiness *business = self.businessArray[indexPath.row];
//        if (business.type == XMBeaconTypeTrip) {
//            XMTripLayout *tripLayout = [[XMTripLayout alloc] init];
//            XMTripVC *tripVC = [[XMTripVC alloc] initWithCollectionViewLayout:tripLayout];
//            tripVC.business = business;
//            [self.navigationController pushViewController:tripVC animated:YES];
//        } else if (business.type == XMBeaconTypeExhibition)
//        {
//            XMExhibitionVC *exhibitionVC = [[XMExhibitionVC alloc] init];
//            exhibitionVC.business = business;
//            [self.navigationController pushViewController:exhibitionVC animated:YES];
//        }
    } else {
        XMShop *shop = self.shopArray[indexPath.row];
        if (shop.type == XMBeaconTypeTrip) {
            XMTripVC *tripVC = [[XMTripVC alloc] initWithCollectionViewLayout:[[XMTripLayout alloc] init]];
            tripVC.shop = shop;
            tripVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:tripVC animated:YES];
        } else {
            XMExhibitionShopVC *exhibitionShopVC = [[XMExhibitionShopVC alloc] init];
            exhibitionShopVC.shop = shop;
            [self.navigationController pushViewController:exhibitionShopVC animated:YES];
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self.searchBar resignFirstResponder];
}


#pragma searchBar delegate

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    self.keyword = searchBar.text;
    self.pageIndex = 0;
    [self.shopArray removeAllObjects];
    [self.businessArray removeAllObjects];
    [self.tableView reloadData];
    
    // 添加搜索历史
    NSMutableArray *storyList = [NSMutableArray arrayWithArray:[mUserDefaults stringArrayForKey:searchStoryKey]];
    if (![storyList containsObject:searchBar.text]) {
        [storyList insertObject:searchBar.text atIndex:0];
        
        if (storyList.count > 10) {
            [storyList removeLastObject];
        }
        
        [mUserDefaults setObject:storyList forKey:searchStoryKey];
        [mUserDefaults synchronize];
    }
    
    [self searchEntityList];
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.tableView.scrollEnabled = NO;
    self.searchStoryView.hidden = NO;
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.tableView.scrollEnabled = YES;
    self.searchStoryView.hidden = YES;
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - network request

- (void)searchEntityList
{
    [self.searchBar resignFirstResponder];
    
    mWeakSelf;
    NSDictionary *params = @{@"type": @"1",
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId,
                             @"page_index":@(self.pageIndex),
                             @"page_size":@(10),
                             @"conditions": self.keyword};
    [[OURLRequest sharedInstance] postForPath:N_Entity_GetEntityList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         [weakSelf.tableView footerEndRefreshing];
         
         if (!error) {
             weakSelf.pageIndex++;
             
             /// 搜索后，则隐藏搜索历史
             weakSelf.searchStoryView.hidden = YES;

//             for (NSDictionary *dict in data[@"Business"]) {
//                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
//                 XMBusiness *business = [[XMBusiness alloc] initWithJSONData:objectData];
//                 [weakSelf.businessArray addObject:business];
//             }
             
             for (NSDictionary *dict in data[@"Shop"]) {
                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                 XMShop *shop = [[XMShop alloc] initWithJSONData:objectData];
                 [weakSelf.shopArray addObject:shop];
             }
             [weakSelf.tableView reloadData];
         }
     }];
}

@end
