//
//  XMGuideVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/4.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMGuideVC.h"

@interface XMGuideVC () <UIScrollViewDelegate>
@property (strong, nonatomic) UIScrollView  *scrollView;
@property (strong, nonatomic) UIPageControl *pageControl;

@end

@implementation XMGuideVC

- (void)viewDidLoad {
    [super viewDidLoad];

    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.width * 3, self.scrollView.height);
    self.scrollView.pagingEnabled = YES;
    self.scrollView.bounces = NO;
    self.scrollView.delegate = self;
    self.scrollView.cornerRadius = 1;
    [self.view addSubview:self.scrollView];
    
    self.pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake((self.view.width - 80)/2, self.view.height - 35, 80, 20)];
    self.pageControl.numberOfPages = 3;
    self.pageControl.currentPageIndicatorTintColor = kBlackColor;
    self.pageControl.pageIndicatorTintColor = kWhiteColor;
    [self.view addSubview:self.pageControl];
    
    for (int i = 0; i < 3; i++) {
        CGRect rect = CGRectMake(self.scrollView.width * i, mIsiP5 ? 0: -20, self.scrollView.width, 568);
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:rect];
        NSString *imgName = [NSString stringWithFormat:@"guide%zd", i];
        imgView.image = [UIImage imageNamed:imgName];
        [self.scrollView addSubview:imgView];
        
        if (i == 2) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:@"立即体验" forState:UIControlStateNormal];
            btn.frame = CGRectMake((self.view.width - 150)/2, self.view.height - (mIsiP4 ? 80: 140), 150, 50);
            btn.backgroundColor = mRGB(240, 240, 240);
            btn.cornerRadius = 6;
            btn.layer.borderColor = mRGB(75, 75, 75).CGColor;
            [btn setTitleColor:mRGB(132, 132, 132) forState:UIControlStateNormal];
            [btn setTitleColor:mRGB(0, 0, 0) forState:UIControlStateHighlighted];
            btn.layer.borderWidth = 1;
            [imgView addSubview:btn];
            mWeakSelf;
            [btn bk_addEventHandler:^(id sender) {
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            } forControlEvents:UIControlEventTouchUpInside];
            imgView.userInteractionEnabled = YES;
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat   pageWidth   = scrollView.frame.size.width;
    NSInteger currentPage = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.pageControl.currentPage = currentPage;
}




@end
