//
//  XMGuideVC.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/4.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGuideVC : UIViewController

@end
