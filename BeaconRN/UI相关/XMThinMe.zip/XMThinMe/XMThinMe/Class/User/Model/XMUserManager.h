//
//  XMUserManager.h
//  XMMuseum
//
//  Created by 何振东 on 14-7-2.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMUser.h"

/** UserManager 用户管理模块，处理用户的相关数据。
 本接口包含Login、Register、UserInfo等相关类的接口及处据处理。
 */
@interface XMUserManager : NSObject
/// 用户个人信息对象
@property (strong, nonatomic, readonly) XMUser *user;

+ (instancetype)sharedInstance;

/**
 *  保存用户信息
 *
 *  @param info 用户信息数据对象
 */
- (void)saveUserInfo:(XMUser *)user;

/**
 *  清除用户信息
 */
- (void)cleanUserInfo;

/**
 *  登出接口
 */
- (void)logout:(void (^) (void))success;

/**
 *  获取用户id号
 *
 *  @return 返回用户id号
 */
- (NSString *)userId;

/**
 *  创建会员终身号
 *  创建终身号以同步方式请求
 */
- (BOOL)createLifeNumber;


@end
