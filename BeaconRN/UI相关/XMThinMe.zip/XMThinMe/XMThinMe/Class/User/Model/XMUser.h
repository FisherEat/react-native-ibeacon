//
//  XMUserModel.h
//  XMMuseum
//
//  Created by 何振东 on 14-6-16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMUser : NSObject
@property (copy, nonatomic) NSString *user_id;
@property (copy, nonatomic) NSString *address;
@property (copy, nonatomic) NSString *city;
@property (copy, nonatomic) NSString *email;
@property (copy, nonatomic) NSString *mobilephone;
@property (copy, nonatomic) NSString *qq;
@property (copy, nonatomic) NSString *renren;
@property (copy, nonatomic) NSString *state;
@property (copy, nonatomic) NSString *telephone;
@property (copy, nonatomic) NSString *true_name;
@property (copy, nonatomic) NSString *web_name;
@property (copy, nonatomic) NSString *weibo;
@property (copy, nonatomic) NSString *weixin;
@property (copy, nonatomic) NSString *userDetailInfoModel;
@property (copy, nonatomic) NSString *userLoginLogModel;

@end
