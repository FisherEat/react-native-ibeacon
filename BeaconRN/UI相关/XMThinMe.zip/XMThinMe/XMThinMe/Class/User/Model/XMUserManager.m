//
//  XMUserManager.m
//  XMMuseum
//
//  Created by 何振东 on 14-7-2.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMUserManager.h"

@interface XMUserManager ()
@property (strong, nonatomic) XMUser *user;

@end

@implementation XMUserManager

+ (instancetype)sharedInstance
{
    static XMUserManager *userManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        userManager = [[XMUserManager alloc] init];
    });
    return userManager;
}

- (instancetype)init
{
    if (self = [super init]) {
    }
    return self;
}


- (void)saveUserInfo:(XMUser *)user
{
    self.user = user;
    
    [mUserDefaults setObject:user.user_id forKey:kUser_UIDKey];
    [mUserDefaults synchronize];
}

- (void)cleanUserInfo
{
    [mUserDefaults setObject:nil forKey:kUser_PasswordKey];
    [mUserDefaults setObject:nil forKey:kUser_UIDKey];
    [mUserDefaults setObject:nil forKey:kUser_NameKey];
    [mUserDefaults synchronize];
}

- (void)logout:(void (^) (void))success
{
    [mUserDefaults setBool:NO forKey:kUser_HadLoginKey];
    [mUserDefaults synchronize];
    
    [mNotificationCenter postNotificationName:kReLoginNotification object:nil userInfo:nil];
    
    if (success) {
        success();
    }

//    NSDictionary *params = @{@"authInfo": [XMAuthInfo sharedInstance].authInfo};
//    [[OURLRequest sharedInstance] postForPath:kLogout withParams:params success:^(NSDictionary *data) {
//    }];
}

- (BOOL)createLifeNumber
{
    NSString *bodyStr = [NSString stringWithFormat:@"device_type=%zd", [XMAppManager platform]];
    NSData *body = [bodyStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *bodyLength = [NSString stringWithFormat:@"%zd", body.length];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/%@", N_HostSite, N_User_CreateLifeNumber]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:bodyLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:body];
    NSError *error = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    if (dict) {
        if ([dict[@"status"] intValue] == ORequestStatusSuccess) {
            [mUserDefaults setObject:dict[@"data"] forKey:kUser_UIDKey];
            [mUserDefaults synchronize];
            return YES;
        }
        return NO;
    }

    return NO;
}

- (NSString *)userId
{
    __block NSString *uid = [mUserDefaults stringForKey:kUser_UIDKey];
    while (!uid) {
        if ([self createLifeNumber]) {
            uid = [mUserDefaults stringForKey:kUser_UIDKey];
            break;
        }
    }
    
    return uid;
}


@end
