//
//  XMLaunchingVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMLaunchingVC.h"
#import "XMLoginVC.h"
#import "XMRegisterVC.h"

@interface XMLaunchingVC ()
@property (strong, nonatomic) OButton *registerBtn;
@property (strong, nonatomic) OButton *loginBtn;

@end

@implementation XMLaunchingVC


- (instancetype)init
{
    self = [super init];
    if (self) {
        self.title = @"寻觅生活";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.registerBtn = [OButton buttonWithType:UIButtonTypeCustom];
    self.registerBtn.frame = CGRectMake(25, self.view.height - 45 - 30, 125, 45);
    [self.registerBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
    [self.registerBtn setTitle:@"注册" forState:UIControlStateNormal];
    self.registerBtn.titleLabel.font = kB_Font(19);
    self.registerBtn.cornerRadius = 6;
    self.registerBtn.backgroundColor = mRGB(75, 75, 75);
    [self.view addSubview:self.registerBtn];
    
    mWeakSelf;
    [self.registerBtn bk_addEventHandler:^(id sender) {
        XMRegisterVC *registerVC = [[XMRegisterVC alloc] init];
        [weakSelf.navigationController pushViewController:registerVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    self.loginBtn = [OButton buttonWithType:UIButtonTypeCustom];
    self.loginBtn.frame = CGRectMake(self.view.width - 125 - 25, self.registerBtn.y, self.registerBtn.width, self.registerBtn.height);
    [self.loginBtn setTitleColor:kBlackColor forState:UIControlStateNormal];
    [self.loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    self.loginBtn.titleLabel.font = kB_Font(19);
    self.loginBtn.cornerRadius = 6;
    self.loginBtn.backgroundColor = mRGB(232, 232, 232);
    self.loginBtn.layer.borderColor = mRGB(75, 75, 75).CGColor;
    self.loginBtn.layer.borderWidth = 1;
    [self.view addSubview:self.loginBtn];
    
    [self.loginBtn bk_addEventHandler:^(id sender) {
        XMLoginVC *loginVC = [[XMLoginVC alloc] init];
        [weakSelf.navigationController pushViewController:loginVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView *sloganIV = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.width - 253)/2, 200, 253, 78)];
    sloganIV.image = [UIImage imageNamed:@"slogan"];
    [self.view addSubview:sloganIV];

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
//    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
//    self.navigationController.navigationBarHidden = NO;
}


@end
