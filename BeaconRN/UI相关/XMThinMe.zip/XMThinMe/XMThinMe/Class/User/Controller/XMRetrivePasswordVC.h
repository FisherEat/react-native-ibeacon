//
//  XMRetrivePasswordVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"

@interface XMRetrivePasswordVC : OViewController

@end
