//
//  XMRetrivePasswordVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMRetrivePasswordVC.h"
#import "XMRetrivePasswordView.h"

@interface XMRetrivePasswordVC ()
@property (strong, nonatomic) XMRetrivePasswordView *retrivePasswordView;
@property (assign, nonatomic) NSInteger countdown;

@end

@implementation XMRetrivePasswordVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.title = @"忘记密码";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.retrivePasswordView = [[XMRetrivePasswordView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.retrivePasswordView];
    
    mWeakSelf;
    [self.retrivePasswordView.verifyCodeBtn bk_addEventHandler:^(id sender) {
        [SMS_SDK getVerifyCodeByPhoneNumber:weakSelf.retrivePasswordView.usernameTF.text AndZone:@"86" result:^(enum SMS_GetVerifyCodeResponseState state)
         {
             if (state == SMS_ResponseStateGetVerifyCodeSuccess) {
                 weakSelf.countdown = 60;
                 NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(countdownTimer:) userInfo:nil repeats:YES];
                 [timer fire];
             }
             else {
                 [XMProgressHUD showTips:@"发送验证码失败" atView:weakSelf.view];
             }
         }];
    } forControlEvents:UIControlEventTouchUpInside];

    [self.retrivePasswordView.submitBtn bk_addEventHandler:^(id sender) {
        [[XMProgressHUD sharedInstance] showProgress];
        [SMS_SDK commitVerifyCode:self.retrivePasswordView.verifyCodeTF.text result:^(enum SMS_ResponseState state)
         {
             [[XMProgressHUD sharedInstance] hideProgress];
             if (state == SMS_ResponseStateSuccess) {
                 [weakSelf requestRetrivePassword];
             } else {
                 [XMProgressHUD showTips:@"短信验证失败" atView:self.view];
             }
         }];
    } forControlEvents:UIControlEventTouchUpInside];
}

- (void)countdownTimer:(NSTimer *)timer
{
    self.countdown--;
    if (self.countdown <= 0) {
        self.retrivePasswordView.verifyCodeBtn.userInteractionEnabled = YES;
        [self.retrivePasswordView.verifyCodeBtn setTitle:@"重新获取" forState:UIControlStateNormal];
        self.retrivePasswordView.verifyCodeBtn.backgroundColor = [kGreenColor colorWithAlphaComponent:1.0];
        
        [timer invalidate];
        timer = nil;
    } else {
        NSString *title = [NSString stringWithFormat:@"%zds重新发送", self.countdown];
        [self.retrivePasswordView.verifyCodeBtn setTitle:title forState:UIControlStateNormal];
        self.retrivePasswordView.verifyCodeBtn.userInteractionEnabled = NO;
        self.retrivePasswordView.verifyCodeBtn.backgroundColor = [kGreenColor colorWithAlphaComponent:0.5];
    }
}

#pragma mark - http request

- (void)requestRetrivePassword
{
    [self.view endEditing:YES];
    
    mWeakSelf;
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    NSDictionary *params = @{@"user_name": self.retrivePasswordView.usernameTF.text,
                             @"new_password": [self.retrivePasswordView.usernameTF.text.md5 uppercaseString],
                             @"user_id": [XMUserManager sharedInstance].userId,
                             @"device_type": @([XMAppManager platform])};
    [[OURLRequest sharedInstance] postForPath:N_User_RetrievePassword withParams:params completionHandler:^(id data, NSError *error)
     {
         if (!error) {
             [mUserDefaults setBool:YES forKey:kUser_HadLoginKey];
             [mUserDefaults setObject:self.retrivePasswordView.usernameTF.text forKey:kUser_NameKey];
             [mUserDefaults setObject:self.retrivePasswordView.usernameTF.text forKey:kUser_PasswordKey];
             [mUserDefaults synchronize];
             
             [self.navigationController popToRootViewControllerAnimated:YES];
         } else {
             [[XMProgressHUD sharedInstance] hideProgress];
             [XMProgressHUD showTips:error.localizedDescription atView:weakSelf.view];
         }
     }];
}




@end
