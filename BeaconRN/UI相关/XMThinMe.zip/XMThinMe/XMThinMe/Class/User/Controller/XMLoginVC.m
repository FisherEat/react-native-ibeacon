//
//  XMLoginVC.m
//  XMMuseum
//
//  Created by 何振东 on 14-6-16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMLoginVC.h"
#import "XMLoginView.h"
#import "XMRetrivePasswordVC.h"
#import "XMRegisterVC.h"

@interface XMLoginVC ()
@property (strong, nonatomic) XMLoginView *loginView;


@end

@implementation XMLoginVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"进入寻觅";
        mWeakSelf;
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] bk_initWithTitle:@"注册" style:0 handler:^(id sender) {
            XMRegisterVC *registerVC = [[XMRegisterVC alloc] init];
            [weakSelf.navigationController pushViewController:registerVC animated:YES];
        }];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
        
    self.loginView = [[XMLoginView alloc] initWithFrame:self.view.bounds];
    [self.loginView.submitBtn addTarget:self action:@selector(loginButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.loginView];
    
    mWeakSelf;
    [self.loginView.retrivePasswordBtn bk_addEventHandler:^(id sender) {
        XMRetrivePasswordVC *retrivePasswordVC = [[XMRetrivePasswordVC alloc] init];
        [weakSelf.navigationController pushViewController:retrivePasswordVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.loginView.usernameTF.text = [mUserDefaults objectForKey:kUser_NameKey];
    self.loginView.passwordTF.text = [mUserDefaults objectForKey:kUser_PasswordKey];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (self.loginView.usernameTF.text.length == 0) {
        [self.loginView.usernameTF becomeFirstResponder];
    }
}


#pragma mark - button click event

- (void)loginButtonClicked:(UIButton *)sender
{
    if (self.loginView.usernameTF.text.length == 0 || self.loginView.passwordTF.text.length == 0) {
        [XMProgressHUD showTips:@"用户名或密码不能为空"];
        return;
    }
    
    if (![self.loginView.passwordTF.text isValidatePassword]) {
        [self.loginView.passwordTF shakeHorizontally];
        [XMProgressHUD showTips:@"密码为6-16位的数字、字母和. @ -_！"];
        return;
    }
    
    [self requestLogin];
}


#pragma mark - data request

- (void)requestLogin
{
    [self.view endEditing:YES];
    mWeakSelf;
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    NSDictionary *params = @{@"user_name": self.loginView.usernameTF.text,
                             @"user_password": [self.loginView.passwordTF.text.md5 uppercaseString],
                             @"device_type": @([XMAppManager platform])};
    [[OURLRequest sharedInstance] postForPath:N_User_Login withParams:params completionHandler:^(id data, NSError *error) {
        [[XMProgressHUD sharedInstance] hideProgress];
        
        if (!error) {
            [weakSelf saveUserData:data];
        } else {
            [XMProgressHUD showTips:@"用户名或密码错误！"];
        }
    }];
}

- (void)saveUserData:(id)data
{
    [mUserDefaults setObject:self.loginView.usernameTF.text forKey:kUser_NameKey];
    [mUserDefaults setObject:self.loginView.passwordTF.text forKey:kUser_PasswordKey];
    [mUserDefaults setBool:YES forKey:kUser_HadLoginKey];
    [mUserDefaults setObject:data[@"user_id"] forKey:kUser_UIDKey];
    [mUserDefaults synchronize];
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:data options:NSJSONWritingPrettyPrinted error:nil];
    XMUser *user = [[XMUser alloc] initWithJSONData:jsonData];
    [[XMUserManager sharedInstance] saveUserInfo:user];
    
    [self.navigationController popToRootViewControllerAnimated:YES];
    
    if (self.loginSuccessBlock) {
        self.loginSuccessBlock();
    }
}



@end
