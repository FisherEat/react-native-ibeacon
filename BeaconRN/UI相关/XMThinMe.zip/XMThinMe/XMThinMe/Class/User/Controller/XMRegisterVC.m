//
//  XMRegisterVC.m
//  XMMuseum
//
//  Created by 何振东 on 14-6-16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMRegisterVC.h"
#import "XMRegisterView.h"
#import "XMAgreementVC.h"
#import "XMRegisterVerifyVC.h"


@interface XMRegisterVC ()
@property (strong, nonatomic) XMRegisterView *registerView;

@end

@implementation XMRegisterVC

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"加入寻觅";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = kWhiteColor;
    self.view.cornerRadius = 6;
    
    self.registerView = [[XMRegisterView alloc] initWithFrame:self.view.bounds];
    [self.registerView.submitBtn addTarget:self action:@selector(registerButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.registerView];
    
    mWeakSelf;
    [self.registerView.agreementBtn bk_addEventHandler:^(id sender) {
        XMAgreementVC *agreementVC = [[XMAgreementVC alloc] init];
        [weakSelf.navigationController pushViewController:agreementVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
}

- (void)registerButtonClicked:(UIButton *)sender
{
    if (self.registerView.usernameTF.text.length == 0 || self.registerView.passwordTF.text.length == 0) {
//        [self.registerView.contentView shakeHorizontally];
        [XMProgressHUD showTips:@"用户名和密码不能为空！"];
        return;
    }
    if (self.registerView.usernameTF.text.length < 10) {
        [self.registerView.usernameTF shakeHorizontally];
        [XMProgressHUD showTips:@"用户名为11位的手机号！"];
        return;
    }
    if (![self.registerView.passwordTF.text isValidatePassword]) {
        [self.registerView.passwordTF shakeHorizontally];
        [XMProgressHUD showTips:@"密码为6-16位的数字、字母和. @ -_！"];
        return;
    }
    
    XMRegisterVerifyVC *validateVC = [[XMRegisterVerifyVC alloc] init];
    validateVC.username = self.registerView.usernameTF.text;
    validateVC.zone = @"86";
    validateVC.password = self.registerView.passwordTF.text;
    [self.navigationController pushViewController:validateVC animated:YES];
}


@end
