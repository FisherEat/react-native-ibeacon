//
//  XMRegisterVC.h
//  XMMuseum
//
//  Created by 何振东 on 14-6-16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"

@interface XMRegisterVC : OViewController
/// 注册成功代理
@property (copy, nonatomic) void (^registerSuccessBlock) (void);

@end
