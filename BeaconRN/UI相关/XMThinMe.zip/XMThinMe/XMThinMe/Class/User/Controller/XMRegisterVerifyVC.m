//
//  XMRegisterValidateVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/6.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMRegisterVerifyVC.h"

@interface XMRegisterVerifyVC ()
@property (strong, nonatomic) OTextField *verifyCodeTF;
@property (strong, nonatomic) OButton *resendBtn;
@property (strong, nonatomic) OButton *submitBtn;
@property (assign, nonatomic) NSInteger countdown;

@end

@implementation XMRegisterVerifyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"填写验证码";
    self.countdown = 60;
    
    mWeakSelf;
    
    self.verifyCodeTF = [[OTextField alloc] initWithFrame:CGRectMake(15, 69, 160, 50)];
    self.verifyCodeTF.placeholder = @"请输入收到的验证码";
    self.verifyCodeTF.keyboardType = UIKeyboardTypeAlphabet;
    self.verifyCodeTF.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.verifyCodeTF];

    self.resendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.resendBtn.frame = CGRectMake(self.verifyCodeTF.right + 10, self.verifyCodeTF.y + 10, self.view.width - self.verifyCodeTF.right - 10- 15, 30);
    [self.resendBtn setTitle:@"60s重新发送" forState:UIControlStateNormal];
    [self.resendBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
    self.resendBtn.backgroundColor = [kGreenColor colorWithAlphaComponent:0.5];
    self.resendBtn.userInteractionEnabled = NO;
    self.resendBtn.titleLabel.font = kFont(15);
    self.resendBtn.cornerRadius = 4;
    [self.resendBtn addTarget:self action:@selector(sendVerifyCode:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.resendBtn];
    
    UIView *seprator = [[UIView alloc] initWithFrame:CGRectMake(self.verifyCodeTF.x, self.verifyCodeTF.bottom, self.view.width - self.verifyCodeTF.x * 2, 0.6)];
    seprator.backgroundColor = mRGB(191, 191, 191);
    [self.view addSubview:seprator];
    
    self.submitBtn = [OButton buttonWithType:UIButtonTypeCustom];
    self.submitBtn.frame = CGRectMake(self.verifyCodeTF.x, seprator.bottom + 25, seprator.width, 50);
    [self.submitBtn setTitle:@"提交" forState:UIControlStateNormal];
    self.submitBtn.titleLabel.font = kB_MiddleFont;
    self.submitBtn.backgroundColor = mRGB(160, 160, 160);
    [self.submitBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
    self.submitBtn.cornerRadius = 4;
    [self.submitBtn bk_addEventHandler:^(id sender) {
        [[XMProgressHUD sharedInstance] showProgress];
        [SMS_SDK commitVerifyCode:weakSelf.verifyCodeTF.text result:^(enum SMS_ResponseState state)
        {
            [[XMProgressHUD sharedInstance] hideProgress];
            if (state == SMS_ResponseStateSuccess) {
                [weakSelf requestRegister];
            } else {
                [XMProgressHUD showTips:@"短信验证失败" atView:self.view];
            }
        }];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.submitBtn];
    
    [self sendVerifyCode:self.resendBtn];
}

- (void)sendVerifyCode:(UIButton *)sender
{
    mWeakSelf;
    [SMS_SDK getVerifyCodeByPhoneNumber:self.username AndZone:self.zone result:^(enum SMS_GetVerifyCodeResponseState state)
     {
         if (state == SMS_ResponseStateGetVerifyCodeSuccess) {
             weakSelf.countdown = 60;
             NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(countdownTimer:) userInfo:nil repeats:YES];
             [timer fire];
         }
         else {
             [XMProgressHUD showTips:@"发送验证码失败" atView:weakSelf.view];
         }
     }];
}

- (void)countdownTimer:(NSTimer *)timer
{
    self.countdown--;
    if (self.countdown <= 0) {
        self.resendBtn.userInteractionEnabled = YES;
        [self.resendBtn setTitle:@"重新获取验证码" forState:UIControlStateNormal];
        self.resendBtn.backgroundColor = [kGreenColor colorWithAlphaComponent:1.0];

        [timer invalidate];
        timer = nil;
    } else {
        NSString *title = [NSString stringWithFormat:@"%zds重新发送", self.countdown];
        [self.resendBtn setTitle:title forState:UIControlStateNormal];
        self.resendBtn.userInteractionEnabled = NO;
        self.resendBtn.backgroundColor = [kGreenColor colorWithAlphaComponent:0.5];
    }
}


#pragma mark - http request

- (void)requestRegister
{
    [self.view endEditing:YES];
    
    mWeakSelf;
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    NSDictionary *params = @{@"user_name": self.username,
                             @"user_password": [self.password.md5 uppercaseString],
                             @"user_id": [XMUserManager sharedInstance].userId,
                             @"device_type": @([XMAppManager platform])};
    [[OURLRequest sharedInstance] postForPath:N_User_Register withParams:params completionHandler:^(id data, NSError *error)
    {
        if (!error) {
            [mUserDefaults setObject:self.username forKey:kUser_NameKey];
            [mUserDefaults setObject:self.password forKey:kUser_PasswordKey];
            [mUserDefaults setBool:YES forKey:kUser_HadLoginKey];
            [mUserDefaults synchronize];

            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        [[XMProgressHUD sharedInstance] hideProgress];
        [XMProgressHUD showTips:error.localizedDescription atView:weakSelf.view];
    }];
}




@end
