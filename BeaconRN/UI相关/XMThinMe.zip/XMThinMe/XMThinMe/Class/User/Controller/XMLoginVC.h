//
//  XMLoginVC.h
//  XMMuseum
//
//  Created by 何振东 on 14-6-16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"
#import "XMUserManager.h"

@interface XMLoginVC : OViewController
@property (copy, nonatomic) void (^loginSuccessBlock) (void);
@property (copy, nonatomic) void (^loginCanceledBlock) (void);



@end
