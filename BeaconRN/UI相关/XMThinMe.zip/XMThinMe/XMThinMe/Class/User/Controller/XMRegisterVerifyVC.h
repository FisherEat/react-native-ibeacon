//
//  XMRegisterValidateVC.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/6.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OViewController.h"
#import <SMS_SDK/SMS_SDK.h>

@interface XMRegisterVerifyVC : OViewController
@property (copy, nonatomic) NSString *zone;
@property (copy, nonatomic) NSString *username;
@property (copy, nonatomic) NSString *password;

@end
