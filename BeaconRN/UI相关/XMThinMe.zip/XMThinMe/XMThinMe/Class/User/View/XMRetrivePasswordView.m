//
//  XMRetrivePasswordView.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMRetrivePasswordView.h"

/// 文本框的Tag基值
static NSInteger kBaseTagTF = 10;

@interface XMRetrivePasswordView () <UITextFieldDelegate>

@end

@implementation XMRetrivePasswordView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.countryBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.countryBtn.frame = CGRectMake(20, mNavHeight+5, 30, 50);
        [self.countryBtn setTitle:@"+86" forState:UIControlStateNormal];
        self.countryBtn.titleLabel.font = kFont(15);
        [self addSubview:self.countryBtn];
        
        self.usernameTF = [[OTextField alloc] initWithFrame:CGRectMake(self.countryBtn.right, self.countryBtn.y, 160, self.countryBtn.height)];
        self.usernameTF.placeholder = @"手机号";
        self.usernameTF.keyboardType = UIKeyboardTypePhonePad;
        self.usernameTF.delegate = self;
        self.usernameTF.tag = 1 + kBaseTagTF;
        self.usernameTF.textAlignment = NSTextAlignmentCenter;
        [self.usernameTF becomeFirstResponder];
        [self addSubview:self.usernameTF];
        
        self.verifyCodeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.verifyCodeBtn.frame = CGRectMake(self.usernameTF.right, self.countryBtn.y + 10, self.width - self.usernameTF.right - self.countryBtn.x, 30);
        [self.verifyCodeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.verifyCodeBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        self.verifyCodeBtn.backgroundColor = kGreenColor;
        self.verifyCodeBtn.titleLabel.font = kFont(15);
        self.verifyCodeBtn.cornerRadius = 4;
        [self addSubview:self.verifyCodeBtn];
        
        UIView *seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.x, self.countryBtn.bottom, self.width - self.countryBtn.x * 2, 0.6)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.verifyCodeTF = [[OTextField alloc] initWithFrame:CGRectMake(self.countryBtn.x, seprator.bottom, seprator.width, self.countryBtn.height)];
        self.verifyCodeTF.placeholder = @"请输入收到的验证码";
        self.verifyCodeTF.keyboardType = UIKeyboardTypeAlphabet;
        self.verifyCodeTF.delegate = self;
        self.verifyCodeTF.tag = 2 + kBaseTagTF;
        self.verifyCodeTF.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.verifyCodeTF];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.x, self.verifyCodeTF.bottom, seprator.width, 0.6)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.passwordTF = [[OTextField alloc] initWithFrame:CGRectMake(self.countryBtn.x, seprator.bottom, seprator.width, self.countryBtn.height)];
        self.passwordTF.placeholder = @"新密码(6-16位)";
        self.passwordTF.keyboardType = UIKeyboardTypeAlphabet;
        self.passwordTF.delegate = self;
        self.passwordTF.tag = 2 + kBaseTagTF;
        self.passwordTF.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.passwordTF];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.x, self.passwordTF.bottom, seprator.width, 0.3)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.submitBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.submitBtn.frame = CGRectMake(self.countryBtn.x, seprator.bottom + 25, seprator.width, 50);
        [self.submitBtn setTitle:@"提交" forState:UIControlStateNormal];
        self.submitBtn.titleLabel.font = kB_MiddleFont;
        self.submitBtn.backgroundColor = mRGB(160, 160, 160);
        [self.submitBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        self.submitBtn.cornerRadius = 4;
        [self addSubview:self.submitBtn];

        [self addTarget:self action:@selector(dismissKeyboard:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)dismissKeyboard:(UIControl *)sender
{
    [self endEditing:YES];
    [UIView animateWithDuration:0.45 animations:^{
        
    }];
}


@end
