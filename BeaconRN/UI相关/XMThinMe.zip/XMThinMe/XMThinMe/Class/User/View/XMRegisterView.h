//
//  XMRegisterView.h
//  XMMuseum
//
//  Created by 何振东 on 14/7/17.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMRegisterView : UIControl
@property (strong, nonatomic) OButton     *countryBtn;
@property (strong, nonatomic) UITextField *usernameTF;
@property (strong, nonatomic) UITextField *passwordTF;
@property (strong, nonatomic) OButton     *submitBtn;
@property (strong, nonatomic) OButton     *agreementBtn;

@end
