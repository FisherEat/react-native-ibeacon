//
//  XMRetrivePasswordView.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMRetrivePasswordView : UIControl
@property (strong, nonatomic) OButton     *countryBtn;
@property (strong, nonatomic) UITextField *usernameTF;
@property (strong, nonatomic) UITextField *verifyCodeTF;
@property (strong, nonatomic) UITextField *passwordTF;
@property (strong, nonatomic) OButton     *verifyCodeBtn;
@property (strong, nonatomic) OButton     *submitBtn;

@end
