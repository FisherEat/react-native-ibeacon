//
//  XMRegisterView.m
//  XMMuseum
//
//  Created by 何振东 on 14/7/17.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMRegisterView.h"

/// 文本框的Tag基值
static NSInteger kBaseTagTF = 10;

@interface XMRegisterView () <UITextFieldDelegate>

@end

@implementation XMRegisterView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.countryBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.countryBtn.frame = CGRectMake(35, mNavHeight+5, 95, 50);
        [self.countryBtn setTitle:@"中国＋86" forState:UIControlStateNormal];
        self.countryBtn.titleLabel.font = kFont(15);
        [self addSubview:self.countryBtn];
        
        UIView *seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.right, self.countryBtn.y + 15, 0.6, self.countryBtn.height - 15 * 2)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.usernameTF = [[OTextField alloc] initWithFrame:CGRectMake(seprator.right, self.countryBtn.y, self.width - seprator.right - 35, self.countryBtn.height)];
        self.usernameTF.placeholder = @"手机号";
        self.usernameTF.keyboardType = UIKeyboardTypePhonePad;
        self.usernameTF.delegate = self;
        self.usernameTF.tag = 1 + kBaseTagTF;
        self.usernameTF.textAlignment = NSTextAlignmentCenter;
        [self.usernameTF becomeFirstResponder];
        [self addSubview:self.usernameTF];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.x, self.countryBtn.bottom, self.width - 70, 0.6)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.passwordTF = [[OTextField alloc] initWithFrame:CGRectMake(self.countryBtn.x, seprator.bottom, self.width-70, self.countryBtn.height)];
        self.passwordTF.placeholder = @"设置密码(6-16位)";
        self.passwordTF.keyboardType = UIKeyboardTypeAlphabet;
        self.passwordTF.delegate = self;
        self.passwordTF.tag = 2 + kBaseTagTF;
        self.passwordTF.layer.borderColor = kClearColor.CGColor;
        self.passwordTF.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.passwordTF];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.x, self.passwordTF.bottom, self.width - 70, 0.6)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.submitBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.submitBtn.frame = CGRectMake(self.countryBtn.x, seprator.bottom + 25, self.passwordTF.width, 50);
        [self.submitBtn setTitle:@"注册" forState:UIControlStateNormal];
        self.submitBtn.titleLabel.font = kB_MiddleFont;
        self.submitBtn.backgroundColor = mRGB(160, 160, 160);
        [self.submitBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        self.submitBtn.cornerRadius = 4;
        [self addSubview:self.submitBtn];
        
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(self.submitBtn.x, self.submitBtn.bottom + 20, 98, 30)];
        lbl.text = @"注册即表示同意";
        lbl.font = kFont(14);
        lbl.textColor = kGrayColor;
        [self addSubview:lbl];
        
        self.agreementBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.agreementBtn.frame = CGRectMake(lbl.right + 5, lbl.y, 84, 30);
        self.agreementBtn.titleLabel.font = kFont(14);
        [self.agreementBtn setTitle:@"寻觅使用协议" forState:UIControlStateNormal];
        self.agreementBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [self.agreementBtn setTitleColor:mRGB(165, 142, 98) forState:UIControlStateNormal];
        [self addSubview:self.agreementBtn];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.agreementBtn.x, self.agreementBtn.bottom-4, self.agreementBtn.width, 0.4)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        [self addTarget:self action:@selector(dismissKeyboard:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)dismissKeyboard:(UIControl *)sender
{
    [self endEditing:YES];
    [UIView animateWithDuration:0.45 animations:^{

    }];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
//    CGFloat top = 80 - 30 * (textField.tag - kBaseTagTF - 1);
    [UIView animateWithDuration:0.45 animations:^{

    }];
}


@end
