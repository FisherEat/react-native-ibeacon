//
//  XMLoginView.m
//  XMMuseum
//
//  Created by 何振东 on 14/7/16.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMLoginView.h"

/// 文本框的Tag基值
static NSInteger kBaseTagTF = 10;

@interface XMLoginView () <UITextFieldDelegate>

@end

@implementation XMLoginView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.countryBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.countryBtn.frame = CGRectMake(35, mNavHeight+5, 95, 50);
        [self.countryBtn setTitle:@"中国＋86" forState:UIControlStateNormal];
        self.countryBtn.titleLabel.font = kFont(15);
        [self addSubview:self.countryBtn];
        
        UIView *seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.right, self.countryBtn.y + 15, 0.6, self.countryBtn.height - 15 * 2)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.usernameTF = [[OTextField alloc] initWithFrame:CGRectMake(seprator.right, self.countryBtn.y, self.width - seprator.right - 35, self.countryBtn.height)];
        self.usernameTF.placeholder = @"手机号";
        self.usernameTF.keyboardType = UIKeyboardTypePhonePad;
        self.usernameTF.delegate = self;
        self.usernameTF.tag = 1 + kBaseTagTF;
        self.usernameTF.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.usernameTF];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.x, self.countryBtn.bottom, self.width - 70, 0.6)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];

        self.passwordTF = [[OTextField alloc] initWithFrame:CGRectMake(self.countryBtn.x, seprator.bottom, self.width-70, self.countryBtn.height)];
        self.passwordTF.placeholder = @"6-16位密码";
        self.passwordTF.keyboardType = UIKeyboardTypeAlphabet;
        self.passwordTF.secureTextEntry = YES;
        self.passwordTF.delegate = self;
        self.passwordTF.tag = 2 + kBaseTagTF;
        self.passwordTF.layer.borderColor = kClearColor.CGColor;
        self.passwordTF.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.passwordTF];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.countryBtn.x, self.passwordTF.bottom, self.width - 70, 0.6)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        self.submitBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.submitBtn.frame = CGRectMake(self.countryBtn.x, seprator.bottom + 25, self.passwordTF.width, 50);
        [self.submitBtn setTitle:@"登录" forState:UIControlStateNormal];
        self.submitBtn.titleLabel.font = kB_MiddleFont;
        self.submitBtn.backgroundColor = mRGB(160, 160, 160);
        [self.submitBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        self.submitBtn.cornerRadius = 4;
        [self addSubview:self.submitBtn];

        self.retrivePasswordBtn = [OButton buttonWithType:UIButtonTypeCustom];
        self.retrivePasswordBtn.frame = CGRectMake((self.width - 65)/2, self.submitBtn.bottom + 20, 65, 25);
        self.retrivePasswordBtn.titleLabel.font = kFont(14);
        [self.retrivePasswordBtn setTitle:@"忘记密码?" forState:UIControlStateNormal];
        [self.retrivePasswordBtn setTitleColor:mRGB(165, 142, 98) forState:UIControlStateNormal];
        [self addSubview:self.retrivePasswordBtn];
        
        seprator = [[UIView alloc] initWithFrame:CGRectMake(self.retrivePasswordBtn.x, self.retrivePasswordBtn.bottom-2, self.retrivePasswordBtn.width-1, 0.4)];
        seprator.backgroundColor = mRGB(191, 191, 191);
        [self addSubview:seprator];
        
        [self addTarget:self action:@selector(dismissKeyboard:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)dismissKeyboard:(UIControl *)sender
{
    [self endEditing:YES];
    [UIView animateWithDuration:0.45 animations:^{
    }];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
//    CGFloat top = 80 - 30 * (textField.tag - kBaseTagTF - 1);
    [UIView animateWithDuration:0.45 animations:^{

    }];
}


@end
