//
//  XMExhibitionFileView.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionFileView.h"

@interface XMExhibitionFileView ()

@end

@implementation XMExhibitionFileView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.files = @[].mutableCopy;
        
        self.talbeView = [[UITableView alloc] initWithFrame:self.bounds];
        self.talbeView.delegate = self;
        self.talbeView.dataSource = self;
        self.talbeView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self addSubview:self.talbeView];
    }
    return self;
}

#pragma mark - delegate && datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.files.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 85;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"exhibitionNewsCell";
    XMFileCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMFileCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    mWeakSelf;
    [cell.downloadBtn bk_addEventHandler:^(id sender) {
        XMFile *file = weakSelf.files[indexPath.row];
        NSString *suffix = [[file.attachment_url componentsSeparatedByString:@"."] lastObject];
        NSString *path = [NSString stringWithFormat:@"%@/%@.%@", kXM_Download_Dir, file.attachment_name, suffix];
        [OURLRequest downloadFile:file.attachment_url toPath:path completionHandler:^(id data, NSError *error) {
            file.local_Path = path;
            [[XMDBManager sharedInstance] updateFileInfo:file];
            [weakSelf.talbeView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }];
    } forControlEvents:UIControlEventTouchUpInside];

    [cell configureCellWithCellData:self.files[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (self.selectCellBlcok) {
        self.selectCellBlcok(indexPath, nil);
    }
}

@end
