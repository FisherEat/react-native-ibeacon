//
//  XMExhibitionFunctionCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionFunctionCell.h"

@implementation XMExhibitionFunctionCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];;
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.overviewBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.overviewBtn setImage:[UIImage imageNamed:@"exhibition_overview_normal"] forState:UIControlStateNormal];
        [self.overviewBtn setImage:[UIImage imageNamed:@"exhibition_overview_highlighted"] forState:UIControlStateHighlighted];
        [self.overviewBtn setTitle:@"概况" forState:UIControlStateNormal];
        self.overviewBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 13.5, 25, 0);
        self.overviewBtn.titleEdgeInsets = UIEdgeInsetsMake(60, -53, 0, 0);
        self.overviewBtn.titleLabel.font = kFont(14);
        self.overviewBtn.tag = ExhibitionFunctionButtonOverview;
        [self.contentView addSubview:self.overviewBtn];
        
        self.locationBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.locationBtn setImage:[UIImage imageNamed:@"exhibition_location_normal"] forState:UIControlStateNormal];
        [self.locationBtn setImage:[UIImage imageNamed:@"exhibition_location_highlighted"] forState:UIControlStateHighlighted];
        [self.locationBtn setTitle:@"位置" forState:UIControlStateNormal];
        self.locationBtn.imageEdgeInsets = self.overviewBtn.imageEdgeInsets;
        self.locationBtn.titleEdgeInsets = self.overviewBtn.titleEdgeInsets;
        self.locationBtn.titleLabel.font = self.overviewBtn.titleLabel.font;
        self.locationBtn.tag = ExhibitionFunctionButtonLocation;
        [self.contentView addSubview:self.locationBtn];

        self.indoorMapBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.indoorMapBtn setImage:[UIImage imageNamed:@"exhibition_map_normal"] forState:UIControlStateNormal];
        [self.indoorMapBtn setImage:[UIImage imageNamed:@"exhibition_map_highlighted"] forState:UIControlStateHighlighted];
        [self.indoorMapBtn setTitle:@"导航" forState:UIControlStateNormal];
        self.indoorMapBtn.imageEdgeInsets = self.overviewBtn.imageEdgeInsets;
        self.indoorMapBtn.titleEdgeInsets = self.overviewBtn.titleEdgeInsets;
        self.indoorMapBtn.titleLabel.font = self.overviewBtn.titleLabel.font;
        self.indoorMapBtn.tag = ExhibitionFunctionButtonIndoorMap;
        [self.contentView addSubview:self.indoorMapBtn];

        self.agendaBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.agendaBtn setImage:[UIImage imageNamed:@"exhibition_agenda_normal"] forState:UIControlStateNormal];
        [self.agendaBtn setImage:[UIImage imageNamed:@"exhibition_agenda_highlighted"] forState:UIControlStateHighlighted];
        [self.agendaBtn setTitle:@"日程" forState:UIControlStateNormal];
        self.agendaBtn.imageEdgeInsets = self.overviewBtn.imageEdgeInsets;
        self.agendaBtn.titleEdgeInsets = self.overviewBtn.titleEdgeInsets;
        self.agendaBtn.titleLabel.font = self.overviewBtn.titleLabel.font;
        self.agendaBtn.tag = ExhibitionFunctionButtonAgenda;
        [self.contentView addSubview:self.agendaBtn];

        [self.overviewBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.locationBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.indoorMapBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.agendaBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.overviewBtn.frame = CGRectMake(0, 0, self.width/4, self.height);
    self.locationBtn.frame = CGRectMake(self.overviewBtn.width, 0, self.width/4, self.height);
    self.indoorMapBtn.frame = CGRectMake(self.overviewBtn.width * 2, 0, self.width/4, self.height);
    self.agendaBtn.frame = CGRectMake(self.overviewBtn.width * 3, 0, self.width/4, self.height);
}

- (void)buttonClicked:(OButton *)sender
{
    if (self.functionButtonClicked) {
        self.functionButtonClicked(sender);
    }
}



@end
