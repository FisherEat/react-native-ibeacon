//
//  XMCarImagesCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/21.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMExhibitionProductImagesCell : OCell
@property (strong, nonatomic) UIImageView *thumbnailIV;
@property (strong, nonatomic) OButton *moreBtn;

@end
