//
//  XMExhibitionCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"
#import "XMShop.h"

@interface XMExhibitionShopCell : OCell
@property (strong, nonatomic) OImageView *thumbIV;
@property (strong, nonatomic) OLabel     *titleLbl;
//@property (strong, nonatomic) OButton    *newsBtn;
//@property (strong, nonatomic) OButton    *detailBtn;
//@property (strong, nonatomic) OButton    *fileBtn;
@property (strong, nonatomic) OLabel     *addressLbl;
@property (strong, nonatomic) OLabel     *dateLbl;


@end
