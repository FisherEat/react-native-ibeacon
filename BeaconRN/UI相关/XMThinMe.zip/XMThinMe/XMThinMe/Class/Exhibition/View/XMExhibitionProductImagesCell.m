//
//  XMCarImagesCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/21.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionProductImagesCell.h"

@implementation XMExhibitionProductImagesCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
//        self.clipsToBounds = YES;
        
        self.thumbnailIV = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:self.thumbnailIV];
        
        self.moreBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.moreBtn setTitle:@"更多" forState:UIControlStateNormal];
        [self.moreBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        self.moreBtn.titleLabel.font = kFont(14);
        self.moreBtn.backgroundColor = [kBlackColor colorWithAlphaComponent:0.4];
        self.moreBtn.cornerRadius = 4;
        [self.moreBtn setBoderColor:kGrayColor width:1];
        self.moreBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 3, 0, 0);
        [self.moreBtn setImage:[UIImage imageNamed:@"exhibition_more"] forState:UIControlStateNormal];
        [self.contentView addSubview:self.moreBtn];
        
        self.height = 200;
        self.thumbnailIV.frame = CGRectMake(self.width - 60, self.height - 35, self.width, self.height);
        self.moreBtn.frame = CGRectMake(self.width - 60, self.height - 35, 55, 30);
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
}


@end
