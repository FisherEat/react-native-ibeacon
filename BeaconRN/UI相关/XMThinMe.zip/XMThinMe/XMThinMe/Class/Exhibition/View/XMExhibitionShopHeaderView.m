//
//  XMExhibitionShopHeaderView.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/13.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMExhibitionShopHeaderView.h"

@interface XMExhibitionShopHeaderView ()
@property (strong, nonatomic) NSArray *images;

@end

@implementation XMExhibitionShopHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:(CGRect)frame];
    if (self) {
        self.backgroundColor = kWhiteColor;
        
        self.scrollView = [[UIScrollView alloc] init];
        self.scrollView.showsHorizontalScrollIndicator = NO;
        self.scrollView.pagingEnabled = YES;
        self.scrollView.bounces = NO;
        self.scrollView.clipsToBounds = YES;
        self.scrollView.delegate = self;
        [self addSubview:self.scrollView];
        
//        self.titleLbl = [[OLabel alloc] init];
//        //        self.titleLbl.text = @"  天津车展";
//        self.titleLbl.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
//        self.titleLbl.textColor = kWhiteColor;
//        [self addSubview:self.titleLbl];
        
        self.pageControl = [[UIPageControl alloc] init];
        [self addSubview:self.pageControl];
        
        self.followBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.followBtn setImage:[UIImage imageNamed:@"exhibition_follow_normal"] forState:UIControlStateNormal];
        [self.followBtn setImage:[UIImage imageNamed:@"exhibition_follow_highlighted"] forState:UIControlStateHighlighted];
        [self addSubview:self.followBtn];
        
        self.overviewBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.overviewBtn setImage:[UIImage imageNamed:@"exhibition_overview_normal"] forState:UIControlStateNormal];
        [self.overviewBtn setImage:[UIImage imageNamed:@"exhibition_overview_highlighted"] forState:UIControlStateHighlighted];
        [self.overviewBtn setTitle:@"简介" forState:UIControlStateNormal];
        self.overviewBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5);
        self.overviewBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        self.overviewBtn.titleLabel.font = kFont(15);
        self.overviewBtn.tag = ExhibitionFunctionButtonOverview;
        [self addSubview:self.overviewBtn];
        
        self.locationBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.locationBtn setImage:[UIImage imageNamed:@"exhibition_location_normal"] forState:UIControlStateNormal];
        [self.locationBtn setImage:[UIImage imageNamed:@"exhibition_location_highlighted"] forState:UIControlStateHighlighted];
        [self.locationBtn setTitle:@"位置" forState:UIControlStateNormal];
        self.locationBtn.imageEdgeInsets = self.overviewBtn.imageEdgeInsets;
        self.locationBtn.titleEdgeInsets = self.overviewBtn.titleEdgeInsets;
        self.locationBtn.titleLabel.font = self.overviewBtn.titleLabel.font;
        self.locationBtn.tag = ExhibitionFunctionButtonLocation;
        [self addSubview:self.locationBtn];
        
        self.fileBtn = [OButton buttonWithType:UIButtonTypeCustom];
        [self.fileBtn setImage:[UIImage imageNamed:@"exhibition_file_logo_normal"] forState:UIControlStateNormal];
        [self.fileBtn setImage:[UIImage imageNamed:@"exhibition_file_logo_highlighted"] forState:UIControlStateHighlighted];
        [self.fileBtn setTitle:@"资料" forState:UIControlStateNormal];
        self.fileBtn.imageEdgeInsets = self.overviewBtn.imageEdgeInsets;
        self.fileBtn.titleEdgeInsets = self.overviewBtn.titleEdgeInsets;
        self.fileBtn.titleLabel.font = self.overviewBtn.titleLabel.font;
        self.fileBtn.tag = ExhibitionFunctionButtonFile;
        [self addSubview:self.fileBtn];
        
        self.scrollView.frame = CGRectMake(0, 0, self.width, 200);
        self.titleLbl.frame = CGRectMake(0, self.scrollView.height - 25, self.width, 25);
        self.pageControl.frame = CGRectMake((self.scrollView.width - 80)/2, self.scrollView.height - 25, 80, 25);
        self.followBtn.frame = CGRectMake(self.width - 80, self.scrollView.height - 35, 75, 30);
        
        self.overviewBtn.frame = CGRectMake(0, 200, self.width/3, self.height - self.scrollView.height);
        self.locationBtn.frame = CGRectMake(self.overviewBtn.width, self.overviewBtn.y, self.overviewBtn.width, self.overviewBtn.height);
        self.fileBtn.frame = CGRectMake(self.overviewBtn.width * 2, self.overviewBtn.y, self.overviewBtn.width, self.overviewBtn.height);

        [self.overviewBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.locationBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.fileBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat   pageWidth   = scrollView.frame.size.width;
    NSInteger currentPage = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.pageControl.currentPage = currentPage;
//    XMAdvertise *advertise = self.advertises[currentPage];
//    self.titleLbl.text = [NSString stringWithFormat:@"  %@", advertise.advertise_title];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
}

- (void)configureViewWithData:(NSArray *)images
{
    self.images = images;
    
    self.pageControl.numberOfPages = images.count;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.width * images.count, self.scrollView.height);
    
    for (UIView *view in self.scrollView.subviews) {
        [view removeFromSuperview];
    }
    for (int i = 0; i < images.count; i++) {
        XMImage *shopImage = images[i];
        CGRect rect = CGRectMake(self.scrollView.width * i, 0, self.scrollView.width, self.scrollView.height);
        UIView *boxView = [[UIView alloc] initWithFrame:rect];
        boxView.clipsToBounds = YES;
        [self.scrollView addSubview:boxView];
        
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:boxView.bounds];
        NSURL *imgUrl = [NSURL URLWithString:shopImage.picture_url];
        NSURLRequest *request = [NSURLRequest requestWithURL:imgUrl];
        __weak UIImageView *iv = imgView;
        mWeakSelf;
        [imgView setImageWithURLRequest:request placeholderImage:kPlaceholderImage_rectangle success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
            iv.image = image;
            CGFloat height = weakSelf.width * (image.size.height / image.size.width);
            if (height > weakSelf.height) {
                iv.frame = CGRectMake(iv.x, -(height-weakSelf.height)/2, iv.width, height);
            } else {
                CGFloat width = weakSelf.height * (image.size.width / image.size.height);
                iv.frame = CGRectMake(iv.x - (width - weakSelf.width)/2, 0, width, iv.height);
                [weakSelf.scrollView sendSubviewToBack:iv];
            }
        } failure:nil];
        [boxView addSubview:imgView];
    }
//    XMAdvertise *advertise = [self.advertises firstObject];
//    self.titleLbl.text = [NSString stringWithFormat:@"  %@", advertise.advertise_title];
}

- (void)buttonClicked:(OButton *)sender
{
    if (self.functionButtonClicked) {
        self.functionButtonClicked(sender);
    }
}


@end
