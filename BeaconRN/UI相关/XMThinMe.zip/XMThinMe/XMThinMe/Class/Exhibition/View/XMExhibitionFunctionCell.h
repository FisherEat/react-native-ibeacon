//
//  XMExhibitionFunctionCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"

/// 定义展会功能按钮的Tag值
typedef NS_ENUM(NSUInteger, ExhibitionFunctionButtonTag) {
    ExhibitionFunctionButtonOverview = 1,
    ExhibitionFunctionButtonLocation,
    ExhibitionFunctionButtonIndoorMap,
    ExhibitionFunctionButtonAgenda,
    ExhibitionFunctionButtonFile,
};

@interface XMExhibitionFunctionCell : OCell
@property (strong, nonatomic) OButton *overviewBtn;
@property (strong, nonatomic) OButton *locationBtn;
@property (strong, nonatomic) OButton *indoorMapBtn;
@property (strong, nonatomic) OButton *agendaBtn;

@property (copy, nonatomic) void (^functionButtonClicked) (OButton *sender);

@end
