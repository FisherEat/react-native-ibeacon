//
//  XMExhibitionProductCell.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/11.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMExhibitionProductCell.h"

@implementation XMExhibitionProductCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView.backgroundColor = kWhiteColor;
        self.contentView.cornerRadius = 2;

        self.thumbIV = [[OImageView alloc] init];
        [self.contentView addSubview:self.thumbIV];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kFont(14);
        self.titleLbl.contentMode = UIControlContentVerticalAlignmentTop;
        self.titleLbl.numberOfLines = 2;
        [self.contentView addSubview:self.titleLbl];

        self.priceLbl = [[OLabel alloc] init];
        self.priceLbl.font = kFont(13);
        self.priceLbl.textColor = kBrownColor;
        self.priceLbl.textAlignment = NSTextAlignmentRight;
        self.priceLbl.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.priceLbl];
        
//        self.likeBtn = [OButton buttonWithType:UIButtonTypeCustom];
//        [self.likeBtn setImage:[UIImage imageNamed:@"exihibition_product_like"] forState:UIControlStateNormal];
//        self.likeBtn.userInteractionEnabled = NO;
//        [self.contentView addSubview:self.likeBtn];
//        
//        self.shareBtn = [OButton buttonWithType:UIButtonTypeCustom];
//        [self.shareBtn setImage:[UIImage imageNamed:@"exihibition_product_share"] forState:UIControlStateNormal];
//        self.shareBtn.userInteractionEnabled = NO;
//        [self.contentView addSubview:self.shareBtn];
//        
//        self.commentBtn = [OButton buttonWithType:UIButtonTypeCustom];
//        [self.commentBtn setImage:[UIImage imageNamed:@"exihibition_product_edit"] forState:UIControlStateNormal];
//        self.commentBtn.userInteractionEnabled = NO;
//        [self.contentView addSubview:self.commentBtn];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.thumbIV.frame = CGRectMake(0, 0, self.width, self.height - 35);
    self.titleLbl.frame = CGRectMake(5, self.thumbIV.bottom + 5, self.width - 60, 25);
    self.priceLbl.frame = CGRectMake(self.titleLbl.right, self.titleLbl.y, 50, self.titleLbl.height);
//    self.commentBtn.frame = CGRectMake(self.width - 20, self.priceLbl.y, 15, 15);
//    self.shareBtn.frame = CGRectMake(self.commentBtn.x - self.commentBtn.width, self.commentBtn.y, self.commentBtn.width, self.commentBtn.height);
//    self.likeBtn.frame = CGRectMake(self.shareBtn.x - self.commentBtn.width, self.commentBtn.y, self.commentBtn.width, self.commentBtn.height);
}

- (void)configureViewWithData:(XMProduct *)product
{
    NSURL *imgUrl = [NSURL URLWithString:product.image_url];
    [self.thumbIV setImageWithURL:imgUrl placeholderImage:kPlaceholderImage_rectangle];
    self.titleLbl.text = product.product_name;
    self.priceLbl.text = [NSString stringWithFormat:@"%.2f元", product.official_quotation];
}


@end
