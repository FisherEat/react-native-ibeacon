//
//  XMExhibitionImagesCell.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"
#import "XMAdvertise.h"

@interface XMExhibitionImagesCell : OCell <UIScrollViewDelegate>
@property (strong, nonatomic) UIScrollView  *scrollView;
@property (strong, nonatomic) OLabel        *titleLbl;
@property (strong, nonatomic) UIPageControl *pageControl;

@end
