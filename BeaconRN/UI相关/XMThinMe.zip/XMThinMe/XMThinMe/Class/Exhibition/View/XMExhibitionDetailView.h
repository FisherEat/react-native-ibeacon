//
//  XMExhibitionDetailView.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OCell.h"
#import "XMExhibitionProductCell.h"
#import "XMExhibitionShopHeaderView.h"


@interface XMExhibitionDetailView : UIView
@property (strong, nonatomic) UICollectionView *collectionView;

@property (strong, nonatomic) SelectCellBlock selectCellBlcok;

/// 产品缩略图
@property (strong, nonatomic) NSArray *shopImages;

@property (strong, nonatomic) NSMutableArray *products;

@property (copy, nonatomic) void (^functionButtonClicked) (OButton *sender);

/// 关注按钮点击事件
@property (copy, nonatomic) void (^followButtonClicked) (OButton *sender);



@property (assign, nonatomic) NSInteger pageIndex;



@end
