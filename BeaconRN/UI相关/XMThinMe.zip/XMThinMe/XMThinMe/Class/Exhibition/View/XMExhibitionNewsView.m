//
//  XMExhibitionNewsView.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionNewsView.h"
#import "XMNews.h"

@implementation XMExhibitionNewsView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.news = @[].mutableCopy;

        self.talbeView = [[UITableView alloc] initWithFrame:self.bounds];
        self.talbeView.delegate = self;
        self.talbeView.dataSource = self;
        self.talbeView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.talbeView.backgroundColor = mRGB(232, 232, 232);
        [self addSubview:self.talbeView];
    }
    return self;
}

#pragma mark - delegate && datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.news.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 370;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"exhibitionNewsCell";
    XMMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMMessageCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    
    XMMessage *message = self.news[indexPath.row];
    [cell configureCellWithCellData:message];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (self.selectCellBlcok) {
        self.selectCellBlcok(indexPath, nil);
    }
}

@end
