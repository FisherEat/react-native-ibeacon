//
//  XMExhibitionCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionShopCell.h"

@implementation XMExhibitionShopCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.height = 100;

        UIView *boxView = [[UIView alloc] initWithFrame:CGRectMake(10, (self.height-80)/2, 120, 80)];
        boxView.clipsToBounds = YES;
        [boxView setBoderColor:mRGBToColor(0xe8e8e8) width:0.5];
        boxView.cornerRadius = 4;
        [self.contentView addSubview:boxView];
        
        self.thumbIV = [[OImageView alloc] initWithFrame:boxView.bounds];
        [boxView addSubview:self.thumbIV];
        
        self.titleLbl = [[OLabel alloc] init];
        self.titleLbl.font = kFont(16);
        self.titleLbl.contentMode = UIControlContentVerticalAlignmentTop;
        self.titleLbl.numberOfLines = 2;
        [self.contentView addSubview:self.titleLbl];
        
        self.addressLbl = [[OLabel alloc] init];
        self.addressLbl.textColor = mRGBToColor(0xa4a4a4);
        self.addressLbl.font = kFont(14);
        [self.contentView addSubview:self.addressLbl];
        
        self.dateLbl = [[OLabel alloc] init];
        self.dateLbl.textColor = mRGBToColor(0xa4a4a4);
        self.dateLbl.font = kFont(14);
        self.dateLbl.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.dateLbl];
        
//        self.newsBtn = [OButton buttonWithType:UIButtonTypeCustom];
//        [self.newsBtn setImage:[UIImage imageNamed:@"exhibition_news"] forState:UIControlStateNormal];
//        self.newsBtn.userInteractionEnabled = NO;
//        [self.contentView addSubview:self.newsBtn];
//        
//        self.detailBtn = [OButton buttonWithType:UIButtonTypeCustom];
//        [self.detailBtn setImage:[UIImage imageNamed:@"exhibition_detail"] forState:UIControlStateNormal];
//        self.detailBtn.userInteractionEnabled = NO;
//        [self.contentView addSubview:self.detailBtn];
//
//        self.fileBtn = [OButton buttonWithType:UIButtonTypeCustom];
//        [self.fileBtn setImage:[UIImage imageNamed:@"exhibition_file"] forState:UIControlStateNormal];
//        self.fileBtn.userInteractionEnabled = NO;
//        [self.contentView addSubview:self.fileBtn];
        self.titleLbl.frame = CGRectMake(boxView.right + 10, 10, self.width - boxView.right - 20 , 30);
        self.addressLbl.frame = CGRectMake(self.titleLbl.x, self.titleLbl.bottom + 5, self.titleLbl.width, 15);
        self.dateLbl.frame = CGRectMake(self.titleLbl.x, self.addressLbl.bottom + 5, self.titleLbl.width, 20);
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
//    self.newsBtn.frame    = CGRectMake(self.titleLbl.x, self.addressLbl.bottom + 5, 42, 20);
//    self.detailBtn.frame  = CGRectMake(self.newsBtn.right + 3, self.newsBtn.y, self.newsBtn.width, self.newsBtn.height);
//    self.fileBtn.frame    = CGRectMake(self.detailBtn.right + 3, self.newsBtn.y, self.newsBtn.width, self.newsBtn.height);
}

- (void)configureCellWithCellData:(XMShop *)shop
{
    NSDate *startDate  = [NSDate dateWithTimeIntervalSince1970:shop.start_time];
    NSDate *endDate    = [NSDate dateWithTimeIntervalSince1970:shop.end_time];
    NSString *startStr = [[[NVDate alloc] initUsingDate:startDate] stringValueWithFormat:@"YYYY年MM月dd日"];
    NSString *endStr   = [[[NVDate alloc] initUsingDate:endDate] stringValueWithFormat:@"MM月dd日"];
//    if (shop.type == XMBeaconTypeTrip) {
        startStr = [[[NVDate alloc] initUsingDate:startDate] stringValueWithFormat:@"HH:mm"];
        endStr = [[[NVDate alloc] initUsingDate:endDate] stringValueWithFormat:@"HH:mm"];
//    } else if (shop.type == XMBeaconTypeExhibition) {
//        
//    }
    self.dateLbl.text = [NSString stringWithFormat:@"%@—%@", startStr, endStr];
    self.titleLbl.text = shop.shop_name;
    self.addressLbl.text = shop.address;

    NSURL *imgUrl = [NSURL URLWithString:shop.logo_url];
    NSURLRequest *request = [NSURLRequest requestWithURL:imgUrl];
    __weak UIImageView *iv = self.thumbIV;
    [self.thumbIV setImageWithURLRequest:request placeholderImage:kPlaceholderImage_rectangle success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
        iv.image = image;
        CGFloat height = iv.width * (image.size.height / image.size.width);
        if (height > iv.height) {
            iv.frame = CGRectMake(0, -(height - iv.height)/2, iv.width, height);
        } else {
            CGFloat width = iv.height * (image.size.width / image.size.height);
            iv.frame = CGRectMake(-(width - iv.width)/2, 0, width, iv.height);
        }
    } failure:nil];
}

+ (CGFloat)cellHeightForCellData:(id)cellData
{
    return 100;
}



@end
