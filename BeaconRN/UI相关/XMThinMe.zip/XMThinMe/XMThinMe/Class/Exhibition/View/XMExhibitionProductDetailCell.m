//
//  XMCarDetailCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/22.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionProductDetailCell.h"

@implementation XMExhibitionProductDetailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier];
    if (self) {
        self.backgroundView.backgroundColor = kGreenColor;
        self.seprator.hidden = YES;
        self.selectionStyle = UITableViewCellSeparatorStyleNone;

        self.titleLbl = [[OLabel alloc] initWithFrame:CGRectMake(10, 10, self.width-20, 35)];
        self.titleLbl.font = kFont(16);
        [self.contentView addSubview:self.titleLbl];
        
        self.titleSeprator = [[UIView alloc] initWithFrame:CGRectMake(self.titleLbl.x, self.titleLbl.bottom, self.titleLbl.width, 0.5)];
        self.titleSeprator.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.5];
        [self.contentView addSubview:self.titleSeprator];
        
        self.priceLbl = [[OLabel alloc] initWithFrame:CGRectMake(self.titleSeprator.right - 80, self.titleLbl.y, 80, self.titleLbl.height)];
        self.priceLbl.font = kFont(16);
        self.priceLbl.textColor = kRedColor;
        self.priceLbl.textAlignment = NSTextAlignmentRight;
        self.priceLbl.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.priceLbl];
        
        self.contentLbl = [[OLabel alloc] initWithFrame:CGRectMake(self.titleLbl.x, self.titleSeprator.bottom + 5, self.titleLbl.width, 210)];
        self.contentLbl.numberOfLines = 0;
        [self.contentView addSubview:self.contentLbl];
    }
    return self;
}

+ (CGFloat)cellHeightForCellData:(id)cellData
{
    return 55 + [[self class] contentHeight:cellData[@"content"]];
}

+ (CGFloat)contentHeight:(NSString *)content
{
    CGFloat height = [content heightForConstraintSize:CGSizeMake(mScreenWidth - 20, 99999) font:kN_MiddleFont] + 15;
    if (height < 40) {
        height = 40;
    }
    return height;
}

- (void)configureCellWithCellData:(id)cellData
{
    self.contentLbl.height = [[self class] contentHeight:cellData[@"content"]];
    self.contentLbl.text = cellData[@"content"];
    self.titleLbl.text = cellData[@"title"];
}


@end
