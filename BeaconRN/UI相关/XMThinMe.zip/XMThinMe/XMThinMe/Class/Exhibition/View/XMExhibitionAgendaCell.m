//
//  XMExhibitionAgendaCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionAgendaCell.h"

@implementation XMExhibitionAgendaCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.thumbIV = [[OImageView alloc] init];
        self.thumbIV.image = [UIImage imageNamed:@"exhibition_agenda_highlighted"];
        [self.contentView addSubview:self.thumbIV];
        
        self.dateLbl = [[OLabel alloc] init];
        self.dateLbl.font = kB_SmallFont;
        self.dateLbl.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.dateLbl];
        
        self.titleLbl = [[OLabel alloc] init];
        [self.contentView addSubview:self.titleLbl];
        
        self.addressLbl = [[OLabel alloc] init];
        [self.contentView addSubview:self.addressLbl];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.thumbIV.frame = CGRectMake(10, 10, 30, 30);
    self.dateLbl.frame = CGRectMake(self.thumbIV.right + 5, 10, self.width - self.thumbIV.right - 20, 25);
    self.titleLbl.frame = CGRectMake(self.dateLbl.x, self.dateLbl.bottom + 8, self.dateLbl.width, 20);
    self.addressLbl.frame = CGRectMake(self.dateLbl.x, self.titleLbl.bottom + 10, self.dateLbl.width, self.titleLbl.height);
    
    self.seprator.frame = CGRectMake(10, self.seprator.y, self.width-20, self.seprator.height);
}

- (void)configureCellWithCellData:(XMAgenda *)agenda
{
    NSDate *startDate  = [NSDate dateWithTimeIntervalSince1970:agenda.start_time];
    NSDate *endDate    = [NSDate dateWithTimeIntervalSince1970:agenda.end_time];
    NSString *startStr = [[[NVDate alloc] initUsingDate:startDate] stringValueWithFormat:@"YYYY年MM月dd日 HH:mm"];
    NSString *endStr   = [[[NVDate alloc] initUsingDate:endDate] stringValueWithFormat:@"HH:mm"];

    self.dateLbl.text = [NSString stringWithFormat:@"%@ — %@", startStr, endStr];
    self.titleLbl.text = agenda.agenda_title;
    self.addressLbl.text = [NSString stringWithFormat:@"地址:%@", agenda.address];
}

@end
