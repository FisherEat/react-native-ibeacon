//
//  XMExhibitionFileView.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OView.h"
#import "XMFileCell.h"

@interface XMExhibitionFileView : OView <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) UITableView *talbeView;
@property (strong, nonatomic) SelectCellBlock selectCellBlcok;

@property (strong, nonatomic) NSMutableArray *files;

@property (copy, nonatomic) void (^downloadButtonClicked) (XMFileCell *cell);


@end
