//
//  XMExhibitionShopHeaderView.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/13.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OView.h"
#import "XMImage.h"
#import "XMExhibitionFunctionCell.h"

@interface XMExhibitionShopHeaderView : UICollectionReusableView <UIScrollViewDelegate>
@property (strong, nonatomic) UIScrollView  *scrollView;
@property (strong, nonatomic) OLabel        *titleLbl;
@property (strong, nonatomic) UIPageControl *pageControl;
@property (strong, nonatomic) OButton       *followBtn;

@property (strong, nonatomic) OButton       *overviewBtn;
@property (strong, nonatomic) OButton       *locationBtn;
@property (strong, nonatomic) OButton       *fileBtn;

@property (copy, nonatomic) void (^functionButtonClicked) (OButton *sender);

@end
