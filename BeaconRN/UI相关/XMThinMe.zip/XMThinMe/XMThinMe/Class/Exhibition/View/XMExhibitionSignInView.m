//
//  XMExhibitionSignInView.m
//  XMThinMe
//
//  Created by 何振东 on 14/12/2.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMExhibitionSignInView.h"
#import "JWGCircleCounter.h"

@interface XMExhibitionSignInView ()
@property (strong, nonatomic) UIScrollView *scrollView;

@property (strong, nonatomic) OLabel *titleLbl1;
@property (strong, nonatomic) OLabel *titleLbl2;
@property (strong, nonatomic) OLabel *titleLbl3;
@property (strong, nonatomic) OLabel *titleLbl4;

@end


@implementation XMExhibitionSignInView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        self.scrollView.alwaysBounceVertical = YES;
        [self addSubview:self.scrollView];
        
        UIImageView *bgImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.width, 200)];
        bgImg.image = [UIImage imageNamed:@"home_top_bg"];
        [self.scrollView addSubview:bgImg];
        
        UIView *boxView = [[UIView alloc] initWithFrame:CGRectMake(10, 20, self.width - 20, 160)];
        boxView.cornerRadius = 6;
        boxView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"home_message_bg"]];
        [self.scrollView addSubview:boxView];
        
        JWGCircleCounter *circleView = [[JWGCircleCounter alloc] initWithFrame:CGRectMake(20, 20, 120, 120)];
        circleView.circleBackgroundColor = kOrangeColor;
        circleView.circleColor = kWhiteColor;
        circleView.circleTimerWidth = 2;
        circleView.backgroundColor = mRGB(171, 165, 153);
        circleView.cornerRadius = circleView.width/2;
        [circleView startWithSeconds:3];
        [self bk_performBlock:^(id obj) {
            [circleView stop];
        } afterDelay:1];
        circleView.textLbl.text = @"9折\n";
        circleView.textLbl.numberOfLines = 2;
        circleView.textLbl.textColor = kWhiteColor;
        circleView.textLbl.font = kB_Font(24);
        [boxView addSubview:circleView];
        
        OLabel *lbl = [[OLabel alloc] initWithFrame:CGRectMake(0, 60, circleView.width, 30)];
        lbl.text = @"消费优惠";
        lbl.textAlignment = NSTextAlignmentCenter;
        lbl.textColor = mRGB(215, 214, 210);
        [circleView addSubview:lbl];

        self.titleLbl1 = [[OLabel alloc] initWithFrame:CGRectMake(boxView.width - 110, 20, 100, 30)];
        self.titleLbl1.textAlignment = NSTextAlignmentCenter;
        self.titleLbl1.textColor = kWhiteColor;
        self.titleLbl1.text = @"90天累计到访";
        [boxView addSubview:self.titleLbl1];
        
        self.titleLbl2 = [[OLabel alloc] initWithFrame:CGRectMake(self.titleLbl1.x, self.titleLbl1.bottom, 100, 30)];
        self.titleLbl2.textAlignment = NSTextAlignmentCenter;
        self.titleLbl2.textColor = kWhiteColor;
        self.titleLbl2.text = @"7次";
        self.titleLbl2.font = kB_Font(17);
        [boxView addSubview:self.titleLbl2];
        
        self.titleLbl3 = [[OLabel alloc] initWithFrame:CGRectMake(self.titleLbl1.x, self.titleLbl2.bottom, 100, 30)];
        self.titleLbl3.textAlignment = NSTextAlignmentCenter;
        self.titleLbl3.textColor = kWhiteColor;
        self.titleLbl3.text = @"再到访3次";
        [boxView addSubview:self.titleLbl3];

        self.titleLbl4 = [[OLabel alloc] initWithFrame:CGRectMake(self.titleLbl1.x, self.titleLbl3.bottom, 100, 30)];
        self.titleLbl4.textAlignment = NSTextAlignmentCenter;
        self.titleLbl4.textColor = kWhiteColor;
        self.titleLbl4.text = @"消费可打6.5折";
        [boxView addSubview:self.titleLbl4];

        OLabel *lbl1 = [[OLabel alloc] initWithFrame:CGRectMake(0, bgImg.bottom + 10, self.width, 30)];
        lbl1.textAlignment = NSTextAlignmentCenter;
        lbl1.text = @"签到次数";
        [self.scrollView addSubview:lbl1];

        OLabel *lbl2 = [[OLabel alloc] initWithFrame:CGRectMake(30, lbl1.bottom, self.width/2-30, 30)];
        lbl2.text = @"奖励规则";
        [self.scrollView addSubview:lbl2];

        OLabel *lbl3 = [[OLabel alloc] initWithFrame:CGRectMake(self.width/2, lbl1.bottom, self.width/2-30, 30)];
        lbl3.textAlignment = NSTextAlignmentRight;
        lbl3.text = @"说明>>";
        [self.scrollView addSubview:lbl3];
        
        UIView *hLine = [[UIView alloc] initWithFrame:CGRectMake(30, lbl1.bottom + 25, self.width - 30 * 2, 1)];
        hLine.backgroundColor = mRGB(198, 198, 198);
        [self.scrollView addSubview:hLine];
        
        UIView *vLine = [[UIView alloc] initWithFrame:CGRectMake((self.width - 3)/2, lbl1.bottom + 25, 3, 260)];
        vLine.backgroundColor = mRGB(198, 198, 198);
        [self.scrollView addSubview:vLine];

        OLabel *dotView = [[OLabel alloc] initWithFrame:CGRectMake((self.width - 30)/2, lbl1.bottom + 10, 30, 30)];;
        dotView.cornerRadius = dotView.width/2;
        dotView.backgroundColor = mRGB(181, 186, 58);
        dotView.text = @"0";
        dotView.textAlignment = NSTextAlignmentCenter;
        dotView.font = kB_Font(18);
        dotView.textColor = kWhiteColor;
        [self.scrollView addSubview:dotView];
        
        OLabel *smallDot1 = [[OLabel alloc] initWithFrame:CGRectMake(vLine.x - 25, dotView.bottom + 57/2 - 5, 10, 10)];;
        smallDot1.backgroundColor = dotView.backgroundColor;
        smallDot1.cornerRadius = smallDot1.width/2;
        [self.scrollView addSubview:smallDot1];
        
        UIView *hLine1 = [[UIView alloc] initWithFrame:CGRectMake(smallDot1.right, smallDot1.centerY - 1.5, vLine.x - smallDot1.right, 3)];
        hLine1.backgroundColor = mRGB(198, 198, 198);
        [self.scrollView addSubview:hLine1];
        
        OLabel *tipsLbl1 = [[OLabel alloc] initWithFrame:CGRectMake(smallDot1.x - 100, smallDot1.y - 5, 90, 20)];
        tipsLbl1.text = @"消费打8.5折";
        tipsLbl1.textAlignment = NSTextAlignmentRight;
        [self.scrollView addSubview:tipsLbl1];
        
        OLabel *dotView1 = [[OLabel alloc] initWithFrame:CGRectMake(dotView.x, dotView.bottom + 57, dotView.width, dotView.height)];;
        dotView1.cornerRadius = dotView.width/2;
        dotView1.backgroundColor = mRGB(125, 159, 158);
        dotView1.textAlignment = NSTextAlignmentCenter;
        dotView1.font = dotView.font;
        dotView1.text = @"1";
        dotView1.textColor = kWhiteColor;
        [self.scrollView addSubview:dotView1];
        
        OLabel *smallDot2 = [[OLabel alloc] initWithFrame:CGRectMake(vLine.right + 15, dotView1.bottom + 57/2 - 5, 10, 10)];;
        smallDot2.backgroundColor = dotView1.backgroundColor;
        smallDot2.cornerRadius = smallDot2.width/2;
        [self.scrollView addSubview:smallDot2];
        
        UIView *hLine2 = [[UIView alloc] initWithFrame:CGRectMake(vLine.right, smallDot2.centerY - 1.5, smallDot2.x-vLine.right, 3)];
        hLine2.backgroundColor = mRGB(198, 198, 198);
        [self.scrollView addSubview:hLine2];
        
        OLabel *tipsLbl2 = [[OLabel alloc] initWithFrame:CGRectMake(smallDot2.x + 10, smallDot2.y - 5, 90, 20)];
        tipsLbl2.text = @"消费打7.5折";
        tipsLbl2.textAlignment = NSTextAlignmentRight;
        [self.scrollView addSubview:tipsLbl2];

        OLabel *dotView2 = [[OLabel alloc] initWithFrame:CGRectMake(dotView.x, dotView1.bottom + 57, dotView.width, dotView.height)];
        dotView2.cornerRadius = dotView.width/2;
        dotView2.backgroundColor = mRGB(146, 121, 213);
        dotView2.textAlignment = NSTextAlignmentCenter;
        dotView2.font = dotView.font;
        dotView2.text = @"10";
        dotView2.textColor = kWhiteColor;
        [self.scrollView addSubview:dotView2];
        
        OLabel *smallDot3 = [[OLabel alloc] initWithFrame:CGRectMake(vLine.x - 25, dotView2.bottom + 57/2 - 5, 10, 10)];;
        smallDot3.backgroundColor = dotView2.backgroundColor;
        smallDot3.cornerRadius = smallDot3.width/2;
        [self.scrollView addSubview:smallDot3];
        
        UIView *hLine3 = [[UIView alloc] initWithFrame:CGRectMake(smallDot3.right, smallDot3.centerY - 1.5, vLine.x - smallDot3.right, 3)];
        hLine3.backgroundColor = mRGB(198, 198, 198);
        [self.scrollView addSubview:hLine3];
        
        OLabel *tipsLbl3 = [[OLabel alloc] initWithFrame:CGRectMake(smallDot3.x - 100, smallDot3.y - 5, 90, 20)];
        tipsLbl3.text = @"消费打6.5折";
        tipsLbl3.textAlignment = NSTextAlignmentRight;
        [self.scrollView addSubview:tipsLbl3];


        self.scrollView.contentSize = CGSizeMake(self.scrollView.width, vLine.bottom);
    }
    return self;
}


@end
