//
//  XMExhibitionDetailView.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/28.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionDetailView.h"
#import "XMExhibitionProductCell.h"

static NSString * const productReuseIdentifier = @"productCell";

@interface XMExhibitionDetailView () <UICollectionViewDelegate, UICollectionViewDataSource, OWaterfallLayoutDelegate>
@property (strong, nonatomic) XMExhibitionShopHeaderView *headerView;

@end



@implementation XMExhibitionDetailView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.products = @[].mutableCopy;
        
        OWaterfallLayout *layout = [[OWaterfallLayout alloc] init];
        layout.delegate = self;
        self.collectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:layout];
        self.collectionView.delegate = self;
        self.collectionView.alwaysBounceVertical = YES;
        self.collectionView.dataSource = self;
        self.collectionView.backgroundColor = mRGB(232, 232, 232);
        [self addSubview:self.collectionView];
        
        self.headerView = [[XMExhibitionShopHeaderView alloc] initWithFrame:CGRectMake(0, -280, self.width, 280)];
        [self.collectionView addSubview:self.headerView];
        
        self.collectionView.contentInset = UIEdgeInsetsMake(280, 0, 0, 0);

        [self.collectionView registerClass:[XMExhibitionProductCell class] forCellWithReuseIdentifier:productReuseIdentifier];
    }
    return self;
}

- (void)setFollowButtonClicked:(void (^)(OButton *))followButtonClicked
{
    _followButtonClicked = followButtonClicked;
    [self.headerView.followBtn bk_addEventHandler:followButtonClicked forControlEvents:UIControlEventTouchUpInside];
}

- (void)setFunctionButtonClicked:(void (^)(OButton *))functionButtonClicked
{
    _functionButtonClicked = functionButtonClicked;
    self.headerView.functionButtonClicked = functionButtonClicked;
}

- (void)setShopImages:(NSArray *)shopImages
{
    _shopImages = shopImages;
    [self.headerView  configureViewWithData:shopImages];
}


#pragma mark <UICollectionViewDataSource>

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.products.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    XMExhibitionProductCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:productReuseIdentifier forIndexPath:indexPath];
    [cell configureViewWithData:self.products[indexPath.item]];
    
    return cell;
}

#pragma mark <UICollectionViewDelegate>

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.selectCellBlcok) {
        self.selectCellBlcok(indexPath, self.products[indexPath.row]);
    }
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout heightForItemAtIndexPath:(NSIndexPath *)indexPath
{
    XMProduct *product = self.products[indexPath.item];
    if (product.width && product.height) {
        CGFloat height = (mScreenWidth/2 - 8) * product.height /product.width;
        return height + 35;
    }
    
    return 220;
}

@end
