//
//  XMExhibitionProductCell.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/11.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OCell.h"
#import "XMProduct.h"

@interface XMExhibitionProductCell : UICollectionViewCell
@property (strong, nonatomic) OImageView *thumbIV;
@property (strong, nonatomic) OLabel     *titleLbl;
//@property (strong, nonatomic) OButton    *likeBtn;
//@property (strong, nonatomic) OButton    *shareBtn;
//@property (strong, nonatomic) OButton    *commentBtn;
@property (strong, nonatomic) OLabel     *priceLbl;

@end
