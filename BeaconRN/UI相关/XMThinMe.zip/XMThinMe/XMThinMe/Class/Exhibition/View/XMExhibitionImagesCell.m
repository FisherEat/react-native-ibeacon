//
//  XMExhibitionImagesCell.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionImagesCell.h"

@interface XMExhibitionImagesCell ()
@property (strong, nonatomic) NSArray *advertises;

@end

@implementation XMExhibitionImagesCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSeparatorStyleNone;
        
        self.scrollView = [[UIScrollView alloc] init];
        self.scrollView.showsHorizontalScrollIndicator = NO;
        self.scrollView.pagingEnabled = YES;
        self.scrollView.bounces = NO;
        self.scrollView.delegate = self;
        [self.contentView addSubview:self.scrollView];
        
        self.titleLbl = [[OLabel alloc] init];
//        self.titleLbl.text = @"  天津车展";
        self.titleLbl.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
        self.titleLbl.textColor = kWhiteColor;
        [self.contentView addSubview:self.titleLbl];
        
        self.pageControl = [[UIPageControl alloc] init];
        [self.contentView addSubview:self.pageControl];
    }
    return self;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat   pageWidth   = scrollView.frame.size.width;
    NSInteger currentPage = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.pageControl.currentPage = currentPage;
    XMAdvertise *advertise = self.advertises[currentPage];
    self.titleLbl.text = [NSString stringWithFormat:@"  %@", advertise.advertise_title];
}

- (void)configureCellWithCellData:(NSArray *)advertises
{
    self.advertises = advertises;
    self.height = 200;
    self.scrollView.frame = self.bounds;
    self.titleLbl.frame = CGRectMake(0, self.height - 25, self.width, 25);
    self.pageControl.frame = CGRectMake(self.width - 60, self.titleLbl.y, 60, 25);

    for (UIView *view in self.scrollView.subviews) {
        [view removeFromSuperview];
    }
    
    for (int i = 0; i < advertises.count; i++) {
        XMAdvertise *advertise = advertises[i];
        CGRect rect = CGRectMake(self.scrollView.width * i, 0, self.scrollView.width, self.scrollView.height);
        NSURL *imgUrl = [NSURL URLWithString:advertise.picture_url];
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:rect];
        [imgView setImageWithURL:imgUrl placeholderImage:kPlaceholderImage_rectangle];
        [self.scrollView addSubview:imgView];
    }
    XMAdvertise *advertise = [self.advertises firstObject];
    self.titleLbl.text = [NSString stringWithFormat:@"  %@", advertise.advertise_title];

    self.pageControl.numberOfPages = advertises.count;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.width * advertises.count, self.scrollView.height);
}

@end
