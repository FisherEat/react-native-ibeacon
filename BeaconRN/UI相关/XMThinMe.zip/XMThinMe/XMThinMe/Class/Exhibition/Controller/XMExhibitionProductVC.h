//
//  XMCarDetailVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/22.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "OViewController.h"
#import "XMProduct.h"

@interface XMExhibitionProductVC : UITableViewController
@property (strong, nonatomic) XMProduct *product;

@end
