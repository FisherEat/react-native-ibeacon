//
//  XMExhibitionAgendaVC.h
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMBusiness.h"

@interface XMExhibitionAgendaVC : UITableViewController
@property (strong, nonatomic) XMBusiness *business;

@end
