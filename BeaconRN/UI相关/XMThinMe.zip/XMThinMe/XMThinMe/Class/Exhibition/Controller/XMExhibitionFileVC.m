//
//  XMExhibitionFileVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/18.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMExhibitionFileVC.h"
#import "XMFileCell.h"
#import "XMReadFileVC.h"


@interface XMExhibitionFileVC () <UIActionSheetDelegate, GalleryViewDelegate>
@property (strong, nonatomic) NSMutableArray *files;
@property (strong, nonatomic) XMFile *shareFile;

@end

@implementation XMExhibitionFileVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.files = @[].mutableCopy;
    self.title = @"资料";
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self requestFileList];
}


#pragma mark - delegate && datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.files.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 85;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"exhibitionNewsCell";
    XMFileCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        mWeakSelf;
        cell = [[XMFileCell alloc] initWithStyle:0 reuseIdentifier:identifier];

        MGSwipeButton *downloadBtn = [MGSwipeButton buttonWithTitle:nil icon:[UIImage imageNamed:@"file_download_normal"] backgroundColor:mRGB(225, 76, 77) callback:^BOOL(MGSwipeTableCell *sender) {
            XMFileCell *cell = (XMFileCell *)sender;
            [cell.indicatorView startAnimating];
            XMFile *file = weakSelf.files[indexPath.row];
            NSString *suffix = [[file.attachment_url componentsSeparatedByString:@"."] lastObject];
            suffix = [[suffix componentsSeparatedByString:@"_"] firstObject];
            NSString *path = [NSString stringWithFormat:@"%@/%@.%@", kXM_Download_Dir, file.attachment_name, suffix];
            [OURLRequest downloadFile:file.attachment_url toPath:path completionHandler:^(id data, NSError *error) {
                [cell.indicatorView stopAnimating];
                
                if (!error) {
                    file.local_Path = path;
                    [[XMDBManager sharedInstance] updateFileInfo:file];
                    [weakSelf.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                } else {
                    [XMProgressHUD showTips:@"加载资料失败！" atView:weakSelf.view];
                }
            }];
            
            return YES;
        }];
        downloadBtn.width = 85;
        MGSwipeButton *shareBtn = [MGSwipeButton buttonWithTitle:nil icon:[UIImage imageNamed:@"file_share"] backgroundColor:mRGB(251, 136, 50) callback:^BOOL(MGSwipeTableCell *sender) {
            weakSelf.shareFile = weakSelf.files[indexPath.row];
            NSString *title = [NSString stringWithFormat:@"分享%@到...", weakSelf.shareFile.attachment_name];
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:title delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"微信好友", @"微信朋友圈", @"收藏到微信", nil];
            [actionSheet showInView:mKeyWindow];
            
            return YES;
        }];
        cell.rightButtons = @[downloadBtn, shareBtn];
    }
    [cell configureCellWithCellData:self.files[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    XMFileCell *cell = (XMFileCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    XMFile *file = self.files[indexPath.row];
    NSString *suffix = [[file.attachment_url componentsSeparatedByString:@"."] lastObject];
    suffix = [[suffix componentsSeparatedByString:@"_"] firstObject];
    NSString *path = [NSString stringWithFormat:@"%@/%@.%@", kXM_Download_Dir, file.attachment_name, suffix];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
        [self showFile:path suffix:suffix];
        return;
    }

    /// 若没有下载，则先下载资料，再显示
    [cell.indicatorView startAnimating];
    mWeakSelf;
    [OURLRequest downloadFile:file.attachment_url toPath:path completionHandler:^(id data, NSError *error) {
        [cell.indicatorView stopAnimating];
        if (!error) {
            file.local_Path = path;
            [[XMDBManager sharedInstance] updateFileInfo:file];
            [weakSelf.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [weakSelf showFile:path suffix:suffix];
        } else {
            [XMProgressHUD showTips:@"加载资料失败！" atView:weakSelf.view];
        }
    }];
}

- (void)showFile:(NSString *)path suffix:(NSString *)suffix
{
    NSString *type = @"jpg png jpeg";

    if ([type containString:suffix]) {
        UIImage *image = [UIImage imageWithContentsOfFile:path];
        if (image) {
            GalleryView *galleryView = [[GalleryView alloc] initWithFrame:mKeyWindow.bounds];
            galleryView.delegate = self;
            galleryView.alpha = 0;
            [galleryView setImages:@[image]];
            [mKeyWindow addSubview:galleryView];
            
            [UIView animateWithDuration:0.75 animations:^{
                galleryView.alpha = 1;
            }];
        } else {
            [XMProgressHUD showTips:@"文件不存在" atView:self.view];
        }
    } else {
        XMReadFileVC *readFileVC = [[XMReadFileVC alloc] init];
        readFileVC.filePath = path;
        [self.navigationController pushViewController:readFileVC animated:YES];
    }
}


#pragma mark - galleryview delegate

- (void)galleryView:(GalleryView *)galleryView didSelectPageAtIndex:(NSInteger)pageIndex
{
    [UIView animateWithDuration:0.45 animations:^{
        galleryView.alpha = 0.0;
    } completion:^(BOOL finished) {
        [galleryView removeFromSuperview];
    }];
}


#pragma mark - network request

- (void)requestFileList
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Shop_GetEntityAttachmentList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         for (NSDictionary *dict in data) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
             XMFile *file = [[XMFile alloc] initWithJSONData:objectData];
             [weakSelf.files addObject:file];
         }
         [weakSelf.tableView reloadData];
     }];
}

@end
