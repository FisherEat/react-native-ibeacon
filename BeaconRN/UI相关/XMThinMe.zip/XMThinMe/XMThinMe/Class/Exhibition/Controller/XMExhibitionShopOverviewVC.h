//
//  XMExhibitionShopOverviewVC.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/11.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "OViewController.h"

@interface XMExhibitionShopOverviewVC : OViewController
@property (strong, nonatomic) NSString *shopName;
@property (strong, nonatomic) NSString *shopDescription;
@property (strong, nonatomic) NSString *address;

@end
