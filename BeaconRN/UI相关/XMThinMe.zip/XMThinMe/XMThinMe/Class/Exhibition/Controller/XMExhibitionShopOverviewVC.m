//
//  XMExhibitionShopOverviewVC.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/11.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMExhibitionShopOverviewVC.h"

@interface XMExhibitionShopOverviewVC ()
@property (strong, nonatomic)  UIScrollView *scrollView;

@end

@implementation XMExhibitionShopOverviewVC

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"简介";
    
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.scrollView];

    OLabel *shopNameLbl = [[OLabel alloc] initWithFrame:CGRectMake(10, 10, self.view.width - 20, 25)];
    shopNameLbl.text = @"关于我们";//self.shopName;
    shopNameLbl.font = kB_Font(16);
    [self.scrollView addSubview:shopNameLbl];
    
    UIView *seprator = [[UIView alloc] initWithFrame:CGRectMake(shopNameLbl.x, shopNameLbl.bottom + 5, shopNameLbl.width, 1)];
    seprator.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.3];
    [self.scrollView addSubview:seprator];
    
    CGFloat height = [self.shopDescription heightForConstraintSize:CGSizeMake(shopNameLbl.width, 99999) font:kN_MiddleFont];
    OLabel *descriptionLbl = [[OLabel alloc] initWithFrame:CGRectMake(shopNameLbl.x, shopNameLbl.bottom + 10, shopNameLbl.width, height)];
    descriptionLbl.text = self.shopDescription;
    descriptionLbl.numberOfLines = 0;
    [self.scrollView addSubview:descriptionLbl];
    
    OLabel *contactsLbl = [[OLabel alloc] initWithFrame:CGRectMake(10, descriptionLbl.bottom + 20, self.view.width - 20, 25)];
    contactsLbl.text = @"联系我们";
    contactsLbl.font = shopNameLbl.font;
    [self.scrollView addSubview:contactsLbl];
    
    seprator = [[UIView alloc] initWithFrame:CGRectMake(shopNameLbl.x, contactsLbl.bottom + 5, shopNameLbl.width, 1)];
    seprator.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.3];
    [self.scrollView addSubview:seprator];
    
    OLabel *contactsInfoLbl = [[OLabel alloc] initWithFrame:CGRectMake(shopNameLbl.x, seprator.bottom + 5, shopNameLbl.width, 100)];
//    contactsInfoLbl.text = @"贵宾专线：400－820－0187\n\n开放时间：周一至周日 8:00 ~ 21:00\n\nE-mail:info@landroverchina.com.cn\n\nWebsite:http://www.landrover.com";
    contactsInfoLbl.text = self.address;
    contactsInfoLbl.numberOfLines = 0;
    [contactsInfoLbl sizeToFit];
    [self.scrollView addSubview:contactsInfoLbl];

    self.scrollView.contentSize = CGSizeMake(self.scrollView.width, contactsInfoLbl.bottom+10);
}


@end
