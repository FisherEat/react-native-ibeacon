//
//  XMCarDetailVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/8/22.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionProductVC.h"
#import "XMExhibitionProductDetailCell.h"
#import "XMExhibitionProductImagesCell.h"
#import "XMCommentVC.h"
#import "XMCommentCell.h"
#import "XMComment.h"
#import "XMCommentBar.h"
#import "XMImageBrowseVC.h"

@interface XMExhibitionProductVC () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
@property (strong, nonatomic) UITableView    *tableView;
@property (strong, nonatomic) NSMutableArray *tableData;

@property (strong, nonatomic) NSMutableArray *comments;
@property (strong, nonatomic) XMCommentBar   *commentBar;
@property (assign, nonatomic) NSInteger      pageIndex;

@end

@implementation XMExhibitionProductVC

- (id)init
{
    self = [super init];
    if (self) {
        mWeakSelf;
        XMSNSManager *snsManager = [[XMSNSManager alloc] init];
        __weak XMSNSManager *weakSNS = snsManager;
        snsManager.shareToFriendBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.product.product_description scene:0];
        };
        snsManager.shareToFriendSessionBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.product.product_description scene:1];
        };
        snsManager.collectToWeChatBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.product.product_description scene:2];
        };
        self.navigationItem.rightBarButtonItem = [snsManager shareBarButton];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    self.tableData = @[].mutableCopy;
    self.title = self.product.product_name;

    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;

    self.comments = @[].mutableCopy;
    
    mWeakSelf;
    self.commentBar = [[XMCommentBar alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 44)];
    self.commentBar.commentTF.delegate = self;
    self.commentBar.commentTF.bk_shouldReturnBlock = ^(UITextField *tf){
        [tf resignFirstResponder];
        [weakSelf sendComent:tf.text completion:^(BOOL success, XMComment *comment) {
            if (success) {
                tf.text = @"";
                [XMProgressHUD showTips:@"评论成功！" atView:weakSelf.view];
                [weakSelf.comments insertObject:comment atIndex:0];
                [weakSelf.tableView reloadSections:[NSIndexSet indexSetWithIndex:2] withRowAnimation:UITableViewRowAnimationAutomatic];
            } else {
                [XMProgressHUD showTips:@"评论失败！" atView:weakSelf.view];
            }
        }];
        return YES;
    };
    
    [self requestProductDetail];
    [self requestCommentList];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGRect rect = CGRectMake(0, self.tableView.contentSize.height, self.tableView.width, self.tableView.height);
    [self.tableView scrollRectToVisible:rect animated:YES];
}


#pragma mark - tableView Delegate && datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    } else if (section == 1) {
        return self.tableData.count;
    }
    return self.comments.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 2) {
        return 44;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (section == 2) {
        return self.commentBar;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 2) {
        return 44;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 2) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.width, 44)];
        view.backgroundColor = mRGB(231, 231, 231);
        
        OLabel *lbl = [[OLabel alloc] initWithFrame:CGRectMake(10, 0, 100, 44)];
        lbl.text = @"热门评论";
        [view addSubview:lbl];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.backgroundColor = kOrangeColor;
        btn.cornerRadius = 4;
        btn.frame = CGRectMake(view.width - 65, 7, 60, 30);
        [btn setTitle:@"所有评论" forState:UIControlStateNormal];
        btn.titleLabel.font = kFont(12);
        [view addSubview:btn];
        
        mWeakSelf;
        [btn bk_addEventHandler:^(id sender) {
            [weakSelf.tableView endEditing:YES];
            
            XMCommentVC *comentVC = [[XMCommentVC alloc] init];
            comentVC.product = weakSelf.product;
            [weakSelf.navigationController pushViewController:comentVC animated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
        
        return view;
    }
    return nil;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 200;
    } else if (indexPath.section == 1) {
        return [XMExhibitionProductDetailCell cellHeightForCellData:self.tableData[indexPath.row]];
    }

    return [XMCommentCell cellHeightForCellData:self.comments[indexPath.row]];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        mWeakSelf;
        XMExhibitionProductImagesCell *cell = [[XMExhibitionProductImagesCell alloc] initWithStyle:0 reuseIdentifier:nil];
        NSURL *imgUrl = [NSURL URLWithString:self.product.image_url];
        NSURLRequest *request = [NSURLRequest requestWithURL:imgUrl];
        __weak UIImageView *iv = cell.thumbnailIV;
        __weak XMExhibitionProductImagesCell *weakCell = cell;
        [cell.thumbnailIV setImageWithURLRequest:request placeholderImage:kPlaceholderImage_rectangle success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
            iv.image = image;
            CGFloat height = weakCell.width * (image.size.height / image.size.width);
            if (height > weakCell.height) {
                iv.frame = CGRectMake(0, -(height-weakCell.height), iv.width, height);
            } else {
                CGFloat width = weakCell.height * (image.size.width / image.size.height);
                iv.frame = CGRectMake(-(width - weakCell.width)/2, 0, width, iv.height);
                [weakCell sendSubviewToBack:iv];
            }
        } failure:nil];
        
        [cell.moreBtn bk_addEventHandler:^(id sender) {
            XMImageBrowseVC *imageBrowseVC = [[XMImageBrowseVC alloc] init];
            imageBrowseVC.product = weakSelf.product;
            [weakSelf.navigationController pushViewController:imageBrowseVC animated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
        
        return cell;
    } else if (indexPath.section == 1) {
        static NSString *identifier = @"carDetailCell";
        XMExhibitionProductDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[XMExhibitionProductDetailCell alloc] initWithStyle:0 reuseIdentifier:identifier];
        }
        
        [cell configureCellWithCellData:self.tableData[indexPath.row]];
        
        if (indexPath.row == 0) {
            cell.priceLbl.text = [NSString stringWithFormat:@"%.2f元", self.product.official_quotation];
            cell.priceLbl.hidden = NO;
        } else {
            cell.priceLbl.hidden = YES;
        }
        
        return cell;
    }
    
    static NSString *identifier = @"tripCommentCell";
    XMCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMCommentCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    [cell configureCellWithCellData:self.comments[indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark - network request

- (void)requestProductDetail
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    mWeakSelf;
    NSDictionary *params = @{@"product_id": self.product.product_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Product_GetEntityDetailInfo withParams:params completionHandler:^(NSDictionary *data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

         if (!error) {
             /// 删除非title_和description_的字段
             NSMutableDictionary *productDict = data.mutableCopy;
             for (NSString *key in productDict.allKeys) {
                 if ([key containString:@"title_"] || [key containString:@"description_"]) {
                     continue;
                 }
                 [productDict removeObjectForKey:key];
             }
             
             /// 将相应的字段做封装，并且过滤掉空字段
             for (int i = 0; i < productDict.allKeys.count/2; i++) {
                 NSString *titleKey = [NSString stringWithFormat:@"title_%zd", i+1];
                 NSString *descriptionKey = [NSString stringWithFormat:@"description_%zd", i+1];
                 if (![productDict[titleKey] isEqualToString:@""] && ![productDict[descriptionKey] isEqualToString:@""]) {
                     NSDictionary *dict = @{@"title": productDict[titleKey], @"content": productDict[descriptionKey]};
                     [self.tableData addObject:dict];
                 }
             }

             NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:1];
             [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
         }
     }];
}

- (void)requestCommentList
{
    if (!self.product.product_id) {
        return;
    }
    mWeakSelf;
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    NSDictionary *params = @{@"use_id": self.product.product_id,
                             @"device_type": @([XMAppManager platform]),
                             @"user_id": [XMUserManager sharedInstance].userId,
                             @"page_index": @(0),
                             @"page_size": @"3"};
    [[OURLRequest sharedInstance] postForPath:N_Product_GetEntityCommentList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

         for (NSDictionary *dict in data) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
             XMComment *comment = [[XMComment alloc] initWithJSONData:objectData];
             [weakSelf.comments addObject:comment];
         }
         NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:2];
         [weakSelf.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
     }];
}

- (void)sendComent:(NSString *)comment completion:(void (^) (BOOL success, XMComment *comment))completion
{
    if (!self.product.product_id || comment.length == 0) {
        return;
    }
    
    NSDictionary *params = @{@"use_id": self.product.product_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId,
                             @"comment_title": self.product.product_name,
                             @"comment_content": comment,
                             @"ip_address":@""};
    [[OURLRequest sharedInstance] postForPath:N_Product_AddEntityComment withParams:params completionHandler:^(id data, NSError *error)
     {
         if (error) {
             completion(NO, nil);
         } else {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:data options:0 error:nil];
             XMComment *comment = [[XMComment alloc] initWithJSONData:objectData];
             completion(YES, comment);
         }
     }];
}

@end
