//
//  XMExhibitionVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionVC.h"
#import "XMExhibitionShopCell.h"
#import "XMExhibitionImagesCell.h"
#import "XMExhibitionFunctionCell.h"
#import "XMExhibitionShopVC.h"
#import "XMExhibitionAgendaVC.h"
#import "XMMapVC.h"
#import "XMIndoorMapVC.h"
#import "XMExhibitionOverviewVC.h"
#import "XMAdvertise.h"
#import "OWaterfallLayout.h"

@interface XMExhibitionVC ()
@property (strong, nonatomic) NSMutableArray *shopArray;
@property (strong, nonatomic) NSMutableArray *advertiseArray;

@end

@implementation XMExhibitionVC

- (id)init
{
    self = [super init];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
        self.shopArray = @[].mutableCopy;
        self.advertiseArray = @[].mutableCopy;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//    self.shyNavBarManager.scrollView = self.tableView;
    self.title = self.business.business_name;

    [self getBusinessAdvertiseList];
    [self getBusinessShopList];
}


#pragma mark - delegate && datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 2) {
        return self.shopArray.count;
    }
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 200;
    }
    else if (indexPath.section == 1) {
        return 110;
    }
    return 100;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        static NSString *identifier = @"exhibitionImagesCell";
        XMExhibitionImagesCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[XMExhibitionImagesCell alloc] initWithStyle:0 reuseIdentifier:identifier];
        }
    
        [cell configureCellWithCellData:self.advertiseArray];
        
        return cell;
    }
    else if (indexPath.section == 1) {
        static NSString *identifier = @"exhibitionFunctionCell";
        XMExhibitionFunctionCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[XMExhibitionFunctionCell alloc] initWithStyle:0 reuseIdentifier:identifier];
            mWeakSelf;
            cell.functionButtonClicked = ^(UIButton *sender)
            {
                if (sender.tag == ExhibitionFunctionButtonAgenda) {
                    XMExhibitionAgendaVC *agendaVC = [[XMExhibitionAgendaVC alloc] init];
                    agendaVC.business = weakSelf.business;
                    [weakSelf.navigationController pushViewController:agendaVC animated:YES];
                } else if (sender.tag == ExhibitionFunctionButtonLocation) {
                    XMMapVC *mapVC = [[XMMapVC alloc] init];
                    mapVC.business = weakSelf.business;
                    [weakSelf.navigationController pushViewController:mapVC animated:YES];
                } else if (sender.tag == ExhibitionFunctionButtonIndoorMap) {
                    XMIndoorMapVC *indoorMapVC = [[XMIndoorMapVC alloc] init];
                    indoorMapVC.business = weakSelf.business;
                    [weakSelf.navigationController pushViewController:indoorMapVC animated:YES];
                } else if (sender.tag == ExhibitionFunctionButtonOverview) {
                    XMExhibitionOverviewVC *overviewVC = [[XMExhibitionOverviewVC alloc] init];
                    overviewVC.description = weakSelf.business.description;
                    [weakSelf.navigationController pushViewController:overviewVC animated:YES];
                }
            };
        }
        
        return cell;
    }
    
    static NSString *identifier = @"exhibitionCell";
    XMExhibitionShopCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMExhibitionShopCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    
    [cell configureCellWithCellData:self.shopArray[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0 || indexPath.section == 1) {
        return;
    }
    
    XMExhibitionShopVC *exhibitionDetailVC = [[XMExhibitionShopVC alloc] init];
    exhibitionDetailVC.shop = self.shopArray[indexPath.row];
    [self.navigationController pushViewController:exhibitionDetailVC animated:YES];
}


#pragma mark - network request

- (void)getBusinessAdvertiseList
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    mWeakSelf;
    NSDictionary *params = @{@"business_id": self.business.business_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Business_GetEntityAdvertiseList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

         for (NSDictionary *dict in data) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
             XMAdvertise *advertise = [[XMAdvertise alloc] initWithJSONData:objectData];
             [weakSelf.advertiseArray addObject:advertise];
         }
         NSIndexPath *idexPath = [NSIndexPath indexPathForRow:0 inSection:0];
         [weakSelf.tableView reloadRowsAtIndexPaths:@[idexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
     }];
}

- (void)getBusinessShopList
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    mWeakSelf;
    NSDictionary *params = @{@"business_id": self.business.business_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Business_GetEntityShopList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

         for (NSDictionary *dict in data) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
             XMShop *shop = [[XMShop alloc] initWithJSONData:objectData];
             [weakSelf.shopArray addObject:shop];
         }
         [weakSelf.tableView reloadData];
     }];
}


@end
