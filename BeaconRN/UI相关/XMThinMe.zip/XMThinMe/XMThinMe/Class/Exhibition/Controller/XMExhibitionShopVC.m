//
//  XMExhibitionDetailVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionShopVC.h"
#import "XMExhibitionProductVC.h"
#import "XMExhibitionDetailView.h"
#import "XMExhibitionNewsView.h"
#import "XMExhibitionFileView.h"
#import "XMMapVC.h"
#import "XMExhibitionShopOverviewVC.h"
#import "XMProduct.h"
#import "XMFile.h"
#import "XMNews.h"
#import "XMExhibitionFileVC.h"
#import "XMMessage.h"
#import "XMExhibitionSignInView.h"

@interface XMExhibitionShopVC () <UIScrollViewDelegate>
@property (strong, nonatomic) UIScrollView *scrollView;
@property (strong, nonatomic) UISegmentedControl *seg;
@property (strong, nonatomic) XMExhibitionDetailView *detailView;
@property (strong, nonatomic) XMExhibitionNewsView *newsView;

@property (strong, nonatomic) XMExhibitionSignInView *signInView;

@property (strong, nonatomic) XMBeaconDetail *beaconDetail;

@end

@implementation XMExhibitionShopVC

- (id)init
{
    self = [super init];
    if (self) {
        mWeakSelf;
        XMSNSManager *snsManager = [[XMSNSManager alloc] init];
        __weak XMSNSManager *weakSNS = snsManager;
        snsManager.shareToFriendBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.beaconDetail.content_1 scene:0];
        };
        snsManager.shareToFriendSessionBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.beaconDetail.content_1 scene:1];
        };
        snsManager.collectToWeChatBlock = ^(){
            [weakSNS sendTextMessage:weakSelf.beaconDetail.content_1 scene:2];
        };
        self.navigationItem.rightBarButtonItem = [snsManager shareBarButton];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = self.shop.shop_name;
    
    mWeakSelf;
    self.seg = [[UISegmentedControl alloc] initWithItems:@[@" 动态  ", @"  详情  ", @"  奖励 "]];
    self.seg.frame = CGRectMake(15, 7 + mNavHeight, self.view.width - 30, 30);
    [self.seg setContentOffset:CGSizeMake(-3, 0) forSegmentAtIndex:1];
    [self.seg setContentOffset:CGSizeMake(-2, 0) forSegmentAtIndex:2];
    self.seg.selectedSegmentIndex = 1;
    self.seg.tintColor = kBlackColor;
    [self.seg bk_addEventHandler:^(UISegmentedControl *sender) {
        CGRect rect = CGRectMake(weakSelf.scrollView.width * sender.selectedSegmentIndex, 0, weakSelf.scrollView.width, weakSelf.scrollView.height);
        [weakSelf.scrollView scrollRectToVisible:rect animated:YES];
        
        if (sender.selectedSegmentIndex == 0) {
            if (weakSelf.newsView.news.count == 0) {

            }
        }
        else if (sender.selectedSegmentIndex == 2) {
        }
    } forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:self.seg];

    CGRect rect = CGRectMake(0, self.seg.bottom + 7, self.view.width, self.view.height - self.seg.bottom - 7);
    self.scrollView = [[UIScrollView alloc] initWithFrame:rect];
    self.scrollView.contentSize = CGSizeMake(self.scrollView.width * 3, self.scrollView.height);
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.delegate = self;
    self.scrollView.bounces = NO;
    [self.view addSubview:self.scrollView];
    
    // 新闻视图
    rect = CGRectMake(0, 0, self.scrollView.width, self.scrollView.height);
    self.newsView = [[XMExhibitionNewsView alloc] initWithFrame:rect];
    self.newsView.selectCellBlcok = ^(NSIndexPath *indexPath, id data){
        
    };
    [self.scrollView addSubview:self.newsView];

    // 详情视图
    rect = CGRectMake(self.scrollView.width, 0, self.scrollView.width, self.scrollView.height);
    self.detailView = [[XMExhibitionDetailView alloc] initWithFrame:rect];
    self.detailView.selectCellBlcok = ^(NSIndexPath *indexPath, id data){
        XMExhibitionProductVC *productDetailVC = [[XMExhibitionProductVC alloc] init];
        productDetailVC.product = data;
        [weakSelf.navigationController pushViewController:productDetailVC animated:YES];
    };
    self.detailView.functionButtonClicked = ^(OButton *sender) {
        if (sender.tag == ExhibitionFunctionButtonLocation) {
            XMMapVC *mapVC = [[XMMapVC alloc] init];
            mapVC.shop = weakSelf.shop;
            [weakSelf.navigationController pushViewController:mapVC animated:YES];
        }
        else if (sender.tag == ExhibitionFunctionButtonFile) {
            XMExhibitionFileVC *fileManagerVC = [[XMExhibitionFileVC alloc] init];
            fileManagerVC.shop = weakSelf.shop;
            [weakSelf.navigationController pushViewController:fileManagerVC animated:YES];
        }
        else if (sender.tag == ExhibitionFunctionButtonOverview) {
            XMExhibitionShopOverviewVC *overviewVC = [[XMExhibitionShopOverviewVC alloc] init];
            overviewVC.shopName = weakSelf.shop.shop_name;
            overviewVC.shopDescription = weakSelf.beaconDetail.content_1;
            overviewVC.address = weakSelf.shop.address;
            [weakSelf.navigationController pushViewController:overviewVC animated:YES];
        }
    };
    self.detailView.followButtonClicked = ^(OButton *sender) {
        sender.selected = !sender.selected;
        if (sender.selected) {
            [weakSelf addEntityAttention:^(BOOL success){
                if (success) {
                    [weakSelf bk_performBlock:^(id obj) {
                        [XMProgressHUD showTips:@"关注成功！" atView:weakSelf.view];
                        [sender setImage:[UIImage imageNamed:@"exhibition_unfollow_normal"] forState:UIControlStateNormal];
                        [sender setImage:[UIImage imageNamed:@"exhibition_unfollow_highlighted"] forState:UIControlStateHighlighted];
                    } afterDelay:0];
                } else {
                    [weakSelf bk_performBlock:^(id obj) {
                        [XMProgressHUD showTips:@"关注失败！" atView:weakSelf.view];
                    } afterDelay:0];
                }
            }];
        } else {
            [weakSelf deleteEntityAttention:^(BOOL success) {
                if (success) {
                    [weakSelf bk_performBlock:^(id obj) {
                        [XMProgressHUD showTips:@"已取消关注！" atView:weakSelf.view];
                        [sender setImage:[UIImage imageNamed:@"exhibition_follow_normal"] forState:UIControlStateNormal];
                        [sender setImage:[UIImage imageNamed:@"exhibition_follow_highlighted"] forState:UIControlStateHighlighted];
                    } afterDelay:0];
                } else {
                    [weakSelf bk_performBlock:^(id obj) {
                        [XMProgressHUD showTips:@"取消关注失败！" atView:weakSelf.view];
                    } afterDelay:0];
                }
            }];
        }
    };
    [self.scrollView addSubview:self.detailView];
    
    // 文件管理视图
    rect = CGRectMake(self.scrollView.width * 2, 0, self.scrollView.width, self.scrollView.height);
    self.signInView = [[XMExhibitionSignInView alloc] initWithFrame:rect];
    [self.scrollView addSubview:self.signInView];
    
    [self.detailView.collectionView addFooterWithCallback:^{
        [weakSelf requestProductList];
    }];
    
    [self getTempleInfo];
    [self requestShopPictureList];
    [self requestProductList];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.scrollView scrollRectToVisible:CGRectMake(self.scrollView.width, 0, self.scrollView.width, self.scrollView.height) animated:YES];
}


#pragma mark - scrollView delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat   pageWidth   = scrollView.frame.size.width;
    NSInteger currentPage = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.seg.selectedSegmentIndex = currentPage;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat   pageWidth   = scrollView.frame.size.width;
    NSInteger currentPage = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    if (currentPage == 0) {
        if (self.newsView.news.count == 0) {

        }
    } else if (currentPage == 2) {
    }
}


#pragma mark - network request

- (void)requestShopPictureList
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId,
                             @"page_index": @(0),
                             @"page_size": @(10)};
    [[OURLRequest sharedInstance] postForPath:N_TemplateExamples_GetEntityPictureListByShopid withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         if (!error) {
             NSMutableArray *images = @[].mutableCopy;
             for (NSDictionary *dict in data) {
                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                 XMImage *image = [[XMImage alloc] initWithJSONData:objectData];
                 [images addObject:image];
             }
             weakSelf.detailView.shopImages = images;
         }
         [weakSelf.detailView.collectionView reloadData];
     }];
}


- (void)getTempleInfo
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];
    
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Shop_GetEntityTemplateExamplesDetailInfo withParams:params completionHandler:^(NSArray *data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];
         
         if (!error) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:[data firstObject] options:0 error:nil];
             weakSelf.beaconDetail = [[XMBeaconDetail alloc] initWithJSONData:objectData];
         }
     }];
}

- (void)requestProductList
{
    mWeakSelf;
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId,
                             @"page_index":@(self.detailView.pageIndex),
                             @"page_size":@(10)};
    [[OURLRequest sharedInstance] postForPath:N_Shop_GetEntityProductList withParams:params completionHandler:^(id data, NSError *error)
     {
         if (!error) {
             weakSelf.detailView.pageIndex++;
             for (NSDictionary *dict in data) {
                 NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
                 XMProduct *product = [[XMProduct alloc] initWithJSONData:objectData];
                 [weakSelf.detailView.products addObject:product];
             }
             
             NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:0];
             [weakSelf.detailView.collectionView reloadSections:indexSet];
         }
         [weakSelf.detailView.collectionView footerEndRefreshing];
     }];
}

- (void)addEntityAttention:(void (^) (BOOL success))completion
{
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_User_AddEntityAttention withParams:params completionHandler:^(id data, NSError *error)
     {
         if (!error) {
             completion(YES);
         } else {
             if (error.code == ORequestStatusDataHadExist) {
                 completion(YES);
             } else {
                 completion(NO);
             }
         }
     }];
}

- (void)deleteEntityAttention:(void (^) (BOOL success))completion
{
    NSDictionary *params = @{@"shop_id": self.shop.shop_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_User_DeleteEntityAttention withParams:params completionHandler:^(id data, NSError *error)
     {
         if (!error) {
             completion(YES);
         } else {
             if (error.code == ORequestStatusDataHadExist) {
                 completion(YES);
             } else {
                 completion(NO);
             }
         }
     }];
}


@end
