//
//  XMExhibitionIntroductionVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionOverviewVC.h"

@interface XMExhibitionOverviewVC ()
@property (strong, nonatomic) OTextView *textView;

@end

@implementation XMExhibitionOverviewVC
@synthesize description;

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"概况";
    
    self.textView = [[OTextView alloc] initWithFrame:CGRectMake(10, 0, self.view.width - 20, self.view.height)];
    self.textView.editable = NO;
    self.textView.showsVerticalScrollIndicator = NO;
    self.textView.text = self.description;
    [self.view addSubview:self.textView];
}



@end
