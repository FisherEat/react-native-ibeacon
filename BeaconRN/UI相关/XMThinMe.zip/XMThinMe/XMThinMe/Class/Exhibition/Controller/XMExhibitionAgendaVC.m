//
//  XMExhibitionAgendaVC.m
//  XMMuseum
//
//  Created by 何振东 on 14/10/29.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import "XMExhibitionAgendaVC.h"
#import "XMExhibitionAgendaCell.h"

@interface XMExhibitionAgendaVC ()
@property (strong, nonatomic) NSMutableArray *tableData;

@end

@implementation XMExhibitionAgendaVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableData = @[].mutableCopy;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.title = @"日程";
    
    [self requestAgendaList];
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableData.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"exhibitionAgendaCell";
    XMExhibitionAgendaCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMExhibitionAgendaCell alloc] initWithStyle:0 reuseIdentifier:identifier];
    }
    [cell configureCellWithCellData:self.tableData[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark - network request

- (void)requestAgendaList
{
    [[XMProgressHUD sharedInstance] showProgressAtView:self.view];

    mWeakSelf;
    NSDictionary *params = @{@"business_id": self.business.business_id,
                             @"device_type":@([XMAppManager platform]),
                             @"user_id":[XMUserManager sharedInstance].userId};
    [[OURLRequest sharedInstance] postForPath:N_Business_GetEntityAgendaList withParams:params completionHandler:^(id data, NSError *error)
     {
         [[XMProgressHUD sharedInstance] hideProgress];

         for (NSDictionary *dict in data) {
             NSData *objectData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
             XMAgenda *agenda = [[XMAgenda alloc] initWithJSONData:objectData];
             [weakSelf.tableData addObject:agenda];
         }
         [weakSelf.tableView reloadData];
     }];
}


@end
