//
//  XMShop.m
//  XMThinMe
//
//  Created by 何振东 on 14/11/4.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import "XMShop.h"

@implementation XMShop
@synthesize description;

-(id)init {
    self = [super init];
    if (self) {
        [self setValue:@"XMImage" forKeyPath:@"propertyArrayMap.images"];
    }
    return self;
}

@end
