//
//  XMProduct.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/11.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMProduct : NSObject
@property (copy, nonatomic) NSString *product_id;
@property (copy, nonatomic) NSString *product_name;
@property (copy, nonatomic) NSString *product_description;
@property (copy, nonatomic) NSString *title_1;
@property (copy, nonatomic) NSString *title_2;
@property (copy, nonatomic) NSString *title_3;
@property (copy, nonatomic) NSString *title_4;
@property (copy, nonatomic) NSString *title_5;
@property (copy, nonatomic) NSString *description_1;
@property (copy, nonatomic) NSString *description_2;
@property (copy, nonatomic) NSString *description_3;
@property (copy, nonatomic) NSString *description_4;
@property (copy, nonatomic) NSString *description_5;
@property (copy, nonatomic) NSString *image_url;
@property (assign, nonatomic) CGFloat official_quotation;
@property (assign, nonatomic) CGFloat width;
@property (assign, nonatomic) CGFloat height;

@end
