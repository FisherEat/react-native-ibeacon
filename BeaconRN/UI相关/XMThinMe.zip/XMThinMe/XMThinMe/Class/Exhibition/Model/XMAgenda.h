//
//  XMExhibitionDetailInfo.h
//  XMMuseum
//
//  Created by 何振东 on 14/8/27.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMAgenda : NSObject
@property (strong, nonatomic) NSString  *agenda_id;
@property (strong, nonatomic) NSString  *agenda_title;
@property (strong, nonatomic) NSString  *address;
@property (strong, nonatomic) NSString  *agenda_content;
@property (assign, nonatomic) NSInteger start_time;
@property (assign, nonatomic) NSInteger end_time;
@property (strong, nonatomic) NSString  *shop_id;

@end