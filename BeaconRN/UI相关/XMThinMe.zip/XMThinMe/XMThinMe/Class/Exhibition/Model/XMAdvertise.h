//
//  XMAdvertise.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/5.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMAdvertise : NSObject
@property (copy, nonatomic) NSString *advertise_id;
@property (copy, nonatomic) NSString *advertise_title;
@property (copy, nonatomic) NSString *advertise_content;
@property (copy, nonatomic) NSString *picture_url;

@end
