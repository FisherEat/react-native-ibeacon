//
//  XMShop.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/4.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMImage.h"

@interface XMShop : NSObject
@property (copy, nonatomic  ) NSString       *shop_id;
@property (copy, nonatomic  ) NSString       *shop_name;
@property (copy, nonatomic  ) NSString       *description;
@property (copy, nonatomic  ) NSString       *logo_url;
@property (assign, nonatomic) NSTimeInterval start_time;
@property (assign, nonatomic) NSTimeInterval end_time;
@property (copy, nonatomic  ) NSString       *address;
@property (strong, nonatomic) NSArray        *images;
@property (assign, nonatomic) NSInteger      type;

@property (assign, nonatomic) CGFloat width;
@property (assign, nonatomic) CGFloat height;

@property (assign, nonatomic) CGFloat latitude;
@property (assign, nonatomic) CGFloat longitude;

@end
