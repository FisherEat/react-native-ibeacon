//
//  XMNews.h
//  XMThinMe
//
//  Created by 何振东 on 14/11/16.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMNews : NSObject
@property (copy, nonatomic) NSString *news_id;
@property (copy, nonatomic) NSString *news_title;
@property (copy, nonatomic) NSString *news_content;

@property (assign, nonatomic) NSTimeInterval created_time;
@property (assign, nonatomic) NSTimeInterval start_time;
@property (assign, nonatomic) NSTimeInterval end_time;

@end
