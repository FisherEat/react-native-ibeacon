//
//  AppDelegate.h
//  XMThinMe
//
//  Created by 何振东 on 14/10/31.
//  Copyright (c) 2014年 寻觅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WXApi.h"
#import "BMKMapManager.h"
#import <SMS_SDK/SMS_SDK.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate, WXApiDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) BMKMapManager *mapManager;


@end

